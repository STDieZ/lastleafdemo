import 'package:material_ui/material_ui.dart';

const canvas = Color(0xfffaf9f5);
const sidebar = Color(0xffeeeee6);
const ink = Color(0xff252c26);
const forest = Color(0xff274e3e);
const moss = Color(0xffdce7db);
const muted = Color(0xff59645a);
const border = Color(0xffdaddd1);

final leafTheme = ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(seedColor: forest).copyWith(
    primary: forest,
    onPrimary: Colors.white,
    surface: canvas,
    onSurface: ink,
    onSurfaceVariant: muted,
    outline: border,
  ),
  scaffoldBackgroundColor: canvas,
  dividerColor: border,
  inputDecorationTheme: InputDecorationTheme(
    filled: true,
    fillColor: canvas,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: border),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: border),
    ),
  ),
  textTheme: const TextTheme(
    headlineMedium: TextStyle(fontWeight: FontWeight.w700, letterSpacing: -0.7),
    titleMedium: TextStyle(fontWeight: FontWeight.w700),
    bodyMedium: TextStyle(height: 1.35),
    bodyLarge: TextStyle(height: 1.4),
  ),
);

class LeafMark extends StatelessWidget {
  const LeafMark({super.key, this.large = false});

  final bool large;

  @override
  Widget build(BuildContext context) => Container(
    width: large ? 64 : 40,
    height: large ? 64 : 40,
    decoration: BoxDecoration(
      color: forest,
      borderRadius: BorderRadius.circular(large ? 20 : 13),
    ),
    child: Icon(Icons.eco_outlined, color: Colors.white, size: large ? 34 : 23),
  );
}
