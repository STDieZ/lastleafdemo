import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

import 'keys.dart';
import 'notes.dart';

const _magic = [0x4c, 0x4c, 0x01, 0x00];
const _frameLimit = maxNotebookBytes + 40;
const _executionTime = Duration(seconds: 12);
final _exchange = X25519();
final _sha256 = Sha256();

typedef MergeNotebook = Future<Notebook> Function(Notebook remote);

Future<void> receiveSync(
  Socket socket,
  AccountKey account,
  Notebook Function() snapshot,
  MergeNotebook merge,
) => _useSocket(socket, (stream) async {
  final hello = await stream.read(36);
  for (var i = 0; i < _magic.length; i++) {
    if (hello[i] != _magic[i]) {
      throw const FormatException('Invalid sync protocol');
    }
  }
  final clientPublic = hello.sublist(4);
  final keyPair = await _exchange.newKeyPair();
  final serverPublic = (await keyPair.extractPublicKey()).bytes;
  final keys = await _session(
    account,
    keyPair,
    clientPublic,
    clientPublic,
    serverPublic,
  );
  socket.add(serverPublic);
  socket.add(await seal(const [], keys.proof));
  await socket.flush();
  final digest = await unseal(await stream.read(72), keys.client);
  final local = await _sha256.hash(snapshot().encode());
  final needsUpdate = local != Hash(digest);
  socket.add(await seal([if (needsUpdate) 1 else 0], keys.server));
  await socket.flush();
  if (!needsUpdate) return;
  final remote = Notebook.decode(
    await unseal(await stream.frame(), keys.client),
  );
  final merged = await merge(remote);
  await stream.writeFrame(await seal(merged.encode(), keys.server));
});

Future<void> sendSync(
  Socket socket,
  AccountKey account,
  Notebook Function() snapshot,
  MergeNotebook merge,
) => _useSocket(socket, (stream) async {
  final keyPair = await _exchange.newKeyPair();
  final clientPublic = (await keyPair.extractPublicKey()).bytes;
  socket.add([..._magic, ...clientPublic]);
  await socket.flush();
  final serverPublic = await stream.read(32);
  final keys = await _session(
    account,
    keyPair,
    serverPublic,
    clientPublic,
    serverPublic,
  );
  await unseal(await stream.read(40), keys.proof);
  final contents = snapshot().encode();
  final digest = await _sha256.hash(contents);
  socket.add(await seal(digest.bytes, keys.client));
  await socket.flush();
  final update = await unseal(await stream.read(41), keys.server);
  if (update.single == 0) return;
  if (update.single != 1) throw const FormatException('Invalid sync response');
  await stream.writeFrame(await seal(contents, keys.client));
  final remote = Notebook.decode(
    await unseal(await stream.frame(), keys.server),
  );
  await merge(remote);
});

Future<SessionKeys> _session(
  AccountKey account,
  KeyPair keyPair,
  List<int> remotePublic,
  List<int> clientPublic,
  List<int> serverPublic,
) async {
  final sharedSecret = await _exchange.sharedSecretKey(
    keyPair: keyPair,
    remotePublicKey: SimplePublicKey(remotePublic, type: KeyPairType.x25519),
  );
  if ((await sharedSecret.extractBytes()).every((byte) => byte == 0)) {
    throw const FormatException('Invalid public key');
  }
  return account.session(
    sharedSecret: sharedSecret,
    clientPublic: clientPublic,
    serverPublic: serverPublic,
  );
}

Future<void> _useSocket(
  Socket socket,
  Future<void> Function(_SocketFrames connection) operation,
) async {
  final stream = _SocketFrames(socket);
  unawaited(
    socket.done.then<void>((_) {}, onError: (Object _, StackTrace _) {}),
  );
  try {
    await operation(stream).timeout(_executionTime);
  } finally {
    socket.destroy();
    unawaited(
      stream.chunks.cancel().then<void>(
        (_) {},
        onError: (Object _, StackTrace _) {},
      ),
    );
  }
}

class _SocketFrames {
  _SocketFrames(this.socket) : chunks = StreamIterator(socket);

  final Socket socket;
  final StreamIterator<Uint8List> chunks;
  Uint8List _chunk = Uint8List(0);
  int _offset = 0;

  Future<Uint8List> read(int size) async {
    final result = Uint8List(size);
    var position = 0;
    while (position < size) {
      if (_offset == _chunk.length) {
        if (!await chunks.moveNext()) {
          throw const SocketException('Connection closed');
        }
        _chunk = chunks.current;
        _offset = 0;
      }
      final available = _chunk.length - _offset;
      final length = available < size - position ? available : size - position;
      result.setRange(position, position + length, _chunk, _offset);
      position += length;
      _offset += length;
    }
    return result;
  }

  Future<Uint8List> frame() async {
    final size = (await read(4)).buffer.asByteData().getUint32(0);
    if (size < 40 || size > _frameLimit) {
      throw const FormatException('Invalid frame size');
    }
    return read(size);
  }

  Future<void> writeFrame(List<int> data) async {
    final length = ByteData(4)..setUint32(0, data.length);
    socket.add(length.buffer.asUint8List());
    socket.add(data);
    await socket.flush();
  }
}
