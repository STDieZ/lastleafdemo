import 'dart:async';
import 'dart:io';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as path;

import 'keys.dart';
import 'note_edit.dart';
import 'notes.dart';

Future<void> replaceFile(File file, List<int> data) async {
  final temporary = File('${file.path}.tmp');
  await temporary.writeAsBytes(data, flush: true);
  await temporary.rename(file.path);
}

class NotebookStore extends ChangeNotifier {
  NotebookStore._(this._file, this._key, this._notebook);

  static File fileIn(Directory directory) =>
      File(path.join(directory.path, 'notebook.v1'));

  static Future<NotebookStore> open(
    Directory directory,
    AccountKey account,
  ) async {
    final file = fileIn(directory);
    final key = await account.diskKey();
    var notebook = Notebook.empty();
    if (await file.exists()) {
      if (await file.length() > maxNotebookBytes + 40) {
        throw const NotebookFull();
      }
      notebook = Notebook.decode(await unseal(await file.readAsBytes(), key));
    }
    return NotebookStore._(file, key, notebook);
  }

  final File _file;
  final SecretKey _key;
  Notebook _notebook;
  Future<void> _pending = Future.value();

  Notebook get notebook => _notebook;
  Directory get directory => _file.parent;
  Future<void> get idle => _pending;

  Future<T> _queue<T>(Future<T> Function() operation) {
    final result = _pending.then((_) => operation());
    _pending = result.then<void>((_) {}, onError: (Object _, StackTrace _) {});
    return result;
  }

  Future<void> _commit(Notebook value) async {
    if (identical(value, _notebook)) return;
    await replaceFile(_file, await seal(value.encode(), _key));
    _notebook = value;
    notifyListeners();
  }

  Future<Notebook> merge(Notebook incoming) => _queue(() async {
    await _commit(_notebook.merge(incoming));
    return _notebook;
  });

  Future<void> setPinned(String id, String author, bool pinned) =>
      _queue(() => _commit(_notebook.setPinned(id, author, pinned)));

  Future<NoteVersion> revise({
    required String id,
    required String author,
    required Iterable<NoteVersion> basedOn,
    required String title,
    required String body,
    bool deleted = false,
    NoteEdit? edit,
  }) => _queue(() async {
    final result = _notebook.revise(
      id: id,
      author: author,
      basedOn: basedOn,
      title: title,
      body: body,
      deleted: deleted,
      edit: edit,
    );
    await _commit(result.notebook);
    return result.version;
  });
}
