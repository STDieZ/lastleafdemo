package com.lanleaf.lanleaf

import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.net.Inet4Address

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "com.lanleaf/local")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "applicationSupport" -> result.success(noBackupFilesDir.absolutePath)
                    "localInterfaces" -> result.success(localInterfaces())
                    else -> result.notImplemented()
                }
            }
    }

    @Suppress("DEPRECATION") // Include Wi-Fi even when mobile data is the default network.
    private fun localInterfaces(): List<String> {
        val connectivity = getSystemService(ConnectivityManager::class.java) ?: return emptyList()
        return buildSet {
            for (network in connectivity.allNetworks) {
                val capabilities = connectivity.getNetworkCapabilities(network) ?: continue
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) continue
                val isLocal = capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                    capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                if (!isLocal) continue

                val link = connectivity.getLinkProperties(network) ?: continue
                for (address in link.linkAddresses) {
                    if (address.address is Inet4Address) {
                        add("${address.address.hostAddress}/${address.prefixLength}")
                    }
                }
            }
        }.toList()
    }
}
