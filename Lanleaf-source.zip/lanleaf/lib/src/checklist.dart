const uncheckedItem = '- [ ] ';
const checkedItem = '- [x] ';

final _marker = RegExp(r'^- \[([ xX])\](?: |$)');

({String text, bool checked})? checklistItem(String line) {
  final match = _marker.firstMatch(line);
  if (match == null) return null;
  return (text: line.substring(match.end), checked: match[1] != ' ');
}

String notePreview(String body) => body
    .split('\n')
    .map((line) => checklistItem(line)?.text ?? line)
    .join(' ')
    .trim()
    .replaceAll(RegExp(r'\s+'), ' ');
