import 'package:material_ui/material_ui.dart';

import 'code_field.dart';
import 'keys.dart';
import 'peers.dart';
import 'platform_services.dart';
import 'theme.dart';

class SetupPage extends StatefulWidget {
  const SetupPage({
    super.key,
    required this.onConnect,
    this.hasPreviousNotes = false,
    this.onImportPrevious,
  });

  final Future<void> Function(ConnectionCode code, {required bool restore})
  onConnect;
  final bool hasPreviousNotes;
  final Future<void> Function()? onImportPrevious;

  @override
  State<SetupPage> createState() => _SetupPageState();
}

class _SetupPageState extends State<SetupPage> {
  final _code = TextEditingController();
  bool _joining = false;
  bool _busy = false;
  String? _error;

  Future<void> _connect({required bool join}) async {
    if (_busy) return;
    final ConnectionCode code;
    try {
      code = join
          ? ConnectionCode.parse(_code.text)
          : ConnectionCode(AccountKey.generate());
    } on FormatException {
      setState(
        () => _error = 'Проверьте код подключения. Он начинается с LL1-.',
      );
      return;
    }
    await _attempt(
      () => widget.onConnect(code, restore: join && widget.hasPreviousNotes),
    );
  }

  Future<void> _attempt(Future<void> Function() open) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await open();
    } on NoNotesForCode {
      if (mounted) {
        setState(
          () => _error = 'По этому коду не удалось открыть сохранённые заметки. Проверьте код прежнего аккаунта.',
        );
      }
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'Не удалось сохранить аккаунт на устройстве.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _setJoining(bool joining) {
    setState(() {
      _joining = joining;
      _error = null;
      if (!joining) _code.clear();
    });
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final text = theme.textTheme;
    final previous = widget.hasPreviousNotes;
    final importPrevious = widget.onImportPrevious;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: LeafMark(large: true),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    appName,
                    style: text.displayMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    previous
                        ? 'На устройстве есть зашифрованные заметки. Их можно открыть по прежнему коду подключения или создать новый аккаунт и восстановить старые заметки позже.'
                        : _joining
                        ? 'Скопируйте код из настроек Last Leaf на другом устройстве. Откройте приложение на обоих устройствах в одной сети Wi‑Fi.'
                        : 'Текстовые заметки на ваших устройствах. Синхронизация по локальной сети, без облака.',
                    style: text.bodyLarge?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 28),
                  if (_joining) ...[
                    CodeField(
                      controller: _code,
                      enabled: !_busy,
                      onSubmitted: (_) => _connect(join: true),
                    ),
                    const SizedBox(height: 14),
                  ],
                  if (_error != null) ...[
                    Text(
                      _error!,
                      style: TextStyle(color: theme.colorScheme.error),
                    ),
                    const SizedBox(height: 12),
                  ],
                  FilledButton.icon(
                    onPressed: _busy
                        ? null
                        : _joining || !previous
                        ? () => _connect(join: _joining)
                        : () => _setJoining(true),
                    icon: Icon(
                      _joining ? Icons.link_rounded : Icons.add_rounded,
                    ),
                    label: Text(
                      _joining
                          ? previous
                                ? 'Открыть прежние заметки'
                                : 'Подключить устройство'
                          : previous
                          ? 'Восстановить по коду'
                          : 'Создать локальный аккаунт',
                    ),
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: _busy
                        ? null
                        : _joining
                        ? () => _setJoining(false)
                        : previous
                        ? () => _connect(join: false)
                        : () => _setJoining(true),
                    child: Text(
                      _joining
                          ? 'Назад'
                          : previous
                          ? 'Создать новый аккаунт'
                          : 'У меня есть код подключения',
                    ),
                  ),
                  if (!_joining && importPrevious != null)
                    TextButton(
                      onPressed: _busy ? null : () => _attempt(importPrevious),
                      child: const Text('Перенести существующий аккаунт'),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
