import 'dart:async';

import 'package:material_ui/material_ui.dart';

import 'src/appearance_settings.dart';
import 'src/lan_sync.dart';
import 'src/notebook_store.dart';
import 'src/notes.dart';
import 'src/peers.dart';
import 'src/platform_services.dart';
import 'src/setup.dart';
import 'src/theme.dart';
import 'src/workspace.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LastLeafApp());
}

class LastLeafApp extends StatefulWidget {
  const LastLeafApp({super.key});

  @override
  State<LastLeafApp> createState() => _LastLeafAppState();
}

class _LastLeafAppState extends State<LastLeafApp> {
  DeviceStorage? _device;
  LocalAccount? _account;
  NotebookStore? _store;
  LanSync? _sync;
  AppearanceSettings _appearance = AppearanceSettings();
  String? _startupError;
  var _loading = true;

  @override
  void initState() {
    super.initState();
    unawaited(_open());
  }

  Future<void> _open() async {
    setState(() {
      _loading = true;
      _startupError = null;
    });
    try {
      _device ??= await DeviceStorage.open();
      _appearance = await AppearanceSettings.open(_device!.directory);
      final stored = await _device!.readAccount();
      if (stored != null) await _activate(stored);
    } on StorageInUse {
      _startupError =
          'Приложение уже открыто. Закройте другое окно и попробуйте снова.';
    } catch (_) {
      _startupError = 'Не удалось открыть данные на этом устройстве.';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _activate(
    LocalAccount account, {
    List<LanEndpoint> hints = const [],
  }) async {
    final store = await NotebookStore.open(
      await _device!.directoryFor(account),
      account.key,
    );
    _startSync(account, store, hints: hints);
  }

  void _startSync(
    LocalAccount account,
    NotebookStore store, {
    List<LanEndpoint> hints = const [],
  }) {
    final sync = LanSync(account, store);
    _store = store;
    _account = account;
    _sync = sync;
    unawaited(sync.start(hints: hints));
  }

  Future<void> _onboard(ConnectionCode code) async {
    final saved = await _device!.readAccount();
    if (saved != null && saved.key.code != code.key.code) {
      throw const FormatException('A local account already exists');
    }
    final account = saved ?? LocalAccount(code.key, newId());
    if (saved == null) await _device!.writeAccount(account);
    await _activate(account, hints: code.endpoints);
    if (mounted) setState(() {});
  }

  Future<void> _joinByCode(ConnectionCode code) async {
    final current = _account!;
    final sync = _sync!;
    if (code.key.code == current.key.code) {
      await sync.addCode(code);
      return;
    }

    final account = LocalAccount(
      code.key,
      current.device,
      storageTag: await code.key.discoveryTag(),
    );
    final oldStore = _store!;
    final newStore = await NotebookStore.open(
      await _device!.directoryFor(account),
      account.key,
    );
    try {
      await sync.close();
      await newStore.merge(oldStore.notebook);
      await _device!.writeAccount(account);
    } catch (_) {
      sync.dispose();
      if (mounted) setState(() => _startSync(current, oldStore));
      rethrow;
    }
    sync.dispose();
    if (mounted) {
      setState(() => _startSync(account, newStore, hints: code.endpoints));
    }
  }

  @override
  void dispose() {
    _sync?.dispose();
    final device = _device;
    if (device != null) unawaited(device.close());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final error = _startupError;
    return ListenableBuilder(
      listenable: _appearance,
      builder: (context, _) => MaterialApp(
        title: appName,
        debugShowCheckedModeBanner: false,
        theme: buildLeafTheme(_appearance.palette, Brightness.light),
        darkTheme: buildLeafTheme(_appearance.palette, Brightness.dark),
        themeMode: _appearance.mode,
        locale: const Locale('ru'),
        supportedLocales: const [Locale('ru')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        home: _loading
            ? const Scaffold(body: Center(child: CircularProgressIndicator()))
            : error != null
            ? Scaffold(
                body: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(error, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        FilledButton(
                          onPressed: _open,
                          child: const Text('Попробовать снова'),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            : _account == null
            ? SetupPage(onConnect: _onboard)
            : NotesWorkspace(
                key: ValueKey(_store!),
                account: _account!,
                store: _store!,
                sync: _sync!,
                appearance: _appearance,
                onJoinCode: _joinByCode,
              ),
      ),
    );
  }
}
