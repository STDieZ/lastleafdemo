import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/main.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/notebook_store.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as path;

const _platform = MethodChannel('com.lanleaf/local');
const _unlock = 'Запросить доступ к ключу';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets(
    'startup reads silently and opens the old notebook after explicit authorization',
    (tester) async {
      final root = await _temporarySupport(tester);
      final key = AccountKey.generate();
      final device = newId();
      final noteId = newId();
      await tester.runAsync(() async {
        final directory = await Directory(path.join(root.path, 'Lanleaf'))
            .create();
        final store = await NotebookStore.open(directory, key);
        await store.revise(
          id: noteId,
          author: device,
          basedOn: [],
          title: 'Мои заметки до обновления',
          body: 'Сохранённый текст',
        );
      });

      final calls = <String>[];
      var authorized = false;
      _mockPlatform((call) async {
        switch (call.method) {
          case 'applicationSupport':
            return root.path;
          case 'readIdentity':
          case 'readIdentityWithAuthorization':
            calls.add(call.method);
            if (call.method == 'readIdentityWithAuthorization' && authorized) {
              return utf8.encode(
                jsonEncode({'key': key.code, 'device': device}),
              );
            }
            throw PlatformException(code: 'keychain-access-required');
          case 'localInterfaces':
            return <String>[];
          default:
            return null;
        }
      });

      await tester.pumpWidget(const LastLeafApp());
      await _waitFor(tester, _unlock);
      expect(calls, ['readIdentity']);
      expect(find.text('Мои заметки до обновления'), findsNothing);

      // Under a denial the app returns to its access screen without another prompt.
      await tester.tap(find.text(_unlock));
      await _waitFor(tester, _unlock);
      expect(calls, ['readIdentity', 'readIdentityWithAuthorization']);

      authorized = true;
      await tester.tap(find.text(_unlock));
      await _waitFor(tester, 'Мои заметки до обновления');
      expect(calls, [
        'readIdentity',
        'readIdentityWithAuthorization',
        'readIdentityWithAuthorization',
      ]);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
    },
    skip: Platform.isWindows,
  );

  testWidgets(
    'an interactive keychain write follows a separate user decision',
    (tester) async {
      final root = await _temporarySupport(tester);
      final calls = <String>[];
      Uint8List? saved;
      _mockPlatform((call) async {
        switch (call.method) {
          case 'applicationSupport':
            return root.path;
          case 'readIdentity':
            return saved;
          case 'writeIdentity':
            calls.add(call.method);
            throw PlatformException(code: 'keychain-access-required');
          case 'writeIdentityWithAuthorization':
            calls.add(call.method);
            saved = call.arguments as Uint8List;
            return null;
          case 'localInterfaces':
            return <String>[];
          default:
            return null;
        }
      });
      await tester.pumpWidget(const LastLeafApp());
      await _waitFor(tester, 'Создать локальный аккаунт');

      await tester.tap(find.text('Создать локальный аккаунт'));
      await _waitFor(tester, 'Сохранить ключ Last Leaf');
      expect(calls, ['writeIdentity']);
      await tester.tap(find.text('Отмена'));
      await tester.pumpAndSettle();
      expect(calls, ['writeIdentity']);
      expect(saved, isNull);

      await tester.tap(find.text('Создать локальный аккаунт'));
      await _waitFor(tester, 'Сохранить ключ Last Leaf');
      await tester.tap(find.text('Запросить доступ'));
      await _waitFor(tester, 'Новая заметка');
      expect(calls, [
        'writeIdentity',
        'writeIdentity',
        'writeIdentityWithAuthorization',
      ]);
      final identity = jsonDecode(utf8.decode(saved!)) as Map<String, dynamic>;
      expect(identity['key'], startsWith('LL1-'));
      expect(isId(identity['device']), isTrue);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
    },
    skip: Platform.isWindows,
  );
}

Future<Directory> _temporarySupport(WidgetTester tester) async {
  final root = (await tester.runAsync(
    () => Directory.systemTemp.createTemp('last-leaf-keychain-test-'),
  ))!;
  addTearDown(() => root.delete(recursive: true));
  return root;
}

void _mockPlatform(Future<Object?> Function(MethodCall) handler) {
  final messenger =
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  messenger.setMockMethodCallHandler(_platform, handler);
  addTearDown(() => messenger.setMockMethodCallHandler(_platform, null));
}

Future<void> _waitFor(WidgetTester tester, String text) async {
  final label = find.text(text);
  final watch = Stopwatch()..start();
  // Exercise real file I/O while advancing the widget test's clock.
  do {
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 12)),
    );
    await tester.pump(const Duration(milliseconds: 20));
  } while (label.evaluate().isEmpty &&
      watch.elapsed < const Duration(seconds: 5));
  expect(label, findsOneWidget);
  await tester.pumpAndSettle();
}
