import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/src/appearance_settings.dart';
import 'package:lanleaf/src/theme.dart';
import 'package:material_ui/material_ui.dart';

void main() {
  test('palette and dark mode survive reopening the application', () async {
    final directory = await Directory.systemTemp.createTemp(
      'last-leaf-appearance-',
    );
    addTearDown(() => directory.delete(recursive: true));
    final settings = await AppearanceSettings.open(directory);
    expect(settings.palette, LeafPalette.green);
    expect(settings.mode, ThemeMode.system);

    await Future.wait([
      settings.update(palette: LeafPalette.purple),
      settings.update(mode: ThemeMode.dark),
    ]);

    final reopened = await AppearanceSettings.open(directory);
    expect(reopened.palette, LeafPalette.purple);
    expect(reopened.mode, ThemeMode.dark);
    final dark = buildLeafTheme(reopened.palette, Brightness.dark);
    final light = buildLeafTheme(reopened.palette, Brightness.light);
    expect(dark.brightness, Brightness.dark);
    expect(dark.colorScheme.surface, isNot(light.colorScheme.surface));
    expect(
      dark.colorScheme.primary,
      isNot(
        buildLeafTheme(LeafPalette.green, Brightness.dark).colorScheme.primary,
      ),
    );
  });
}
