import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:nsd/nsd.dart' as nsd;

import 'notebook_store.dart';
import 'notes.dart';
import 'platform_services.dart';
import 'wire_sync.dart';

const _serviceType = '_lanleaf-v1._tcp';
const _maxIncoming = 6;

class LanSync extends ChangeNotifier {
  LanSync(this.account, this.store);

  final LocalAccount account;
  final NotebookStore store;

  ServerSocket? _server;
  List<LanInterface> _interfaces = const [];
  nsd.Discovery? _discovery;
  nsd.Registration? _registration;
  final _resolved = <String, nsd.Service>{};
  final _connections = <Socket>{};
  final _outgoing = <String, Future<void>>{};
  Timer? _timer;
  Timer? _debounce;
  Future<void>? _refreshing;
  Future<void>? _polling;
  DateTime? _lastDiscoveryAttempt;
  String _name = '';
  String _match = '';
  int _incoming = 0;
  bool _disposed = false;

  DateTime? lastSynced;
  bool discoveryReady = false;

  List<String> get addresses {
    final port = _server?.port;
    return port == null
        ? []
        : [
            for (final interface in _interfaces)
              '${interface.address.address}:$port',
          ];
  }

  bool get hasNetwork => _interfaces.isNotEmpty;

  Future<void> start() async {
    final tag = await account.key.discoveryTag();
    if (_disposed) return;
    _match = 'lanleaf-$tag-';
    _name = '$_match${newId().substring(0, 10)}';
    store.addListener(_scheduleSync);
    _timer = Timer.periodic(
      const Duration(seconds: 10),
      (_) => unawaited(syncNow()),
    );
    await syncNow();
  }

  void _scheduleSync() {
    _debounce?.cancel();
    _debounce = Timer(
      const Duration(milliseconds: 450),
      () => unawaited(syncNow()),
    );
  }

  Future<void> _refresh() =>
      _refreshing ??= _updateNetwork().whenComplete(() => _refreshing = null);

  Future<void> _updateNetwork() async {
    final interfaces = await localInterfaces();
    if (_disposed) return;
    final previous = _interfaces
        .map((e) => '${e.address.address}/${e.prefix}')
        .toSet();
    _interfaces = interfaces;
    final current = interfaces
        .map((e) => '${e.address.address}/${e.prefix}')
        .toSet();
    if (!setEquals(previous, current)) {
      _resolved.clear();
      _lastDiscoveryAttempt = null;
      _notify();
    }
    if (_interfaces.isEmpty || _server != null) return;
    final server = await ServerSocket.bind(InternetAddress.anyIPv4, 0);
    if (_disposed) {
      await server.close();
      return;
    }
    _server = server;
    server.listen(
      (socket) => unawaited(_receive(socket)),
      onError: (Object _) {},
    );
    _notify();
  }

  Future<void> _ensureDiscovery() async {
    if (_disposed ||
        !hasNetwork ||
        _server == null ||
        _name.isEmpty ||
        discoveryReady) {
      return;
    }
    final now = DateTime.now();
    final last = _lastDiscoveryAttempt;
    if (last != null && now.difference(last) < const Duration(seconds: 25)) {
      return;
    }
    _lastDiscoveryAttempt = now;
    try {
      if (_registration == null) {
        final registration = await _withTimeout(
          nsd.register(
            nsd.Service(name: _name, type: _serviceType, port: _server!.port),
          ),
          nsd.unregister,
        );
        if (_disposed) {
          await nsd.unregister(registration);
          return;
        }
        _registration = registration;
        _name = registration.service.name?.toLowerCase() ?? _name;
      }
      if (_discovery == null) {
        final discovery = await _withTimeout(
          nsd.startDiscovery(_serviceType, autoResolve: false),
          nsd.stopDiscovery,
        );
        if (_disposed) {
          await nsd.stopDiscovery(discovery);
          return;
        }
        _discovery = discovery;
        discovery.addServiceListener(_discoveryChanged);
      }
      discoveryReady = true;
    } catch (_) {
      discoveryReady = false;
    }
    _notify();
  }

  Future<T> _withTimeout<T>(Future<T> task, Future<void> Function(T) cleanup) =>
      task.timeout(
        const Duration(seconds: 4),
        onTimeout: () {
          unawaited(
            task
                .then(cleanup)
                .then<void>((_) {}, onError: (Object _, StackTrace _) {}),
          );
          throw TimeoutException('Bonjour operation expired');
        },
      );

  void _discoveryChanged(nsd.Service service, nsd.ServiceStatus status) {
    final name = service.name?.toLowerCase();
    if (name == null || name == _name || !name.startsWith(_match)) return;
    if (status == nsd.ServiceStatus.lost) _resolved.remove(name);
    _scheduleSync();
  }

  Future<void> syncNow() =>
      _polling ??= _poll().whenComplete(() => _polling = null);

  Future<void> _poll() async {
    try {
      await _refresh();
      await _ensureDiscovery();
      if (_disposed || !hasNetwork) return;
      final candidates =
          _discovery?.services
              .where((service) {
                final name = service.name?.toLowerCase();
                return name != null && name != _name && name.startsWith(_match);
              })
              .take(12)
              .toList() ??
          [];
      // Limit simultaneous lookups and handshakes on busy local networks.
      for (var i = 0; i < candidates.length && !_disposed; i += 4) {
        await Future.wait(candidates.skip(i).take(4).map(_syncService));
      }
    } catch (_) {
      _notify();
    }
  }

  Future<void> _syncService(nsd.Service service) async {
    final name = service.name!.toLowerCase();
    try {
      final peer =
          _resolved[name] ??
          await nsd.resolve(service).timeout(const Duration(seconds: 3));
      final port = peer.port;
      if (port == null || port < 1 || port > 65535 || _disposed) return;
      final hosts = peer.addresses ?? await _lookup(peer.host);
      for (final address in hosts) {
        if (_route(address) == null || _isThisDevice(address, port)) continue;
        try {
          await _connect(address, port);
          _resolved[name] = peer;
          return;
        } catch (_) {
          // A service can have multiple addresses; try the remaining routes.
        }
      }
      _resolved.remove(name);
    } catch (_) {
      _resolved.remove(name);
    }
  }

  Future<List<InternetAddress>> _lookup(String? host) async {
    if (host == null) return [];
    final direct = InternetAddress.tryParse(host);
    if (direct != null) return [direct];
    final local = host.toLowerCase();
    if (!local.endsWith('.local') && !local.endsWith('.local.')) return [];
    return InternetAddress.lookup(
      host,
      type: InternetAddressType.IPv4,
    ).timeout(const Duration(seconds: 3));
  }

  LanInterface? _route(InternetAddress address) =>
      _interfaces.where((interface) => interface.contains(address)).firstOrNull;

  bool _isThisDevice(InternetAddress address, int port) =>
      _server?.port == port &&
      _interfaces.any(
        (interface) => interface.address.address == address.address,
      );

  Future<void> syncWith(String target) async {
    final parts = target.trim().split(':');
    final address = parts.length == 2
        ? InternetAddress.tryParse(parts[0])
        : null;
    final port = parts.length == 2 ? int.tryParse(parts[1]) : null;
    if (address == null ||
        port == null ||
        port < 1 ||
        port > 65535 ||
        !LanInterface.isPrivateV4(address)) {
      throw const FormatException(
        'Введите локальный адрес в формате 192.168.1.5:12345.',
      );
    }
    await _refresh();
    if (_route(address) == null || _isThisDevice(address, port)) {
      throw const FormatException(
        'Укажите адрес другого устройства в этой локальной сети.',
      );
    }
    await _connect(address, port);
  }

  Future<void> _connect(InternetAddress address, int port) {
    final endpoint = '${address.address}:$port';
    return _outgoing.putIfAbsent(
      endpoint,
      () => _exchangeNotes(
        address,
        port,
      ).whenComplete(() => _outgoing.remove(endpoint)),
    );
  }

  Future<void> _exchangeNotes(InternetAddress address, int port) async {
    if (_disposed) return;
    final route = _route(address);
    if (route == null) throw const SocketException('Not on the local subnet');
    Socket? socket;
    try {
      socket = await Socket.connect(
        address,
        port,
        sourceAddress: route.address,
        timeout: const Duration(seconds: 3),
      );
      if (_disposed) {
        socket.destroy();
        return;
      }
      _connections.add(socket);
      await sendSync(socket, account.key, () => store.notebook, store.merge);
      _markSynced();
    } finally {
      if (socket != null) _connections.remove(socket);
    }
  }

  Future<void> _receive(Socket socket) async {
    if (_disposed ||
        _incoming >= _maxIncoming ||
        _route(socket.remoteAddress) == null) {
      socket.destroy();
      return;
    }
    _incoming++;
    _connections.add(socket);
    try {
      await receiveSync(socket, account.key, () => store.notebook, store.merge);
      _markSynced();
    } catch (_) {
      // Unknown accounts, invalid frames, and disconnected peers are ignored.
    } finally {
      _connections.remove(socket);
      _incoming--;
    }
  }

  void _markSynced() {
    lastSynced = DateTime.now();
    _notify();
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  void _quietly(Future<void> task) {
    unawaited(task.then<void>((_) {}, onError: (Object _, StackTrace _) {}));
  }

  @override
  void dispose() {
    _disposed = true;
    _timer?.cancel();
    _debounce?.cancel();
    store.removeListener(_scheduleSync);
    for (final socket in _connections) {
      socket.destroy();
    }
    final discovery = _discovery;
    if (discovery != null) {
      discovery.removeServiceListener(_discoveryChanged);
      _quietly(nsd.stopDiscovery(discovery));
    }
    final registration = _registration;
    if (registration != null) _quietly(nsd.unregister(registration));
    final server = _server;
    if (server != null) _quietly(server.close());
    super.dispose();
  }
}
