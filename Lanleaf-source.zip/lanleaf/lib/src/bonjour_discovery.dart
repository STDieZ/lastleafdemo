import 'dart:async';
import 'dart:io';

import 'package:bonsoir/bonsoir.dart';
import 'package:flutter/foundation.dart';

import 'peers.dart';

const _serviceType = '_lanleaf-v1._tcp';
const _addressAttribute = 'ipv4';
const _operationTimeout = Duration(seconds: 4);

typedef PeerDiscoveryFactory = PeerDiscovery Function(
  String name,
  String group,
  List<LanEndpoint> localEndpoints,
  VoidCallback onChanged,
);

abstract interface class PeerDiscovery {
  Iterable<LanEndpoint> get endpoints;
  bool get healthy;
  Future<void> start();
  Future<void> close();
}

class BonjourDiscovery implements PeerDiscovery {
  BonjourDiscovery(
    this._name,
    this._group,
    this._localEndpoints,
    this._onChanged,
  );

  final String _name;
  final String _group;
  final List<LanEndpoint> _localEndpoints;
  final VoidCallback _onChanged;
  final _services = <String, Set<LanEndpoint>>{};
  final _resolving = <String>{};
  BonsoirBroadcast? _broadcast;
  BonsoirDiscovery? _browser;
  StreamSubscription<BonsoirBroadcastEvent>? _broadcastEvents;
  StreamSubscription<BonsoirDiscoveryEvent>? _discoveryEvents;
  bool _publishing = false;
  bool _browsing = false;
  bool _closed = false;

  @override
  bool get healthy => _publishing && _browsing;

  @override
  Iterable<LanEndpoint> get endpoints => _services.values.expand((e) => e);

  @override
  Future<void> start() => Future.wait([_publish(), _browse()]);

  Future<void> _publish() async {
    try {
      final service = BonsoirService(
        name: _name,
        type: _serviceType,
        port: _localEndpoints.first.port,
        attributes: {
          _addressAttribute: _localEndpoints.take(maxCodeEndpoints).join(','),
        },
      );
      final broadcast = _broadcast = BonsoirBroadcast(
        service: service,
        printLogs: false,
      );
      await broadcast.initialize().timeout(_operationTimeout);
      if (_closed) return;
      _broadcastEvents = broadcast.eventStream?.listen(
        (event) {
          if (event is BonsoirBroadcastStartedEvent) _publishing = true;
          if (event is BonsoirBroadcastStoppedEvent) _publishing = false;
        },
        onError: (Object _, StackTrace _) => _publishing = false,
        onDone: () => _publishing = false,
      );
      await broadcast.start().timeout(_operationTimeout);
    } catch (_) {
      _publishing = false;
    }
  }

  Future<void> _browse() async {
    try {
      final browser = _browser = BonsoirDiscovery(
        type: _serviceType,
        printLogs: false,
      );
      await browser.initialize().timeout(_operationTimeout);
      if (_closed) return;
      _discoveryEvents = browser.eventStream?.listen(
        _onEvent,
        onError: (Object _, StackTrace _) => _browsing = false,
        onDone: () => _browsing = false,
      );
      await browser.start().timeout(_operationTimeout);
    } catch (_) {
      _browsing = false;
    }
  }

  void _onEvent(BonsoirDiscoveryEvent event) {
    if (_closed) return;
    if (event is BonsoirDiscoveryStartedEvent) _browsing = true;
    if (event is BonsoirDiscoveryStoppedEvent) _browsing = false;
    final service = event.service;
    if (service == null) return;
    final name = service.name.toLowerCase();
    if (!name.startsWith(_group) || name == _name) return;

    if (event is BonsoirDiscoveryServiceLostEvent) {
      _resolving.remove(name);
      if (_services.remove(name) != null) _onChanged();
      return;
    }
    if (event is BonsoirDiscoveryServiceResolvedEvent ||
        event is BonsoirDiscoveryServiceResolveFailedEvent) {
      _resolving.remove(name);
    }
    if (event is BonsoirDiscoveryServiceResolveFailedEvent) return;
    if (!_services.containsKey(name) && _services.length >= 24) {
      return;
    }

    final addresses = advertisedEndpoints(service);
    if (addresses.isEmpty) {
      final browser = _browser;
      if (browser != null &&
          (event is BonsoirDiscoveryServiceFoundEvent ||
              event is BonsoirDiscoveryServiceUpdatedEvent) &&
          _resolving.length < 24 &&
          _resolving.add(name)) {
        unawaited(
          service.resolve(browser.serviceResolver).catchError((Object _) {
            _resolving.remove(name);
          }),
        );
      }
      return;
    }
    if (!setEquals(_services[name], addresses)) {
      _services[name] = addresses;
      _onChanged();
    }
  }

  @override
  Future<void> close() async {
    _closed = true;
    _services.clear();
    _resolving.clear();
    await Future.wait([
      if (_browser case final browser? when browser.isReady)
        _stop(browser.stop()),
      if (_broadcast case final broadcast? when broadcast.isReady)
        _stop(broadcast.stop()),
    ]);
    await Future.wait([
      if (_discoveryEvents case final events?) _stop(events.cancel()),
      if (_broadcastEvents case final events?) _stop(events.cancel()),
    ]);
  }

  Future<void> _stop(Future<void> operation) async {
    try {
      await operation.timeout(_operationTimeout);
    } catch (_) {
      // A platform service can already be stopped after a network change.
    }
  }
}

@visibleForTesting
Set<LanEndpoint> advertisedEndpoints(BonsoirService service) {
  final advertised = service.attributes[_addressAttribute]?.split(',') ?? [];
  return {
    for (final value in advertised.take(maxCodeEndpoints))
      ?LanEndpoint.tryParse(value),
    if (service.port > 0 && service.port <= 65535)
      for (final raw in service.hostAddresses.take(maxCodeEndpoints))
        if (InternetAddress.tryParse(raw) case final address?
            when address.type == InternetAddressType.IPv4)
          LanEndpoint(address, service.port),
  };
}
