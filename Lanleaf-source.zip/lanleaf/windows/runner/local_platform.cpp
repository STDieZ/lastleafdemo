#include <winsock2.h>
#include <ws2tcpip.h>
#include <windows.h>
#include <iphlpapi.h>
#include <wincrypt.h>

#include <flutter/method_channel.h>
#include <flutter/standard_method_codec.h>

#include <string>
#include <vector>

#include "local_platform.h"

namespace {

using ByteVector = std::vector<uint8_t>;
using flutter::EncodableValue;
using flutter::MethodResult;

flutter::EncodableList LocalInterfaces() {
  constexpr ULONG flags = GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST |
                          GAA_FLAG_SKIP_DNS_SERVER;
  ULONG size = 15000;
  std::vector<uint8_t> buffer(size);
  auto adapters = reinterpret_cast<IP_ADAPTER_ADDRESSES*>(buffer.data());
  ULONG status = GetAdaptersAddresses(AF_INET, flags, nullptr, adapters, &size);
  if (status == ERROR_BUFFER_OVERFLOW) {
    buffer.resize(size);
    adapters = reinterpret_cast<IP_ADAPTER_ADDRESSES*>(buffer.data());
    status = GetAdaptersAddresses(AF_INET, flags, nullptr, adapters, &size);
  }

  flutter::EncodableList addresses;
  if (status != NO_ERROR) {
    return addresses;
  }
  for (auto adapter = adapters; adapter; adapter = adapter->Next) {
    if (adapter->OperStatus != IfOperStatusUp ||
        (adapter->IfType != IF_TYPE_ETHERNET_CSMACD &&
         adapter->IfType != IF_TYPE_IEEE80211)) {
      continue;
    }
    for (auto entry = adapter->FirstUnicastAddress; entry; entry = entry->Next) {
      if (entry->Address.lpSockaddr->sa_family != AF_INET) {
        continue;
      }
      const auto address =
          reinterpret_cast<const sockaddr_in*>(entry->Address.lpSockaddr);
      char text[INET_ADDRSTRLEN];
      if (InetNtopA(AF_INET, &address->sin_addr, text, sizeof(text))) {
        addresses.emplace_back(std::string(text) + "/" +
                               std::to_string(entry->OnLinkPrefixLength));
      }
    }
  }
  return addresses;
}

void ReadLegacyIdentity(const EncodableValue* argument,
                        MethodResult<EncodableValue>* result) {
  const auto bytes = argument ? std::get_if<ByteVector>(argument) : nullptr;
  if (!bytes || bytes->empty() || bytes->size() > 65536) {
    result->Error("arguments");
    return;
  }
  DATA_BLOB input{static_cast<DWORD>(bytes->size()),
                  const_cast<BYTE*>(bytes->data())};
  DATA_BLOB output{};
  const BOOL ok = CryptUnprotectData(&input, nullptr, nullptr, nullptr, nullptr,
                                     CRYPTPROTECT_UI_FORBIDDEN, &output);
  if (!ok) {
    result->Error("dpapi");
    return;
  }
  const ByteVector data(output.pbData, output.pbData + output.cbData);
  SecureZeroMemory(output.pbData, output.cbData);
  LocalFree(output.pbData);
  result->Success(EncodableValue(data));
}

}  // namespace

void RegisterLocalPlatform(flutter::BinaryMessenger* messenger) {
  flutter::MethodChannel<EncodableValue> channel(
      messenger, "com.lanleaf/local", &flutter::StandardMethodCodec::GetInstance());
  channel.SetMethodCallHandler([](const auto& call, auto result) {
    if (call.method_name() == "localInterfaces") {
      result->Success(EncodableValue(LocalInterfaces()));
    } else if (call.method_name() == "readLegacyWindowsIdentity") {
      ReadLegacyIdentity(call.arguments(), result.get());
    } else {
      result->NotImplemented();
    }
  });
}
