import 'dart:async';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/src/bluetooth_mailbox.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/note_edit.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/peers.dart';
import 'package:lanleaf/src/wire_sync.dart';

void main() {
  test(
    'public addresses in codes survive reopening and stay separate from LAN',
    () async {
      final key = AccountKey.generate();
      final lan = LanEndpoint.tryParse('192.168.1.10:41721')!;
      final v6 = InternetEndpoint.tryParse('[2606:4700::1]:41721')!;
      final dns = InternetEndpoint.tryParse('NOTES.Example.org:43000')!;
      final code = ConnectionCode.parse(
        ConnectionCode(key, [lan], [v6, dns]).text,
      );
      expect(code.key.code, key.code);
      expect(code.endpoints, [lan]);
      expect(code.internet, [v6, dns]);
      expect(dns.toString(), 'notes.example.org:43000');
      for (final address in [
        '192.168.1.10:41721',
        '100.65.10.1:41721',
        '127.0.0.1:80',
        '[::1]:41721',
        'user@notes.example.org:80',
      ]) {
        expect(InternetEndpoint.tryParse(address), isNull);
      }

      final directory = await Directory.systemTemp.createTemp(
        'last-leaf-endpoints-',
      );
      addTearDown(() => directory.delete(recursive: true));
      final saved = await PeerHistory.open(directory, key);
      await saved.rememberHints(code.endpoints);
      await saved.rememberInternet(code.internet);
      final reopened = await PeerHistory.open(directory, key);
      expect(reopened.endpoints, [lan]);
      expect(reopened.internet, [v6, dns]);
      await reopened.forgetInternet(v6);
      expect((await PeerHistory.open(directory, key)).internet, [dns]);
    },
  );

  test(
    'legacy revisions can be enriched without losing the latest edit on sync',
    () {
      final noteId = newId();
      final edit = NoteEdit.between(
        device: 'Домашний ноутбук',
        beforeTitle: 'Дела',
        beforeBody: '- [ ] Купить чай',
        title: 'Дела',
        body: '- [x] Купить чай',
      );
      final revision = Notebook.empty()
          .revise(
            id: noteId,
            author: newId(),
            basedOn: [],
            title: 'Дела',
            body: '- [x] Купить чай',
            edit: edit,
          )
          .notebook;
      final older = Notebook.decode(revision.encode(includeEdits: false));
      final newer = Notebook.decode(revision.encode());
      expect(older.notes[noteId]!.latest.edit, isNull);
      expect(
        newer.merge(older).notes[noteId]!.latest.edit?.device,
        'Домашний ноутбук',
      );
      expect(older.merge(newer).notes[noteId]!.latest.edit?.describe('Дела'), [
        'Отмечен пункт «Купить чай»',
      ]);
    },
  );

  test(
    'a chunked Bluetooth mailbox exchanges encrypted notebooks both ways',
    () async {
      final key = AccountKey.generate();
      final first = PeerIdentity(newId(), 41721);
      final second = PeerIdentity(newId(), 41721);
      final revision = newId();
      final other = newId();
      var one = Notebook.empty()
          .revise(
            id: revision,
            author: first.device,
            basedOn: [],
            title: 'Чеклист',
            body: List.filled(80, '- [ ] Пройтись по парку').join('\n'),
            edit: NoteEdit.between(
              device: 'Планшет',
              beforeTitle: null,
              beforeBody: '',
              title: 'Чеклист',
              body: '',
            ),
          )
          .notebook;
      var two = Notebook.empty()
          .revise(
            id: other,
            author: second.device,
            basedOn: [],
            title: 'Маршрут',
            body: 'Через парк',
          )
          .notebook;
      final received = Completer<PeerIdentity?>();
      final mailbox = BluetoothMailbox((channel) async {
        received.complete(
          await receiveChannelSync(
            channel,
            key,
            () => two,
            (remote) async => two = two.merge(remote),
            identity: second,
            requireLatest: true,
          ),
        );
      });
      addTearDown(mailbox.close);
      expect(mailbox.read('central', 17), [bleDone]);
      expect(mailbox.write('central', Uint8List.fromList([bleStart])), isTrue);
      expect(mailbox.write('other', Uint8List.fromList([bleStart])), isFalse);
      var closed = false;
      Stream<Uint8List> replies() async* {
        while (!closed) {
          final bytes = mailbox.read('central', 17);
          if (bytes.first == bleDone) return;
          if (bytes.first == bleData) {
            yield Uint8List.sublistView(bytes, 1);
          } else {
            await Future<void>.delayed(Duration.zero);
          }
        }
      }

      final peer = await sendChannelSync(
        SyncChannel(
          incoming: replies(),
          write: (bytes) async {
            for (var start = 0; start < bytes.length; start += 19) {
              final packet = Uint8List.fromList([
                bleData,
                ...bytes.skip(start).take(19),
              ]);
              expect(mailbox.write('central', packet), isTrue);
            }
          },
          dispose: () => closed = true,
          compress: true,
        ),
        key,
        () => one,
        (remote) async => one = one.merge(remote),
        identity: first,
      );
      expect(peer?.device, second.device);
      expect((await received.future)?.device, first.device);
      expect(two.notes[revision]!.latest.edit?.device, 'Планшет');
      expect(one.notes[other]!.latest.body, 'Через парк');
      expect(one.encode(), two.encode());
    },
  );
}
