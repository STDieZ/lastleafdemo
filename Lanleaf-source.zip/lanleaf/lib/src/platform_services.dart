import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:path/path.dart' as path;

import 'keys.dart';
import 'notebook_store.dart';
import 'notes.dart';

const _platform = MethodChannel('com.lanleaf/local');

class LocalAccount {
  const LocalAccount(this.key, this.device, {this.storageTag});

  final AccountKey key;
  final String device;
  final String? storageTag;
}

class DeviceStorage {
  DeviceStorage._(this.directory, this._lock);

  static Future<DeviceStorage> open() async {
    final Directory directory;
    if (Platform.isWindows) {
      final base = Platform.environment['LOCALAPPDATA'];
      if (base == null || base.isEmpty) {
        throw const FileSystemException('LOCALAPPDATA is unavailable');
      }
      directory = Directory(path.join(base, 'Lanleaf'));
    } else {
      final support = await _platform.invokeMethod<String>(
        'applicationSupport',
      );
      if (support == null) {
        throw const FileSystemException('Application Support is unavailable');
      }
      directory = Directory(path.join(support, 'Lanleaf'));
    }
    await directory.create(recursive: true);
    if (Platform.isIOS || Platform.isMacOS) {
      await _platform.invokeMethod<void>('excludeBackup', directory.path);
    }
    final lock = await File(path.join(directory.path, 'app.lock'))
        .open(mode: FileMode.append);
    try {
      await lock.lock(FileLock.exclusive);
    } catch (_) {
      await lock.close();
      throw const StorageInUse();
    }
    return DeviceStorage._(directory, lock);
  }

  final Directory directory;
  final RandomAccessFile _lock;

  File get _windowsIdentity => File(path.join(directory.path, 'identity.v1'));

  Future<Directory> directoryFor(LocalAccount account) async {
    final tag = account.storageTag;
    if (tag == null) return directory;
    return Directory(path.join(directory.path, 'accounts', tag))
        .create(recursive: true);
  }

  Future<LocalAccount?> readAccount() async {
    Uint8List? data;
    if (Platform.isWindows) {
      if (await _windowsIdentity.exists()) {
        data = await _platform.invokeMethod<Uint8List>(
          'unprotect',
          await _windowsIdentity.readAsBytes(),
        );
        if (data == null) throw const FormatException('Missing local identity');
      }
    } else {
      data = await _platform.invokeMethod<Uint8List>('readIdentity');
    }
    if (data == null) {
      if (await File(path.join(directory.path, 'notebook.v1')).exists()) {
        throw const FormatException('Notebook key is unavailable');
      }
      return null;
    }
    final value = jsonDecode(utf8.decode(data));
    if (value is! Map<String, dynamic> ||
        value['key'] is! String ||
        !isId(value['device'])) {
      throw const FormatException('Invalid local identity');
    }
    final key = AccountKey.parse(value['key'] as String);
    final tag = value['storage'];
    if (tag != null && tag != await key.discoveryTag()) {
      throw const FormatException('Invalid local account directory');
    }
    return LocalAccount(
      key,
      value['device'] as String,
      storageTag: tag as String?,
    );
  }

  Future<void> writeAccount(LocalAccount account) async {
    final data = utf8.encode(
      jsonEncode({
        'key': account.key.code,
        'device': account.device,
        'storage': account.storageTag,
      }),
    );
    if (Platform.isWindows) {
      final sealed = await _platform.invokeMethod<Uint8List>('protect', data);
      if (sealed == null) {
        throw const FormatException('Local identity could not be protected');
      }
      await replaceFile(_windowsIdentity, sealed);
    } else {
      await _platform.invokeMethod<void>('writeIdentity', data);
    }
  }

  Future<void> close() => _lock.close();
}

class StorageInUse implements Exception {
  const StorageInUse();
}

class LanInterface {
  const LanInterface(this.address, this.prefix);

  final InternetAddress address;
  final int prefix;

  bool contains(InternetAddress remote) {
    if (remote.type != InternetAddressType.IPv4 || !isPrivateV4(remote)) {
      return false;
    }
    final mask = (0xffffffff << (32 - prefix)) & 0xffffffff;
    return (_number(address) & mask) == (_number(remote) & mask);
  }

  static int _number(InternetAddress address) =>
      address.rawAddress.fold(0, (value, octet) => (value << 8) | octet);

  static bool isPrivateV4(InternetAddress address) {
    if (address.type != InternetAddressType.IPv4) return false;
    final bytes = address.rawAddress;
    return bytes[0] == 10 ||
        (bytes[0] == 192 && bytes[1] == 168) ||
        (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) ||
        (bytes[0] == 169 && bytes[1] == 254);
  }
}

Future<List<LanInterface>> localInterfaces() async {
  final raw = await _platform.invokeListMethod<String>('localInterfaces') ?? [];
  return [for (final item in raw) ?_parseInterface(item)];
}

LanInterface? _parseInterface(String item) {
  final parts = item.split('/');
  if (parts.length != 2) return null;
  final address = InternetAddress.tryParse(parts[0]);
  final prefix = int.tryParse(parts[1]);
  if (address == null ||
      prefix == null ||
      prefix < 1 ||
      prefix > 32 ||
      !LanInterface.isPrivateV4(address)) {
    return null;
  }
  return LanInterface(address, prefix);
}
