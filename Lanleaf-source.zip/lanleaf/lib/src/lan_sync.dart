import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'bluetooth_sync.dart';
import 'bonjour_discovery.dart';
import 'device_settings.dart';
import 'notebook_store.dart';
import 'notes.dart';
import 'peers.dart';
import 'platform_services.dart';
import 'wire_sync.dart';

const _defaultSyncPort = 41721;
const _connectionTimeout = Duration(seconds: 3);
const _maxConnections = 6;

enum SyncTransport { lan, internet, bluetooth }

class LanSync extends ChangeNotifier {
  LanSync(
    this.account,
    this.store, {
    this._readInterfaces = localInterfaces,
    PeerDiscoveryFactory discovery = BonjourDiscovery.new,
    this._pollInterval = const Duration(seconds: 6),
    DeviceSettings? settings,
  }) : _discoveryFactory = discovery,
       deviceSettings = settings ?? DeviceSettings();

  final LocalAccount account;
  final NotebookStore store;
  final Future<List<LanInterface>> Function() _readInterfaces;
  final PeerDiscoveryFactory _discoveryFactory;
  final Duration _pollInterval;
  final DeviceSettings deviceSettings;

  late final Future<PeerHistory> _historyReady = PeerHistory.open(
    store.directory,
    account.key,
  );
  final _hints = <LanEndpoint>{};
  final _protocolHints = <LanEndpoint, (int, DateTime)>{};
  final _internetAttempts = <InternetEndpoint, DateTime>{};
  final _internetOutgoing = <InternetEndpoint, Future<void>>{};
  final _connections = <Socket>{};
  final _outgoing = <LanEndpoint, Future<void>>{};
  final _incoming = <Future<void>>{};
  PeerHistory? _history;
  ServerSocket? _server;
  ServerSocket? _ipv6Server;
  BluetoothSync? _bluetooth;
  Future<bool>? _bluetoothTransfer;
  bool _bluetoothAgain = false;
  PeerDiscovery? _discovery;
  List<LanInterface> _interfaces = const [];
  Timer? _timer;
  Timer? _debounce;
  Future<void>? _starting;
  Future<void>? _refreshing;
  Future<void>? _polling;
  Future<void>? _discoveryWork;
  Future<void>? _closing;
  DateTime? _discoveryStarted;
  String _name = '';
  String _group = '';
  bool _restartDiscovery = true;
  bool _runAgain = false;
  bool _closed = false;

  DateTime? lastSynced;
  SyncTransport? lastTransport;
  String bluetoothStatus = 'Обмен через Bluetooth выключен.';

  bool get bluetoothEnabled => deviceSettings.value.bluetooth;
  bool get bluetoothBusy => _bluetoothTransfer != null;

  int? get listeningPort => _server?.port ?? _ipv6Server?.port;
  InternetEndpoint? get publicEndpoint =>
      InternetEndpoint.tryParse(deviceSettings.value.internetAddress);
  List<InternetEndpoint> get internetPeers => _history?.internet ?? const [];

  String get deviceName {
    final name = deviceSettings.value.name;
    if (name.isNotEmpty) return name;
    final platform = switch (Platform.operatingSystem) {
      'ios' => 'iPhone/iPad',
      'macos' => 'Mac',
      'android' => 'Android',
      'linux' => 'Linux',
      'windows' => 'Windows',
      _ => 'Устройство',
    };
    return '$platform · ${account.device.substring(0, 4)}';
  }

  List<LanEndpoint> get _localEndpoints {
    final port = _server?.port;
    return port == null
        ? []
        : {
            for (final interface in _interfaces)
              LanEndpoint(interface.address, port),
          }.toList();
  }

  List<String> get addresses =>
      _localEndpoints.map((endpoint) => endpoint.toString()).toList();
  ConnectionCode get connectionCode =>
      ConnectionCode(account.key, _localEndpoints, [?publicEndpoint]);
  bool get hasNetwork => _interfaces.isNotEmpty;

  Future<void> start({
    List<LanEndpoint> hints = const [],
    List<InternetEndpoint> internet = const [],
  }) => _starting ??= _start(hints, internet);

  Future<void> _start(
    List<LanEndpoint> hints,
    List<InternetEndpoint> internet,
  ) async {
    _history = await _historyReady;
    if (_closed) return;
    await _rememberHints(hints);
    if (internet.isNotEmpty) await _history!.rememberInternet(internet);
    if (_closed) return;
    final tag = await account.key.discoveryTag();
    if (_closed) return;
    _group = 'lanleaf-$tag-';
    _name = '$_group${newId().substring(0, 8)}';
    store.addListener(_scheduleSync);
    deviceSettings.addListener(_deviceSettingsChanged);
    _timer = Timer.periodic(_pollInterval, (_) => unawaited(syncNow()));
    unawaited(refreshBluetooth());
    await syncNow();
  }

  Future<void> setBluetoothEnabled(bool enabled) async {
    await deviceSettings.update(bluetooth: enabled);
    if (enabled) {
      await refreshBluetooth(askPermission: true);
    } else {
      final previous = _bluetooth;
      _bluetooth = null;
      bluetoothStatus = 'Обмен через Bluetooth выключен.';
      _notify();
      await previous?.close();
    }
  }

  Future<void> refreshBluetooth({bool askPermission = false}) async {
    if (_closed || !bluetoothEnabled) return;
    final bluetooth = _bluetooth ??= BluetoothSync(
      account.key,
      store,
      () => _identity,
      () => _markSynced(SyncTransport.bluetooth),
    );
    try {
      final (canScan, canReceive) = await bluetooth.prepare(
        askPermission: askPermission,
      );
      if (_closed || _bluetooth != bluetooth) return;
      bluetoothStatus = switch ((canScan, canReceive)) {
        (true, true) => 'Готов к обмену после редактирования.',
        (true, false) => 'Можно подключиться к ближайшему устройству. Приём подключения недоступен.',
        (false, true) =>
          'Готов принимать обмен. Для поиска проверьте разрешение Bluetooth.',
        (false, false) =>
          'Bluetooth LE недоступен. Проверьте адаптер и разрешения.',
      };
    } catch (_) {
      if (_closed || _bluetooth != bluetooth) return;
      bluetoothStatus = 'Не удалось открыть Bluetooth LE.';
    }
    _notify();
  }

  Future<bool> syncOverBluetooth() {
    if (_closed || !bluetoothEnabled) return Future.value(false);
    if (_bluetoothTransfer case final ongoing?) {
      _bluetoothAgain = true;
      return ongoing;
    }
    return _bluetoothTransfer = _exchangeBluetooth().whenComplete(() {
      _bluetoothTransfer = null;
      _notify();
      if (_bluetoothAgain) {
        _bluetoothAgain = false;
        unawaited(syncOverBluetooth());
      }
    });
  }

  Future<bool> _exchangeBluetooth() async {
    await refreshBluetooth();
    if (_closed || !bluetoothEnabled) return false;
    bluetoothStatus = 'Поиск ближайших устройств…';
    _notify();
    final bool synced;
    try {
      synced = await _bluetooth?.exchange() ?? false;
    } catch (_) {
      if (!_closed && bluetoothEnabled) {
        bluetoothStatus = 'Обмен через Bluetooth прервался.';
      }
      return false;
    }
    if (!_closed && bluetoothEnabled) {
      bluetoothStatus = synced ? 'Обмен через Bluetooth завершён.' : 'Связь не установилась. Проверьте Bluetooth и откройте Last Leaf на обоих устройствах.';
    }
    return synced;
  }

  Future<void> addCode(ConnectionCode code) async {
    if (code.key.code != account.key.code) {
      throw const FormatException('Код относится к другому аккаунту.');
    }
    await _rememberHints(code.endpoints);
    if (code.internet.isNotEmpty) {
      await (await _historyReady).rememberInternet(code.internet);
      for (final endpoint in code.internet) {
        _internetAttempts.remove(endpoint);
      }
    }
    _restartDiscovery = true;
    _scheduleSync();
  }

  void _deviceSettingsChanged() {
    _scheduleSync();
    _notify();
  }

  Future<void> _rememberHints(List<LanEndpoint> hints) async {
    _hints.addAll(hints);
    try {
      await (await _historyReady).rememberHints(hints);
      _hints.removeAll(hints);
    } on FileSystemException {
      // Still try these addresses during this run if the history cannot be saved.
    }
  }

  void _scheduleSync() {
    if (_closed) return;
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      if (_polling == null) {
        unawaited(syncNow());
      } else {
        _runAgain = true;
      }
    });
  }

  Future<void> _refresh() =>
      _refreshing ??= _updateNetwork().whenComplete(() => _refreshing = null);

  Future<void> _updateNetwork() async {
    final List<LanInterface> interfaces;
    try {
      interfaces = await _readInterfaces();
    } catch (_) {
      _interfaces = const [];
      await _ensureListeners();
      return;
    }
    if (_closed) return;
    final before = _interfaces
        .map((e) => '${e.address.address}/${e.prefix}')
        .toSet();
    final after = interfaces
        .map((e) => '${e.address.address}/${e.prefix}')
        .toSet();
    _interfaces = [...interfaces]..sort((a, b) => b.prefix.compareTo(a.prefix));
    if (!setEquals(before, after)) {
      _restartDiscovery = true;
      _notify();
    }
    await _ensureListeners();
  }

  Future<void> _ensureListeners() async {
    if (_closed) return;
    if (_ipv6Server case final server? when publicEndpoint == null) {
      _ipv6Server = null;
      await server.close();
    }
    if (_server == null && (hasNetwork || publicEndpoint != null)) {
      await _bindIPv4();
    }
    if (!_closed && publicEndpoint != null && _ipv6Server == null) {
      final port = listeningPort;
      if (port != null) await _bindIPv6(port);
    }
  }

  Future<void> _bindIPv4() async {
    final history = await _historyReady;
    if (_closed) return;
    ServerSocket server;
    try {
      server = await ServerSocket.bind(
        InternetAddress.anyIPv4,
        history.port ?? _defaultSyncPort,
      );
    } on SocketException {
      try {
        server = await ServerSocket.bind(InternetAddress.anyIPv4, 0);
      } on SocketException {
        return;
      }
    }
    if (_closed) {
      await server.close();
      return;
    }
    _server = server;
    server.listen(
      _accept,
      onError: (Object _) {},
      onDone: () {
        if (_server == server) {
          _server = null;
          _restartDiscovery = true;
          _scheduleSync();
        }
      },
    );
    _notify();
    try {
      await history.rememberPort(server.port);
    } on FileSystemException {
      // The running listener can still serve requests.
    }
  }

  Future<void> _bindIPv6(int port) async {
    try {
      final server = await ServerSocket.bind(
        InternetAddress.anyIPv6,
        port,
        v6Only: true,
      );
      if (_closed || publicEndpoint == null) {
        await server.close();
        return;
      }
      _ipv6Server = server;
      server.listen(
        _accept,
        onError: (Object _) {},
        onDone: () {
          if (_ipv6Server == server) _ipv6Server = null;
        },
      );
    } on SocketException {
      // IPv4 and outbound connections still work on an IPv4-only system.
    }
  }

  void _updateDiscovery() {
    if (_closed || _discoveryWork != null || _name.isEmpty) return;
    final endpoints = _localEndpoints;
    if (endpoints.isEmpty && _discovery == null) return;
    final lastStart = _discoveryStarted;
    final retry =
        _discovery?.healthy != true &&
        (lastStart == null ||
            DateTime.now().difference(lastStart) > const Duration(seconds: 20));
    if (!_restartDiscovery && !retry) return;
    _restartDiscovery = false;
    _discoveryStarted = DateTime.now();
    _discoveryWork = _replaceDiscovery(endpoints).whenComplete(() {
      _discoveryWork = null;
      if (_restartDiscovery) _scheduleSync();
    });
  }

  Future<void> _replaceDiscovery(List<LanEndpoint> endpoints) async {
    final previous = _discovery;
    _discovery = null;
    try {
      if (previous != null) await previous.close();
      if (_closed || endpoints.isEmpty) return;
      final discovery = _discovery = _discoveryFactory(
        _name,
        _group,
        endpoints,
        _scheduleSync,
      );
      await discovery.start();
    } catch (_) {
      // A saved peer is still usable if the network blocks Bonjour.
    }
  }

  Future<void> syncNow({bool refreshDiscovery = false}) {
    if (_closed || _history == null) return Future.value();
    if (refreshDiscovery) {
      _restartDiscovery = true;
      _internetAttempts.clear();
      if (_polling != null) _runAgain = true;
    }
    return _polling ??= _poll().whenComplete(() {
      _polling = null;
      if (_runAgain && !_closed) {
        _runAgain = false;
        _scheduleSync();
      }
    });
  }

  Future<void> _poll() async {
    try {
      await _refresh();
      _updateDiscovery();
      if (_closed) return;
      await Future.wait([_pollLan(), _pollInternet()]);
    } catch (_) {
      _notify();
    }
  }

  Future<void> _pollLan() async {
    if (!hasNetwork) return;
    final now = DateTime.now();
    _protocolHints.removeWhere((_, hint) => !now.isBefore(hint.$2));
    final candidates =
        {...?_discovery?.endpoints, ...?_history?.endpoints, ..._hints}
            .where(
              (endpoint) =>
                  _route(endpoint.address) != null && !_isThisDevice(endpoint),
            )
            .toList();
    for (var i = 0; i < candidates.length && !_closed; i += _maxConnections) {
      await Future.wait(
        candidates.skip(i).take(_maxConnections).map((endpoint) async {
          try {
            await _connect(endpoint);
          } catch (_) {
            // Retain saved addresses for when the peer comes back online.
          }
        }),
      );
    }
  }

  Future<void> _pollInternet() async {
    final now = DateTime.now();
    await Future.wait(
      internetPeers
          .where((endpoint) {
            final tried = _internetAttempts[endpoint];
            return endpoint != publicEndpoint &&
                (tried == null ||
                    now.difference(tried) >= const Duration(seconds: 20));
          })
          .map((endpoint) async {
            try {
              await _connectInternet(endpoint);
            } catch (_) {}
          }),
    );
  }

  Future<void> syncWithInternet(String address) async {
    final endpoint = InternetEndpoint.tryParse(address);
    if (endpoint == null || endpoint == publicEndpoint) {
      throw const FormatException(
        'Укажите публичный адрес другого устройства и порт.',
      );
    }
    await _connectInternet(endpoint);
    await (await _historyReady).rememberInternet([endpoint]);
    _notify();
  }

  Future<void> forgetInternet(InternetEndpoint endpoint) async {
    await (await _historyReady).forgetInternet(endpoint);
    _internetAttempts.remove(endpoint);
    _notify();
  }

  Future<void> _connectInternet(InternetEndpoint endpoint) =>
      _internetOutgoing.putIfAbsent(
        endpoint,
        () =>
            _exchangeInternet(endpoint)
                .whenComplete(() => _internetOutgoing.remove(endpoint)),
      );

  Future<void> _exchangeInternet(InternetEndpoint endpoint) async {
    _internetAttempts[endpoint] = DateTime.now();
    final addresses = await endpoint.resolve();
    Socket? socket;
    for (final address in addresses.take(4)) {
      if (_closed) return;
      try {
        socket = await Socket.connect(
          address,
          endpoint.port,
          timeout: _connectionTimeout,
        );
        break;
      } on SocketException {
        // DNS can provide both IPv6 and IPv4, only one may be reachable.
      }
    }
    if (socket == null) {
      throw const SocketException('No reachable public address');
    }
    final peer = await _sendSocket(socket, protocol: 3);
    if (peer?.device == account.device) {
      throw const SocketException('Same device');
    }
    _markSynced(SyncTransport.internet);
  }

  LanInterface? _route(InternetAddress address) =>
      _interfaces.where((interface) => interface.contains(address)).firstOrNull;

  bool _isThisDevice(LanEndpoint endpoint) =>
      _server?.port == endpoint.port &&
      _interfaces.any(
        (interface) => interface.address.address == endpoint.address.address,
      );

  Future<void> syncWith(String target) async {
    final endpoint = LanEndpoint.tryParse(target);
    if (endpoint == null) {
      throw const FormatException(
        'Введите локальный адрес в формате 192.168.1.5:12345.',
      );
    }
    await _refresh();
    if (_route(endpoint.address) == null || _isThisDevice(endpoint)) {
      throw const FormatException(
        'Укажите адрес другого устройства в этой локальной сети.',
      );
    }
    await _connect(endpoint);
  }

  Future<void> _connect(LanEndpoint endpoint) => _outgoing.putIfAbsent(
    endpoint,
    () => _exchangeNotes(endpoint).whenComplete(() {
      _outgoing.remove(endpoint);
    }),
  );

  PeerIdentity get _identity =>
      PeerIdentity(account.device, listeningPort ?? _defaultSyncPort);

  Future<void> _exchangeNotes(LanEndpoint endpoint) async {
    var protocol = _protocolHints[endpoint]?.$1 ?? 3;
    while (true) {
      try {
        final peer = await _send(endpoint, protocol: protocol);
        if (protocol < 3 && !_protocolHints.containsKey(endpoint)) {
          _protocolHints[endpoint] = (
            protocol,
            DateTime.now().add(const Duration(minutes: 2)),
          );
        }
        await _rememberSuccessful(endpoint, peer);
        return;
      } on PeerNeedsLegacyProtocol {
        if (protocol == 1) rethrow;
        protocol--;
      }
    }
  }

  Future<PeerIdentity?> _send(
    LanEndpoint endpoint, {
    required int protocol,
  }) async {
    final route = _route(endpoint.address);
    if (_closed || route == null) {
      throw const SocketException('Not on the local subnet');
    }
    final socket = await Socket.connect(
      endpoint.address,
      endpoint.port,
      sourceAddress: route.address,
      timeout: _connectionTimeout,
    );
    return _sendSocket(socket, protocol: protocol);
  }

  Future<PeerIdentity?> _sendSocket(
    Socket socket, {
    required int protocol,
  }) async {
    if (_closed) {
      socket.destroy();
      throw const SocketException('Sync is stopped');
    }
    _connections.add(socket);
    try {
      return await sendSync(
        socket,
        account.key,
        () => store.notebook,
        store.merge,
        identity: protocol == 1 ? null : _identity,
        protocol: protocol,
      );
    } finally {
      _connections.remove(socket);
    }
  }

  void _accept(Socket socket) {
    final internet = _route(socket.remoteAddress) == null;
    if (_closed ||
        _incoming.length >= _maxConnections ||
        (internet &&
            (publicEndpoint == null ||
                !InternetEndpoint.isPublicAddress(socket.remoteAddress)))) {
      socket.destroy();
      return;
    }
    final request = _receive(socket, internet: internet);
    _incoming.add(request);
    unawaited(request.whenComplete(() => _incoming.remove(request)));
  }

  Future<void> _receive(Socket socket, {required bool internet}) async {
    final address = socket.remoteAddress;
    _connections.add(socket);
    try {
      final peer = await receiveSync(
        socket,
        account.key,
        () => store.notebook,
        store.merge,
        identity: _identity,
        requireLatest: internet,
      );
      if (internet) {
        _markSynced(SyncTransport.internet);
      } else if (peer == null) {
        _markSynced();
      } else {
        await _rememberSuccessful(LanEndpoint(address, peer.port), peer);
      }
    } catch (_) {
      // Unknown accounts, invalid frames, and disconnected peers are ignored.
    } finally {
      _connections.remove(socket);
    }
  }

  Future<void> _rememberSuccessful(
    LanEndpoint contacted, [
    PeerIdentity? peer,
  ]) async {
    if (_closed) return;
    final endpoint = peer == null
        ? contacted
        : LanEndpoint(contacted.address, peer.port);
    if ((peer == null || peer.device != account.device) &&
        !_isThisDevice(endpoint)) {
      final history = _history ?? await _historyReady;
      try {
        await history.rememberPeer(
          endpoint,
          device: peer?.device,
          contacted: contacted,
        );
      } on FileSystemException {
        _hints.add(endpoint);
        _markSynced();
        rethrow;
      }
      _hints.remove(endpoint);
      _hints.remove(contacted);
    }
    _markSynced();
  }

  void _markSynced([SyncTransport transport = SyncTransport.lan]) {
    if (_closed) return;
    lastSynced = DateTime.now();
    lastTransport = transport;
    _notify();
  }

  void _notify() {
    if (!_closed) notifyListeners();
  }

  Future<void> close() => _closing ??= _stop();

  Future<void> _stop() async {
    _closed = true;
    _timer?.cancel();
    _debounce?.cancel();
    store.removeListener(_scheduleSync);
    deviceSettings.removeListener(_deviceSettingsChanged);
    // Closing a socket can synchronously finish a request and remove it.
    final pending = <Future<void>>[
      ..._outgoing.values,
      ..._internetOutgoing.values,
      ..._incoming,
      ?_bluetoothTransfer,
      ?_polling,
      ?_refreshing,
      ?_discoveryWork,
      ?_starting,
    ];
    for (final socket in _connections.toList()) {
      socket.destroy();
    }
    await Future.wait(
      [
        if (_server case final server?) server.close(),
        if (_ipv6Server case final server?) server.close(),
        if (_bluetooth case final bluetooth?) bluetooth.close(),
        ...pending,
      ].map(
        (task) => task.then<void>((_) {}, onError: (Object _, StackTrace _) {}),
      ),
    );
    final discovery = _discovery;
    _discovery = null;
    if (discovery != null) await discovery.close();
    await store.idle;
  }

  @override
  void dispose() {
    unawaited(close());
    super.dispose();
  }
}
