import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/src/appearance_settings.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/platform_services.dart';
import 'package:lanleaf/src/profile_vault.dart';
import 'package:lanleaf/src/theme.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as path;

void main() {
  test(
    'appearance migrates into the encrypted vault and survives reopening',
    () async {
      final directory = await Directory.systemTemp.createTemp(
        'last-leaf-appearance-',
      );
      addTearDown(() => directory.delete(recursive: true));
      final file = File(path.join(directory.path, 'appearance.v1'));
      await file.writeAsString('{"palette":"orange","mode":"light"}');
      final previous = await readPreviousAppearance(directory);
      expect(previous, (palette: LeafPalette.orange, mode: ThemeMode.light));
      final vault = ProfileVault(directory);
      const password = 'настоящий локальный пароль';
      final session = await vault.create(
        account: LocalAccount(AccountKey.generate(), newId()),
        appearance: previous,
        password: password,
      );
      final settings = AppearanceSettings(
        value: session.appearance,
        save: session.setAppearance,
      );

      await Future.wait([
        settings.update(palette: LeafPalette.purple),
        settings.update(mode: ThemeMode.dark),
      ]);

      final reopened = (await vault.unlock(password)).appearance;
      expect(reopened.palette, LeafPalette.purple);
      expect(reopened.mode, ThemeMode.dark);
      final saved = await File(path.join(directory.path, 'profile.v1'))
          .readAsString();
      expect(
        (jsonDecode(saved) as Map<String, dynamic>).keys,
        unorderedEquals(['format', 'salt', 'password', 'recovery']),
      );
      expect(await file.readAsString(), '{"palette":"orange","mode":"light"}');
      final dark = buildLeafTheme(reopened.palette, Brightness.dark);
      final light = buildLeafTheme(reopened.palette, Brightness.light);
      expect(dark.brightness, Brightness.dark);
      expect(dark.colorScheme.surface, isNot(light.colorScheme.surface));
      expect(
        dark.colorScheme.primary,
        isNot(
          buildLeafTheme(
            LeafPalette.green,
            Brightness.dark,
          ).colorScheme.primary,
        ),
      );
    },
  );
}
