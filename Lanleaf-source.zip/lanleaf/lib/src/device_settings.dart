import 'package:characters/characters.dart';
import 'package:flutter/foundation.dart';

const minSidebarWidth = 226.0;
const maxSidebarWidth = 480.0;

typedef DevicePreferences = ({
  String name,
  String internetAddress,
  bool bluetooth,
  double sidebarWidth,
  bool sidebarVisible,
});

const defaultDevicePreferences = (
  name: '',
  internetAddress: '',
  bluetooth: false,
  sidebarWidth: 306.0,
  sidebarVisible: true,
);

String normalizeDeviceName(String text) {
  final clean = text
      .replaceAll(
        RegExp(r'[\u0000-\u001F\u007F\u202A-\u202E\u2066-\u2069]'),
        ' ',
      )
      .trim();
  return String.fromCharCodes(clean.runes.take(120)).characters
      .take(40)
      .toString()
      .trim();
}

DevicePreferences parseDevicePreferences(Object? value) {
  if (value is! Map<String, dynamic>) return defaultDevicePreferences;
  final width = value['sidebarWidth'];
  return (
    name: normalizeDeviceName(value['name'] is String ? value['name'] : ''),
    internetAddress: value['internetAddress'] is String
        ? (value['internetAddress'] as String).substring(
            0,
            (value['internetAddress'] as String).length.clamp(0, 260),
          )
        : '',
    bluetooth: value['bluetooth'] == true,
    sidebarWidth: width is num && width.isFinite
        ? width.toDouble().clamp(minSidebarWidth, maxSidebarWidth)
        : defaultDevicePreferences.sidebarWidth,
    sidebarVisible: value['sidebarVisible'] != false,
  );
}

Map<String, Object> encodeDevicePreferences(DevicePreferences value) => {
  'name': value.name,
  'internetAddress': value.internetAddress,
  'bluetooth': value.bluetooth,
  'sidebarWidth': value.sidebarWidth,
  'sidebarVisible': value.sidebarVisible,
};

class DeviceSettings extends ChangeNotifier {
  DeviceSettings({this._value = defaultDevicePreferences, this._save});

  DevicePreferences _value;
  final Future<void> Function(DevicePreferences value)? _save;
  Future<void> _pending = Future.value();
  bool _disposed = false;

  DevicePreferences get value => _value;

  Future<void> update({
    String? name,
    String? internetAddress,
    bool? bluetooth,
    double? sidebarWidth,
    bool? sidebarVisible,
  }) {
    final result = _pending.then((_) async {
      final next = (
        name: name == null ? _value.name : normalizeDeviceName(name),
        internetAddress: internetAddress ?? _value.internetAddress,
        bluetooth: bluetooth ?? _value.bluetooth,
        sidebarWidth: sidebarWidth == null
            ? _value.sidebarWidth
            : sidebarWidth.clamp(minSidebarWidth, maxSidebarWidth),
        sidebarVisible: sidebarVisible ?? _value.sidebarVisible,
      );
      if (next == _value) return;
      await _save?.call(next);
      _value = next;
      if (!_disposed) notifyListeners();
    });
    _pending = result.then<void>((_) {}, onError: (Object _, StackTrace _) {});
    return result;
  }

  @override
  void dispose() {
    _disposed = true;
    super.dispose();
  }
}
