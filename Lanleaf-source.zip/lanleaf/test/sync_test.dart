import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/notebook_store.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/platform_services.dart';
import 'package:lanleaf/src/wire_sync.dart';

void main() {
  test(
    'a code can be moved to another device without changing the account',
    () {
      final first = AccountKey.generate();
      final second = AccountKey.parse(
        '  ${first.code.substring(0, 8)}\n${first.code.substring(8)} ',
      );
      expect(first.code, hasLength(47));
      expect(second.code, first.code);
      expect(() => AccountKey.parse('bad code'), throwsFormatException);
    },
  );

  test('a local IPv4 route uses the actual interface prefix', () {
    final interface = LanInterface(InternetAddress('10.12.0.2'), 23);
    expect(interface.contains(InternetAddress('10.12.1.10')), isTrue);
    expect(interface.contains(InternetAddress('10.12.2.10')), isFalse);
    expect(interface.contains(InternetAddress('8.8.8.8')), isFalse);
  });

  test(
    'old encrypted notes load and pin changes merge without a text conflict',
    () async {
      final directory = await Directory.systemTemp.createTemp(
        'last-leaf-legacy-',
      );
      addTearDown(() => directory.delete(recursive: true));
      final key = AccountKey.generate();
      final id = newId();
      final first = newId();
      final other = newId();
      final legacy = utf8.encode(
        jsonEncode({
          'format': 1,
          'notes': {
            id: [
              {
                'author': first,
                'clock': {first: 1},
                'time': 1700000000000,
                'title': 'Старая заметка',
                'body': 'Уже была на устройстве',
                'deleted': false,
              },
            ],
          },
        }),
      );
      await File('${directory.path}/notebook.v1')
          .writeAsBytes(await seal(legacy, await key.diskKey()));
      final store = await NotebookStore.open(directory, key);
      expect(store.notebook.notes[id]!.latest.body, 'Уже была на устройстве');
      expect(store.notebook.isPinned(id), isFalse);
      final edited = store.notebook
          .revise(
            id: id,
            author: other,
            basedOn: store.notebook.notes[id]!.versions,
            title: 'Старая заметка',
            body: 'Текст изменился на втором устройстве',
          )
          .notebook;
      await store.setPinned(id, first, true);
      final pinned = store.notebook;
      await store.merge(edited);
      expect(store.notebook.isPinned(id), isTrue);
      expect(store.notebook.notes[id]!.versions, hasLength(1));
      expect(
        store.notebook.notes[id]!.latest.body,
        'Текст изменился на втором устройстве',
      );
      expect(
        Notebook.decode(store.notebook.encode(includePins: false)).isPinned(id),
        isFalse,
      );

      await store.setPinned(id, first, false);
      await store.merge(pinned);
      final reopened = await NotebookStore.open(directory, key);
      expect(reopened.notebook.isPinned(id), isFalse);
    },
  );

  test(
    'TCP sync persists both devices and preserves concurrent edits and deletes',
    () async {
      final directory = await Directory.systemTemp.createTemp('lanleaf-test-');
      addTearDown(() => directory.delete(recursive: true));
      final firstDirectory = await directory.createTemp('first');
      final secondDirectory = await directory.createTemp('second');
      final key = AccountKey.generate();
      final sameKey = AccountKey.parse(key.code);
      final first = await NotebookStore.open(firstDirectory, key);
      final second = await NotebookStore.open(secondDirectory, sameKey);
      final editorA = newId();
      final editorB = newId();
      final id = newId();
      final shared = await first.revise(
        id: id,
        author: editorA,
        basedOn: [],
        title: 'План',
        body: 'Начальный текст 🔑',
      );
      final encrypted = await File('${firstDirectory.path}/notebook.v1')
          .readAsBytes();
      expect(
        utf8.decode(encrypted, allowMalformed: true),
        isNot(contains('Начальный текст')),
      );
      await expectLater(
        NotebookStore.open(firstDirectory, AccountKey.generate()),
        throwsA(isA<Exception>()),
      );

      final initial = await exchange(first, key, second, sameKey);
      expect(initial, [null, null]);
      expect(second.notebook.notes[id]!.latest.body, 'Начальный текст 🔑');

      final unchanged = await exchange(
        first,
        key,
        second,
        sameKey,
        expectUnchanged: true,
      );
      expect(unchanged, [null, null]);

      // The two devices take their changes offline from the same version.
      await Future.wait([
        first.revise(
          id: id,
          author: editorA,
          basedOn: [shared],
          title: 'План',
          body: 'Первая правка',
        ),
        second.revise(
          id: id,
          author: editorB,
          basedOn: [shared],
          title: 'План',
          body: 'Вторая правка',
        ),
      ]);
      expect(await exchange(first, key, second, sameKey), [null, null]);
      final expected = ['Первая правка', 'Вторая правка'];
      for (final store in [first, second]) {
        expect(
          store.notebook.notes[id]!.versions.map((v) => v.body),
          unorderedEquals(expected),
        );
      }

      final conflict = first.notebook.notes[id]!;
      final resolved = await first.revise(
        id: id,
        author: editorA,
        basedOn: conflict.versions,
        title: 'План',
        body: 'Согласовано',
      );
      expect(await exchange(first, key, second, sameKey), [null, null]);
      expect(second.notebook.notes[id]!.versions.single.body, 'Согласовано');

      await first.revise(
        id: id,
        author: editorA,
        basedOn: [resolved],
        title: '',
        body: '',
        deleted: true,
      );
      await second.revise(
        id: id,
        author: editorB,
        basedOn: [resolved],
        title: 'План',
        body: 'Правка после удаления',
      );
      expect(await exchange(first, key, second, sameKey), [null, null]);
      final competing = second.notebook.notes[id]!;
      expect(competing.visible, isTrue);
      expect(competing.versions.any((v) => v.deleted), isTrue);
      await second.revise(
        id: id,
        author: editorB,
        basedOn: competing.versions,
        title: '',
        body: '',
        deleted: true,
      );
      expect(await exchange(first, key, second, sameKey), [null, null]);
      final reloaded = await NotebookStore.open(firstDirectory, key);
      expect(reloaded.notebook.notes[id]!.visible, isFalse);
      expect(
        reloaded.notebook.merge(Notebook.empty()).notes[id]!.visible,
        isFalse,
      );
    },
  );

  test('different accounts cannot exchange any notes', () async {
    final dir = await Directory.systemTemp.createTemp('lanleaf-auth-');
    addTearDown(() => dir.delete(recursive: true));
    final one = AccountKey.generate();
    final two = AccountKey.generate();
    final first = await NotebookStore.open(await dir.createTemp('first'), one);
    final second = await NotebookStore.open(
      await dir.createTemp('second'),
      two,
    );
    final id = newId();
    await first.revise(
      id: id,
      author: newId(),
      basedOn: [],
      title: 'Личная запись',
      body: 'Только для меня',
    );
    final failures = await exchange(
      first,
      one,
      second,
      two,
      expectUnchanged: true,
    );
    expect(failures.every((failure) => failure != null), isTrue);
    expect(second.notebook.notes, isEmpty);
    expect(first.notebook.notes[id]!.latest.body, 'Только для меня');
  });
}

Future<List<Object?>> exchange(
  NotebookStore first,
  AccountKey firstAccount,
  NotebookStore second,
  AccountKey secondAccount, {
  bool expectUnchanged = false,
}) async {
  final server = await ServerSocket.bind(InternetAddress.loopbackIPv4, 0);
  Future<Notebook> merge(NotebookStore store, Notebook incoming) {
    expect(expectUnchanged, isFalse, reason: 'No notebook should be sent');
    return store.merge(incoming);
  }

  Future<Object?> capture(Future<void> task) async {
    try {
      await task;
      return null;
    } catch (error) {
      return error;
    }
  }

  try {
    final incoming = capture(
      server.first.then(
        (socket) => receiveSync(
          socket,
          secondAccount,
          () => second.notebook,
          (notebook) => merge(second, notebook),
        ),
      ),
    );
    final client = await Socket.connect(
      InternetAddress.loopbackIPv4,
      server.port,
    );
    final outgoing = capture(
      sendSync(
        client,
        firstAccount,
        () => first.notebook,
        (notebook) => merge(first, notebook),
      ),
    );
    return await Future.wait([incoming, outgoing]);
  } finally {
    await server.close();
  }
}
