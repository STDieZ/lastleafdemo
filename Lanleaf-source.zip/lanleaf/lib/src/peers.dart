import 'dart:convert';
import 'dart:io';

import 'package:cryptography/cryptography.dart';
import 'package:path/path.dart' as path;

import 'keys.dart';
import 'notebook_store.dart';
import 'notes.dart';

const maxCodeEndpoints = 8;
const _maxSavedEndpoints = 24;

class LanEndpoint {
  const LanEndpoint(this.address, this.port);

  static LanEndpoint? tryParse(String text) {
    final parts = text.trim().split(':');
    if (parts.length != 2) return null;
    final address = InternetAddress.tryParse(parts[0]);
    final port = int.tryParse(parts[1]);
    if (address == null ||
        address.type != InternetAddressType.IPv4 ||
        port == null ||
        port < 1 ||
        port > 65535) {
      return null;
    }
    return LanEndpoint(address, port);
  }

  final InternetAddress address;
  final int port;

  @override
  String toString() => '${address.address}:$port';

  @override
  bool operator ==(Object other) =>
      other is LanEndpoint &&
      address.address == other.address.address &&
      port == other.port;

  @override
  int get hashCode => Object.hash(address.address, port);
}

class ConnectionCode {
  ConnectionCode(this.key, [Iterable<LanEndpoint> endpoints = const []])
    : endpoints = List.unmodifiable(endpoints.toSet().take(maxCodeEndpoints));

  factory ConnectionCode.parse(String input) {
    final segments = input
        .replaceAll(RegExp(r'[\s\u200B\u200E\u200F\uFEFF]'), '')
        .split('|');
    if (segments.length > maxCodeEndpoints + 1) {
      throw const FormatException('Too many addresses in the connection code');
    }
    final key = AccountKey.parse(segments.first);
    final endpoints = <LanEndpoint>[];
    for (final segment in segments.skip(1)) {
      final endpoint = LanEndpoint.tryParse(segment);
      if (endpoint == null) {
        throw const FormatException('Invalid address in the connection code');
      }
      endpoints.add(endpoint);
    }
    return ConnectionCode(key, endpoints);
  }

  final AccountKey key;
  final List<LanEndpoint> endpoints;

  String get text => [key.code, ...endpoints].join('|');
}

class PeerIdentity {
  const PeerIdentity(this.device, this.port);

  final String device;
  final int port;
}

class PeerHistory {
  PeerHistory._(this._file, this._key);

  static Future<PeerHistory> open(
    Directory directory,
    AccountKey account,
  ) async {
    final history = PeerHistory._(
      File(path.join(directory.path, 'peers.v1')),
      await account.peersKey(),
    );
    await history._load();
    return history;
  }

  final File _file;
  final SecretKey _key;
  Map<LanEndpoint, String?> _peers = {};
  int? _port;
  Future<void> _pending = Future.value();

  int? get port => _port;
  List<LanEndpoint> get endpoints => List.unmodifiable(_peers.keys);

  Future<void> _load() async {
    try {
      if (!await _file.exists() || await _file.length() > 8192) return;
      final value = jsonDecode(
        utf8.decode(await unseal(await _file.readAsBytes(), _key)),
      );
      if (value is! Map<String, dynamic> || value['peers'] is! List) return;
      final port = value['port'];
      if (port is int && port >= 1 && port <= 65535) _port = port;
      for (final entry in (value['peers'] as List).take(_maxSavedEndpoints)) {
        if (entry case [final String address, final Object? device]) {
          final endpoint = LanEndpoint.tryParse(address);
          if (endpoint != null && (device == null || isId(device))) {
            _peers[endpoint] = device as String?;
          }
        }
      }
    } on FormatException {
      // The history can be reconstructed by discovery.
    } on SecretBoxAuthenticationError {
      // A history from another account cannot supply addresses.
    } on FileSystemException {
      // The notebook is independent of the discovery history.
    }
  }

  Future<void> rememberPort(int port) => _queue(() async {
    if (port != _port) await _save(port, _peers);
  });

  Future<void> rememberHints(List<LanEndpoint> endpoints) => _queue(() async {
    final updated = Map.of(_peers);
    for (final endpoint in endpoints) {
      updated.putIfAbsent(endpoint, () => null);
    }
    if (updated.length != _peers.length) await _save(_port, updated);
  });

  Future<void> rememberPeer(
    LanEndpoint endpoint, {
    String? device,
    LanEndpoint? contacted,
  }) => _queue(() async {
    final existing = _peers[endpoint];
    final hasOldEndpoint =
        contacted != null &&
        contacted != endpoint &&
        _peers.containsKey(contacted);
    if (_peers.containsKey(endpoint) &&
        (device == null || existing == device) &&
        !hasOldEndpoint) {
      return;
    }
    final updated = Map.of(_peers);
    updated
      ..remove(contacted)
      ..removeWhere(
        (address, id) =>
            address == endpoint || (device != null && id == device),
      )
      ..[endpoint] = device ?? existing;
    await _save(_port, updated);
  });

  Future<void> _queue(Future<void> Function() write) {
    final result = _pending.then((_) => write());
    _pending = result.then<void>((_) {}, onError: (Object _, StackTrace _) {});
    return result;
  }

  Future<void> _save(int? port, Map<LanEndpoint, String?> peers) async {
    final kept = peers.entries.skip(
      peers.length > _maxSavedEndpoints ? peers.length - _maxSavedEndpoints : 0,
    );
    final result = Map.fromEntries(kept);
    final json = jsonEncode({
      'port': port,
      'peers': [
        for (final peer in result.entries) [peer.key.toString(), peer.value],
      ],
    });
    await replaceFile(_file, await seal(utf8.encode(json), _key));
    _port = port;
    _peers = result;
  }
}
