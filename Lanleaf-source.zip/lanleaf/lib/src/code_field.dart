import 'package:flutter/services.dart';
import 'package:material_ui/material_ui.dart';

class CodeField extends StatelessWidget {
  const CodeField({
    super.key,
    required this.controller,
    this.enabled = true,
    this.onSubmitted,
  });

  final TextEditingController controller;
  final bool enabled;
  final ValueChanged<String>? onSubmitted;

  @override
  Widget build(BuildContext context) => TextField(
    controller: controller,
    enabled: enabled,
    obscureText: true,
    autocorrect: false,
    enableSuggestions: false,
    enableIMEPersonalizedLearning: false,
    textInputAction: TextInputAction.done,
    onSubmitted: onSubmitted,
    decoration: InputDecoration(
      labelText: 'Код подключения',
      suffixIcon: IconButton(
        tooltip: 'Вставить из буфера',
        icon: const Icon(Icons.content_paste_rounded),
        onPressed: enabled
            ? () async {
                final data = await Clipboard.getData(Clipboard.kTextPlain);
                if (context.mounted && data?.text != null) {
                  controller.text = data!.text!;
                }
              }
            : null,
      ),
    ),
  );
}
