plugins {
    id("com.android.application")
    // The Flutter Gradle Plugin must be applied after the Android and Kotlin Gradle plugins.
    id("dev.flutter.flutter-gradle-plugin")
}

val signingStore = providers.environmentVariable("LAST_LEAF_SIGNING_STORE").orNull

android {
    namespace = "com.lanleaf.lanleaf"
    compileSdk = flutter.compileSdkVersion
    ndkVersion = flutter.ndkVersion

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    defaultConfig {
        applicationId = "com.lanleaf.lanleaf"
        minSdk = flutter.minSdkVersion
        targetSdk = flutter.targetSdkVersion
        versionCode = flutter.versionCode
        versionName = flutter.versionName
        manifestPlaceholders["appLabel"] = "Last Leaf"
    }

    signingConfigs {
        if (signingStore != null) {
            create("release") {
                val password = providers.environmentVariable("LAST_LEAF_SIGNING_PASSWORD").orNull
                require(!password.isNullOrEmpty()) { "Set LAST_LEAF_SIGNING_PASSWORD to sign the release APK." }
                storeFile = file(signingStore)
                storePassword = password
                keyAlias = providers.environmentVariable("LAST_LEAF_SIGNING_ALIAS").orNull ?: "last-leaf"
                keyPassword = providers.environmentVariable("LAST_LEAF_SIGNING_KEY_PASSWORD").orNull ?: password
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            manifestPlaceholders["appLabel"] = "Last Leaf (Debug)"
        }
        release {
            signingConfig = signingConfigs.findByName("release")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17
    }
}

flutter {
    source = "../.."
}
