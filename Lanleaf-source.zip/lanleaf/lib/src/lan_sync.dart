import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'bonjour_discovery.dart';
import 'notebook_store.dart';
import 'notes.dart';
import 'peers.dart';
import 'platform_services.dart';
import 'wire_sync.dart';

const _defaultSyncPort = 41721;
const _connectionTimeout = Duration(seconds: 3);
const _maxConnections = 6;

class LanSync extends ChangeNotifier {
  LanSync(
    this.account,
    this.store, {
    this._readInterfaces = localInterfaces,
    PeerDiscoveryFactory discovery = BonjourDiscovery.new,
    this._pollInterval = const Duration(seconds: 6),
  }) : _discoveryFactory = discovery;

  final LocalAccount account;
  final NotebookStore store;
  final Future<List<LanInterface>> Function() _readInterfaces;
  final PeerDiscoveryFactory _discoveryFactory;
  final Duration _pollInterval;

  late final Future<PeerHistory> _historyReady = PeerHistory.open(
    store.directory,
    account.key,
  );
  final _hints = <LanEndpoint>{};
  final _legacyUntil = <LanEndpoint, DateTime>{};
  final _connections = <Socket>{};
  final _outgoing = <LanEndpoint, Future<void>>{};
  final _incoming = <Future<void>>{};
  PeerHistory? _history;
  ServerSocket? _server;
  PeerDiscovery? _discovery;
  List<LanInterface> _interfaces = const [];
  Timer? _timer;
  Timer? _debounce;
  Future<void>? _starting;
  Future<void>? _refreshing;
  Future<void>? _polling;
  Future<void>? _discoveryWork;
  Future<void>? _closing;
  DateTime? _discoveryStarted;
  String _name = '';
  String _group = '';
  bool _restartDiscovery = true;
  bool _runAgain = false;
  bool _closed = false;

  DateTime? lastSynced;

  List<LanEndpoint> get _localEndpoints {
    final port = _server?.port;
    return port == null
        ? []
        : {
            for (final interface in _interfaces)
              LanEndpoint(interface.address, port),
          }.toList();
  }

  List<String> get addresses =>
      _localEndpoints.map((endpoint) => endpoint.toString()).toList();
  ConnectionCode get connectionCode =>
      ConnectionCode(account.key, _localEndpoints);
  bool get hasNetwork => _interfaces.isNotEmpty;

  Future<void> start({List<LanEndpoint> hints = const []}) =>
      _starting ??= _start(hints);

  Future<void> _start(List<LanEndpoint> hints) async {
    _history = await _historyReady;
    if (_closed) return;
    await _rememberHints(hints);
    if (_closed) return;
    final tag = await account.key.discoveryTag();
    if (_closed) return;
    _group = 'lanleaf-$tag-';
    _name = '$_group${newId().substring(0, 8)}';
    store.addListener(_scheduleSync);
    _timer = Timer.periodic(_pollInterval, (_) => unawaited(syncNow()));
    await syncNow();
  }

  Future<void> addCode(ConnectionCode code) async {
    if (code.key.code != account.key.code) {
      throw const FormatException('Код относится к другому аккаунту.');
    }
    await _rememberHints(code.endpoints);
    _restartDiscovery = true;
    _scheduleSync();
  }

  Future<void> _rememberHints(List<LanEndpoint> hints) async {
    _hints.addAll(hints);
    try {
      await (await _historyReady).rememberHints(hints);
      _hints.removeAll(hints);
    } on FileSystemException {
      // Still try these addresses during this run if the history cannot be saved.
    }
  }

  void _scheduleSync() {
    if (_closed) return;
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () {
      if (_polling == null) {
        unawaited(syncNow());
      } else {
        _runAgain = true;
      }
    });
  }

  Future<void> _refresh() =>
      _refreshing ??= _updateNetwork().whenComplete(() => _refreshing = null);

  Future<void> _updateNetwork() async {
    final interfaces = await _readInterfaces();
    if (_closed) return;
    final before = _interfaces
        .map((e) => '${e.address.address}/${e.prefix}')
        .toSet();
    final after = interfaces
        .map((e) => '${e.address.address}/${e.prefix}')
        .toSet();
    _interfaces = [...interfaces]..sort((a, b) => b.prefix.compareTo(a.prefix));
    if (!setEquals(before, after)) {
      _restartDiscovery = true;
      _notify();
    }
    if (!hasNetwork || _server != null) return;

    final history = await _historyReady;
    if (_closed) return;
    ServerSocket server;
    try {
      server = await ServerSocket.bind(
        InternetAddress.anyIPv4,
        history.port ?? _defaultSyncPort,
      );
    } on SocketException {
      server = await ServerSocket.bind(InternetAddress.anyIPv4, 0);
    }
    if (_closed) {
      await server.close();
      return;
    }
    _server = server;
    server.listen(
      _accept,
      onError: (Object _) {},
      onDone: () {
        if (_server == server) {
          _server = null;
          _restartDiscovery = true;
          _scheduleSync();
        }
      },
    );
    _notify();
    try {
      await history.rememberPort(server.port);
    } on FileSystemException {
      // The running listener can still serve requests.
    }
  }

  void _updateDiscovery() {
    if (_closed || _discoveryWork != null || _name.isEmpty) return;
    final endpoints = _localEndpoints;
    if (endpoints.isEmpty && _discovery == null) return;
    final lastStart = _discoveryStarted;
    final retry =
        _discovery?.healthy != true &&
        (lastStart == null ||
            DateTime.now().difference(lastStart) > const Duration(seconds: 20));
    if (!_restartDiscovery && !retry) return;
    _restartDiscovery = false;
    _discoveryStarted = DateTime.now();
    _discoveryWork = _replaceDiscovery(endpoints).whenComplete(() {
      _discoveryWork = null;
      if (_restartDiscovery) _scheduleSync();
    });
  }

  Future<void> _replaceDiscovery(List<LanEndpoint> endpoints) async {
    final previous = _discovery;
    _discovery = null;
    try {
      if (previous != null) await previous.close();
      if (_closed || endpoints.isEmpty) return;
      final discovery = _discovery = _discoveryFactory(
        _name,
        _group,
        endpoints,
        _scheduleSync,
      );
      await discovery.start();
    } catch (_) {
      // A saved peer is still usable if the network blocks Bonjour.
    }
  }

  Future<void> syncNow({bool refreshDiscovery = false}) {
    if (_closed || _history == null) return Future.value();
    if (refreshDiscovery) {
      _restartDiscovery = true;
      if (_polling != null) _runAgain = true;
    }
    return _polling ??= _poll().whenComplete(() {
      _polling = null;
      if (_runAgain && !_closed) {
        _runAgain = false;
        _scheduleSync();
      }
    });
  }

  Future<void> _poll() async {
    try {
      await _refresh();
      _updateDiscovery();
      if (_closed || !hasNetwork) return;
      final now = DateTime.now();
      _legacyUntil.removeWhere((_, until) => !now.isBefore(until));
      final candidates =
          {...?_discovery?.endpoints, ...?_history?.endpoints, ..._hints}
              .where(
                (endpoint) =>
                    _route(endpoint.address) != null &&
                    !_isThisDevice(endpoint),
              )
              .toList();
      for (var i = 0; i < candidates.length && !_closed; i += _maxConnections) {
        await Future.wait(
          candidates.skip(i).take(_maxConnections).map((endpoint) async {
            try {
              await _connect(endpoint);
            } catch (_) {
              // Retain saved addresses for when the peer comes back online.
            }
          }),
        );
      }
    } catch (_) {
      _notify();
    }
  }

  LanInterface? _route(InternetAddress address) =>
      _interfaces.where((interface) => interface.contains(address)).firstOrNull;

  bool _isThisDevice(LanEndpoint endpoint) =>
      _server?.port == endpoint.port &&
      _interfaces.any(
        (interface) => interface.address.address == endpoint.address.address,
      );

  Future<void> syncWith(String target) async {
    final endpoint = LanEndpoint.tryParse(target);
    if (endpoint == null) {
      throw const FormatException(
        'Введите локальный адрес в формате 192.168.1.5:12345.',
      );
    }
    await _refresh();
    if (_route(endpoint.address) == null || _isThisDevice(endpoint)) {
      throw const FormatException(
        'Укажите адрес другого устройства в этой локальной сети.',
      );
    }
    await _connect(endpoint);
  }

  Future<void> _connect(LanEndpoint endpoint) => _outgoing.putIfAbsent(
    endpoint,
    () => _exchangeNotes(endpoint).whenComplete(() {
      _outgoing.remove(endpoint);
    }),
  );

  PeerIdentity? get _identity {
    final port = _server?.port;
    return port == null ? null : PeerIdentity(account.device, port);
  }

  Future<void> _exchangeNotes(LanEndpoint endpoint) async {
    final PeerIdentity? peer;
    try {
      peer = await _send(
        endpoint,
        identity: _legacyUntil.containsKey(endpoint) ? null : _identity,
      );
    } on PeerNeedsLegacyProtocol {
      await _send(endpoint);
      _legacyUntil[endpoint] = DateTime.now().add(const Duration(minutes: 2));
      await _rememberSuccessful(endpoint);
      return;
    }
    await _rememberSuccessful(endpoint, peer);
  }

  Future<PeerIdentity?> _send(
    LanEndpoint endpoint, {
    PeerIdentity? identity,
  }) async {
    final route = _route(endpoint.address);
    if (_closed || route == null) {
      throw const SocketException('Not on the local subnet');
    }
    final socket = await Socket.connect(
      endpoint.address,
      endpoint.port,
      sourceAddress: route.address,
      timeout: _connectionTimeout,
    );
    if (_closed) {
      socket.destroy();
      throw const SocketException('Sync is stopped');
    }
    _connections.add(socket);
    try {
      return await sendSync(
        socket,
        account.key,
        () => store.notebook,
        store.merge,
        identity: identity,
      );
    } finally {
      _connections.remove(socket);
    }
  }

  void _accept(Socket socket) {
    if (_closed ||
        _incoming.length >= _maxConnections ||
        _route(socket.remoteAddress) == null) {
      socket.destroy();
      return;
    }
    final request = _receive(socket);
    _incoming.add(request);
    unawaited(request.whenComplete(() => _incoming.remove(request)));
  }

  Future<void> _receive(Socket socket) async {
    final address = socket.remoteAddress;
    _connections.add(socket);
    try {
      final peer = await receiveSync(
        socket,
        account.key,
        () => store.notebook,
        store.merge,
        identity: _identity,
      );
      if (peer == null) {
        _markSynced();
      } else {
        await _rememberSuccessful(LanEndpoint(address, peer.port), peer);
      }
    } catch (_) {
      // Unknown accounts, invalid frames, and disconnected peers are ignored.
    } finally {
      _connections.remove(socket);
    }
  }

  Future<void> _rememberSuccessful(
    LanEndpoint contacted, [
    PeerIdentity? peer,
  ]) async {
    if (_closed) return;
    final endpoint = peer == null
        ? contacted
        : LanEndpoint(contacted.address, peer.port);
    if ((peer == null || peer.device != account.device) &&
        !_isThisDevice(endpoint)) {
      final history = _history ?? await _historyReady;
      try {
        await history.rememberPeer(
          endpoint,
          device: peer?.device,
          contacted: contacted,
        );
      } on FileSystemException {
        _hints.add(endpoint);
        _markSynced();
        rethrow;
      }
      _hints.remove(endpoint);
      _hints.remove(contacted);
    }
    _markSynced();
  }

  void _markSynced() {
    lastSynced = DateTime.now();
    _notify();
  }

  void _notify() {
    if (!_closed) notifyListeners();
  }

  Future<void> close() => _closing ??= _stop();

  Future<void> _stop() async {
    _closed = true;
    _timer?.cancel();
    _debounce?.cancel();
    store.removeListener(_scheduleSync);
    // Closing a socket can synchronously finish a request and remove it.
    final pending = <Future<void>>[
      ..._outgoing.values,
      ..._incoming,
      ?_polling,
      ?_refreshing,
      ?_discoveryWork,
      ?_starting,
    ];
    for (final socket in _connections.toList()) {
      socket.destroy();
    }
    await Future.wait(
      [if (_server case final server?) server.close(), ...pending].map(
        (task) => task.then<void>((_) {}, onError: (Object _, StackTrace _) {}),
      ),
    );
    final discovery = _discovery;
    _discovery = null;
    if (discovery != null) await discovery.close();
    await store.idle;
  }

  @override
  void dispose() {
    unawaited(close());
    super.dispose();
  }
}
