import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/src/appearance_settings.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/platform_services.dart';
import 'package:lanleaf/src/profile_vault.dart';
import 'package:lanleaf/src/theme.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as path;

void main() {
  test('the local vault encrypts the account and rejects an incorrect password or code', () async {
    final directory = await Directory.systemTemp.createTemp(
      'last-leaf-profile-',
    );
    addTearDown(() => directory.delete(recursive: true));
    final vault = ProfileVault(directory);
    final account = LocalAccount(AccountKey.generate(), newId());
    const original = 'свой пароль на устройстве';
    const changed = 'другой пароль Last Leaf';
    await vault.create(
      account: account,
      appearance: defaultAppearance,
      password: original,
    );
    final file = File(path.join(directory.path, 'profile.v1'));
    final encrypted = await file.readAsString();
    expect(encrypted, isNot(contains(account.key.code)));
    expect(encrypted, isNot(contains(account.device)));
    expect(encrypted, isNot(contains(original)));
    expect(await vault.exists(), isTrue);

    await expectLater(
      vault.unlock('ошибочный пароль'),
      throwsA(isA<VaultAuthenticationFailed>()),
    );
    await expectLater(
      vault.resetPassword(AccountKey.generate(), changed),
      throwsA(isA<VaultAuthenticationFailed>()),
    );
    expect(await file.readAsString(), encrypted);

    final session = await vault.unlock(original);
    expect(session.account.key.code, account.key.code);
    expect(session.account.device, account.device);
    await session.setAppearance((
      palette: LeafPalette.purple,
      mode: ThemeMode.dark,
    ));

    final restored = await vault.resetPassword(account.key, changed);
    expect(restored.account.device, account.device);
    expect(restored.appearance, (
      palette: LeafPalette.purple,
      mode: ThemeMode.dark,
    ));
    await expectLater(
      vault.unlock(original),
      throwsA(isA<VaultAuthenticationFailed>()),
    );
    expect((await vault.unlock(changed)).account.key.code, account.key.code);
  });

  test('changing the account rewrites both local envelopes and keeps pending appearance edits', () async {
    final directory = await Directory.systemTemp.createTemp(
      'last-leaf-profile-switch-',
    );
    addTearDown(() => directory.delete(recursive: true));
    final original = LocalAccount(AccountKey.generate(), newId());
    final nextKey = AccountKey.generate();
    final next = LocalAccount(
      nextKey,
      original.device,
      storageTag: await nextKey.discoveryTag(),
    );
    final vault = ProfileVault(directory);
    const password = 'пароль на этом компьютере';
    final session = await vault.create(
      account: original,
      appearance: defaultAppearance,
      password: password,
    );

    await Future.wait([
      session.setAppearance((palette: LeafPalette.blue, mode: ThemeMode.dark)),
      session.setAccount(next),
    ]);
    final unlocked = await vault.unlock(password);
    expect(unlocked.account.key.code, nextKey.code);
    expect(unlocked.account.storageTag, next.storageTag);
    expect(unlocked.appearance.palette, LeafPalette.blue);
    await expectLater(
      vault.resetPassword(original.key, password),
      throwsA(isA<VaultAuthenticationFailed>()),
    );
    expect(
      (await vault.resetPassword(next.key, password)).account.device,
      original.device,
    );
  });
}
