import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:characters/characters.dart';

const maxNotebookBytes = 8 * 1024 * 1024;
const maxTitleLength = 160;
const maxBodyLength = 60000;

final _random = Random.secure();
final _idPattern = RegExp(r'^[a-f0-9]{32}$');

Uint8List randomBytes(int length) =>
    Uint8List.fromList(List.generate(length, (_) => _random.nextInt(256)));

String newId() =>
    randomBytes(16)
        .map((byte) => byte.toRadixString(16).padLeft(2, '0'))
        .join();

bool isId(Object? value) => value is String && _idPattern.hasMatch(value);

class NoteVersion {
  NoteVersion({
    required this.author,
    required Map<String, int> clock,
    required this.time,
    required this.title,
    required this.body,
    required this.deleted,
  }) : clock = Map.unmodifiable(clock);

  factory NoteVersion.fromJson(Object? value) {
    if (value is! Map<String, dynamic>) throw const FormatException();
    final author = value['author'];
    final clock = value['clock'];
    final time = value['time'];
    final title = value['title'];
    final body = value['body'];
    final deleted = value['deleted'];
    if (author is! String ||
        !isId(author) ||
        clock is! Map<String, dynamic> ||
        !clock.containsKey(author) ||
        clock.entries.any(
          (e) =>
              !isId(e.key) ||
              e.value is! int ||
              (e.value as int) < 1 ||
              (e.value as int) > 0x7fffffff,
        ) ||
        time is! int ||
        time < 0 ||
        time > 8640000000000000 ||
        title is! String ||
        title.characters.length > maxTitleLength ||
        body is! String ||
        body.characters.length > maxBodyLength ||
        deleted is! bool ||
        (deleted && (title.isNotEmpty || body.isNotEmpty))) {
      throw const FormatException('Invalid note revision');
    }
    return NoteVersion(
      author: author,
      clock: clock.cast<String, int>(),
      time: time,
      title: title,
      body: body,
      deleted: deleted,
    );
  }

  final String author;
  final Map<String, int> clock;
  final int time;
  final String title;
  final String body;
  final bool deleted;

  String get id => '$author:${clock[author]}';

  bool supersedes(NoteVersion other) {
    for (final entry in other.clock.entries) {
      if ((clock[entry.key] ?? 0) < entry.value) return false;
    }
    return clock.entries.any(
      (entry) => entry.value > (other.clock[entry.key] ?? 0),
    );
  }

  bool matches(NoteVersion other) =>
      id == other.id &&
      time == other.time &&
      title == other.title &&
      body == other.body &&
      deleted == other.deleted &&
      clock.length == other.clock.length &&
      clock.entries.every((e) => other.clock[e.key] == e.value);

  Map<String, Object> toJson() => {
    'author': author,
    'clock': {for (final key in clock.keys.toList()..sort()) key: clock[key]},
    'time': time,
    'title': title,
    'body': body,
    'deleted': deleted,
  };
}

class Note {
  const Note(this.id, this.versions);

  final String id;
  final List<NoteVersion> versions;

  bool get visible => versions.any((v) => !v.deleted);
  bool get hasConflict => versions.length > 1;
  NoteVersion get latest => versions.firstWhere((v) => !v.deleted);
}

class Notebook {
  Notebook.empty() : notes = const {};

  Notebook._(Map<String, Note> notes) : notes = Map.unmodifiable(notes);

  factory Notebook.decode(List<int> bytes) {
    if (bytes.length > maxNotebookBytes) throw const NotebookFull();
    final value = jsonDecode(utf8.decode(bytes));
    if (value is! Map<String, dynamic> ||
        value['format'] != 1 ||
        value['notes'] is! Map<String, dynamic>) {
      throw const FormatException('Invalid notebook');
    }
    final notes = <String, Note>{};
    for (final entry in (value['notes'] as Map<String, dynamic>).entries) {
      final versions = entry.value;
      if (!isId(entry.key) || versions is! List || versions.isEmpty) {
        throw const FormatException('Invalid note');
      }
      final frontier = _mergeVersions(
        const [],
        versions.map(NoteVersion.fromJson),
      );
      notes[entry.key] = Note(entry.key, List.unmodifiable(frontier));
    }
    return Notebook._(notes);
  }

  final Map<String, Note> notes;

  late final Uint8List _encoded = _encodeCanonical();

  Uint8List encode() => _encoded;

  Uint8List _encodeCanonical() {
    final bytes = utf8.encode(
      jsonEncode({
        'format': 1,
        'notes': {
          for (final id in notes.keys.toList()..sort()) id: notes[id]!.versions,
        },
      }),
    );
    if (bytes.length > maxNotebookBytes) throw const NotebookFull();
    return bytes.asUnmodifiableView();
  }

  Notebook merge(Notebook incoming) {
    final notes = Map.of(this.notes);
    var changed = false;
    for (final note in incoming.notes.values) {
      final before = notes[note.id]?.versions ?? const <NoteVersion>[];
      final after = _mergeVersions(before, note.versions);
      if (before.length != after.length ||
          List.generate(
            before.length,
            (i) => i,
          ).any((i) => before[i].id != after[i].id)) {
        notes[note.id] = Note(note.id, List.unmodifiable(after));
        changed = true;
      }
    }
    return changed ? Notebook._(notes) : this;
  }

  ({Notebook notebook, NoteVersion version}) revise({
    required String id,
    required String author,
    required Iterable<NoteVersion> basedOn,
    required String title,
    required String body,
    bool deleted = false,
  }) {
    if (title.characters.length > maxTitleLength ||
        body.characters.length > maxBodyLength) {
      throw const NotebookFull();
    }
    final clock = <String, int>{};
    for (final version in basedOn) {
      for (final entry in version.clock.entries) {
        clock.update(
          entry.key,
          (old) => max(old, entry.value),
          ifAbsent: () => entry.value,
        );
      }
    }
    final versions = notes[id]?.versions ?? const <NoteVersion>[];
    var count = clock[author] ?? 0;
    for (final version in versions) {
      count = max(count, version.clock[author] ?? 0);
    }
    clock[author] = count + 1;
    final version = NoteVersion(
      author: author,
      clock: clock,
      time: DateTime.now().millisecondsSinceEpoch,
      title: deleted ? '' : title,
      body: deleted ? '' : body,
      deleted: deleted,
    );
    return (
      notebook: Notebook._({
        ...notes,
        id: Note(id, List.unmodifiable(_mergeVersions(versions, [version]))),
      }),
      version: version,
    );
  }
}

List<NoteVersion> _mergeVersions(
  List<NoteVersion> before,
  Iterable<NoteVersion> additions,
) {
  final versions = List.of(before);
  for (final incoming in additions) {
    final same = versions
        .where((version) => version.id == incoming.id)
        .firstOrNull;
    if (same != null) {
      if (!same.matches(incoming)) {
        throw const FormatException('Revision identifier reused');
      }
      continue;
    }
    if (versions.any((version) => version.supersedes(incoming))) continue;
    versions.removeWhere(incoming.supersedes);
    versions.add(incoming);
  }
  versions.sort((a, b) {
    if (a.deleted != b.deleted) return a.deleted ? 1 : -1;
    final time = b.time.compareTo(a.time);
    return time != 0 ? time : a.id.compareTo(b.id);
  });
  return versions;
}

class NotebookFull implements Exception {
  const NotebookFull();
}
