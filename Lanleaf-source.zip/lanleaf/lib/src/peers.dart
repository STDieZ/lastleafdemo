import 'dart:convert';
import 'dart:io';

import 'package:cryptography/cryptography.dart';
import 'package:path/path.dart' as path;

import 'keys.dart';
import 'notebook_store.dart';
import 'notes.dart';

const maxCodeEndpoints = 8;
const maxInternetEndpoints = 4;
const _maxSavedEndpoints = 24;

class LanEndpoint {
  const LanEndpoint(this.address, this.port);

  static LanEndpoint? tryParse(String text) {
    final parts = text.trim().split(':');
    if (parts.length != 2) return null;
    final address = InternetAddress.tryParse(parts[0]);
    final port = int.tryParse(parts[1]);
    if (address == null ||
        address.type != InternetAddressType.IPv4 ||
        port == null ||
        port < 1 ||
        port > 65535) {
      return null;
    }
    return LanEndpoint(address, port);
  }

  final InternetAddress address;
  final int port;

  @override
  String toString() => '${address.address}:$port';

  @override
  bool operator ==(Object other) =>
      other is LanEndpoint &&
      address.address == other.address.address &&
      port == other.port;

  @override
  int get hashCode => Object.hash(address.address, port);
}

class InternetEndpoint {
  const InternetEndpoint._(this.host, this.port);

  static InternetEndpoint? tryParse(String text) {
    final value = text.trim();
    final separator = value.lastIndexOf(':');
    if (separator < 1 || value.length > 260) return null;
    var host = value.substring(0, separator).toLowerCase();
    final port = int.tryParse(value.substring(separator + 1));
    if (port == null || port < 1 || port > 65535) return null;
    if (host.startsWith('[') && host.endsWith(']')) {
      host = host.substring(1, host.length - 1);
      if (host.contains('%')) return null;
      final address = InternetAddress.tryParse(host);
      if (address == null ||
          address.type != InternetAddressType.IPv6 ||
          !isPublicAddress(address)) {
        return null;
      }
      return InternetEndpoint._(address.address, port);
    }
    final address = InternetAddress.tryParse(host);
    if (address != null) {
      return address.type == InternetAddressType.IPv4 &&
              isPublicAddress(address)
          ? InternetEndpoint._(address.address, port)
          : null;
    }
    final labels = host.split('.');
    final labelPattern = RegExp(r'^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$');
    if (host.length > 253 ||
        labels.length < 2 ||
        !labels.every(labelPattern.hasMatch) ||
        !RegExp(r'[a-z]').hasMatch(labels.last) ||
        const [
          'local',
          'localhost',
          'internal',
          'home',
        ].contains(labels.last)) {
      return null;
    }
    return InternetEndpoint._(host, port);
  }

  static bool isPublicAddress(InternetAddress address) {
    final bytes = address.rawAddress;
    if (address.type == InternetAddressType.IPv6) {
      return (bytes[0] & 0xe0) == 0x20;
    }
    final first = bytes[0];
    final second = bytes[1];
    return first != 0 &&
        first != 10 &&
        first != 127 &&
        first < 224 &&
        !(first == 100 && second >= 64 && second <= 127) &&
        !(first == 169 && second == 254) &&
        !(first == 172 && second >= 16 && second <= 31) &&
        !(first == 192 && second == 168) &&
        !(first == 198 && (second == 18 || second == 19));
  }

  final String host;
  final int port;

  Future<List<InternetAddress>> resolve() async {
    final literal = InternetAddress.tryParse(host);
    final addresses = literal == null
        ? await InternetAddress.lookup(host).timeout(const Duration(seconds: 4))
        : [literal];
    return addresses.where(isPublicAddress).toList();
  }

  @override
  String toString() => host.contains(':') ? '[$host]:$port' : '$host:$port';

  @override
  bool operator ==(Object other) =>
      other is InternetEndpoint && host == other.host && port == other.port;

  @override
  int get hashCode => Object.hash(host, port);
}

class ConnectionCode {
  ConnectionCode(
    this.key, [
    Iterable<LanEndpoint> endpoints = const [],
    Iterable<InternetEndpoint> internet = const [],
  ]) : endpoints = List.unmodifiable(endpoints.toSet().take(maxCodeEndpoints)),
       internet = List.unmodifiable(
         internet.toSet().take(maxInternetEndpoints),
       );

  factory ConnectionCode.parse(String input) {
    final segments = input
        .replaceAll(RegExp(r'[\s\u200B\u200E\u200F\uFEFF]'), '')
        .split('|');
    if (segments.length > maxCodeEndpoints + maxInternetEndpoints + 1) {
      throw const FormatException('Too many addresses in the connection code');
    }
    final key = AccountKey.parse(segments.first);
    final endpoints = <LanEndpoint>[];
    final internet = <InternetEndpoint>[];
    for (final segment in segments.skip(1)) {
      if (segment.startsWith('wan=')) {
        final endpoint = InternetEndpoint.tryParse(segment.substring(4));
        if (endpoint == null || internet.length >= maxInternetEndpoints) {
          throw const FormatException(
            'Invalid public address in the connection code',
          );
        }
        internet.add(endpoint);
        continue;
      }
      final endpoint = LanEndpoint.tryParse(segment);
      if (endpoint == null || endpoints.length >= maxCodeEndpoints) {
        throw const FormatException('Invalid address in the connection code');
      }
      endpoints.add(endpoint);
    }
    return ConnectionCode(key, endpoints, internet);
  }

  final AccountKey key;
  final List<LanEndpoint> endpoints;
  final List<InternetEndpoint> internet;

  String get text => [
    key.code,
    ...endpoints,
    for (final endpoint in internet) 'wan=$endpoint',
  ].join('|');
}

class PeerIdentity {
  const PeerIdentity(this.device, this.port);

  final String device;
  final int port;
}

class PeerHistory {
  PeerHistory._(this._file, this._key);

  static Future<PeerHistory> open(
    Directory directory,
    AccountKey account,
  ) async {
    final history = PeerHistory._(
      File(path.join(directory.path, 'peers.v1')),
      await account.peersKey(),
    );
    await history._load();
    return history;
  }

  final File _file;
  final SecretKey _key;
  Map<LanEndpoint, String?> _peers = {};
  Set<InternetEndpoint> _internet = {};
  int? _port;
  Future<void> _pending = Future.value();

  int? get port => _port;
  List<LanEndpoint> get endpoints => List.unmodifiable(_peers.keys);
  List<InternetEndpoint> get internet => List.unmodifiable(_internet);

  Future<void> _load() async {
    try {
      if (!await _file.exists() || await _file.length() > 8192) return;
      final value = jsonDecode(
        utf8.decode(await unseal(await _file.readAsBytes(), _key)),
      );
      if (value is! Map<String, dynamic> || value['peers'] is! List) return;
      final port = value['port'];
      if (port is int && port >= 1 && port <= 65535) _port = port;
      if (value['internet'] case final List<dynamic> endpoints) {
        _internet = {
          for (final address in endpoints.whereType<String>().take(
            maxInternetEndpoints,
          ))
            ?InternetEndpoint.tryParse(address),
        };
      }
      for (final entry in (value['peers'] as List).take(_maxSavedEndpoints)) {
        if (entry case [final String address, final Object? device]) {
          final endpoint = LanEndpoint.tryParse(address);
          if (endpoint != null && (device == null || isId(device))) {
            _peers[endpoint] = device as String?;
          }
        }
      }
    } on FormatException {
      // The history can be reconstructed by discovery.
    } on SecretBoxAuthenticationError {
      // A history from another account cannot supply addresses.
    } on FileSystemException {
      // The notebook is independent of the discovery history.
    }
  }

  Future<void> rememberPort(int port) => _queue(() async {
    if (port != _port) await _save(port, _peers);
  });

  Future<void> rememberHints(List<LanEndpoint> endpoints) => _queue(() async {
    final updated = Map.of(_peers);
    for (final endpoint in endpoints) {
      updated.putIfAbsent(endpoint, () => null);
    }
    if (updated.length != _peers.length) await _save(_port, updated);
  });

  Future<void> rememberInternet(Iterable<InternetEndpoint> endpoints) =>
      _queue(() async {
        final combined = {..._internet, ...endpoints}.toList();
        final kept = combined
            .skip(
              combined.length > maxInternetEndpoints
                  ? combined.length - maxInternetEndpoints
                  : 0,
            )
            .toSet();
        if (kept.length != _internet.length || !_internet.containsAll(kept)) {
          await _save(_port, _peers, internet: kept);
        }
      });

  Future<void> forgetInternet(InternetEndpoint endpoint) => _queue(() async {
    if (_internet.contains(endpoint)) {
      await _save(_port, _peers, internet: {..._internet}..remove(endpoint));
    }
  });

  Future<void> rememberPeer(
    LanEndpoint endpoint, {
    String? device,
    LanEndpoint? contacted,
  }) => _queue(() async {
    final existing = _peers[endpoint];
    final hasOldEndpoint =
        contacted != null &&
        contacted != endpoint &&
        _peers.containsKey(contacted);
    if (_peers.containsKey(endpoint) &&
        (device == null || existing == device) &&
        !hasOldEndpoint) {
      return;
    }
    final updated = Map.of(_peers);
    updated
      ..remove(contacted)
      ..removeWhere(
        (address, id) =>
            address == endpoint || (device != null && id == device),
      )
      ..[endpoint] = device ?? existing;
    await _save(_port, updated);
  });

  Future<void> _queue(Future<void> Function() write) {
    final result = _pending.then((_) => write());
    _pending = result.then<void>((_) {}, onError: (Object _, StackTrace _) {});
    return result;
  }

  Future<void> _save(
    int? port,
    Map<LanEndpoint, String?> peers, {
    Set<InternetEndpoint>? internet,
  }) async {
    final kept = peers.entries.skip(
      peers.length > _maxSavedEndpoints ? peers.length - _maxSavedEndpoints : 0,
    );
    final result = Map.fromEntries(kept);
    final json = jsonEncode({
      'port': port,
      'peers': [
        for (final peer in result.entries) [peer.key.toString(), peer.value],
      ],
      'internet': [for (final peer in internet ?? _internet) peer.toString()],
    });
    await replaceFile(_file, await seal(utf8.encode(json), _key));
    _port = port;
    _peers = result;
    _internet = internet ?? _internet;
  }
}
