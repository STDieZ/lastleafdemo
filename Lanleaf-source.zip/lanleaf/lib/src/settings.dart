import 'package:cryptography/cryptography.dart';
import 'package:flutter/services.dart';
import 'package:material_ui/material_ui.dart';

import 'appearance_settings.dart';
import 'code_field.dart';
import 'lan_sync.dart';
import 'notes.dart';
import 'peers.dart';
import 'theme.dart';

enum _SettingsPane { sync, appearance }

class SettingsDialog extends StatefulWidget {
  const SettingsDialog({
    super.key,
    required this.sync,
    required this.appearance,
  });

  final LanSync sync;
  final AppearanceSettings appearance;

  @override
  State<SettingsDialog> createState() => _SettingsDialogState();
}

class _SettingsDialogState extends State<SettingsDialog> {
  final _target = TextEditingController();
  _SettingsPane _pane = _SettingsPane.sync;
  bool _showCode = false;
  bool _busy = false;
  String? _feedback;
  bool _failed = false;

  void _showFeedback(String message, {bool failed = false}) {
    if (!mounted) return;
    setState(() {
      _feedback = message;
      _failed = failed;
    });
  }

  Future<void> _connect() async {
    setState(() {
      _busy = true;
      _feedback = null;
    });
    try {
      await widget.sync.syncWith(_target.text);
      if (mounted) _target.clear();
      _showFeedback(
        'Устройство запомнено. Дальше обмен будет идти автоматически.',
      );
    } catch (error) {
      _showFeedback(switch (error) {
        FormatException() => error.message,
        NotebookFull() => 'Недостаточно места в хранилище заметок.',
        SecretBoxAuthenticationError() => 'На устройствах разные аккаунты. Введите код подключения другого устройства.',
        _ => 'Не удалось подключиться. Проверьте адрес и откройте Last Leaf на обоих устройствах.',
      }, failed: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _enterCode() async {
    final code = await showDialog<ConnectionCode>(
      context: context,
      builder: (context) => const _EnterCodeDialog(),
    );
    if (!mounted || code == null) return;
    if (code.key.code != widget.sync.account.key.code) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Подключить другой аккаунт?'),
          content: const Text(
            'Заметки с этого устройства будут добавлены в аккаунт из кода '
            'и станут доступны всем его устройствам после синхронизации.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Подключить'),
            ),
          ],
        ),
      );
      if (!mounted || confirmed != true) return;
    }
    Navigator.pop(context, code);
  }

  Future<void> _setAppearance({LeafPalette? palette, ThemeMode? mode}) async {
    try {
      await widget.appearance.update(palette: palette, mode: mode);
    } catch (_) {
      _showFeedback('Не удалось сохранить оформление.', failed: true);
    }
  }

  @override
  void dispose() {
    _target.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AlertDialog(
      title: const Text('Настройки'),
      scrollable: true,
      content: SizedBox(
        width: 430,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Wrap(
              spacing: 8,
              children: [
                for (final (pane, label) in [
                  (_SettingsPane.sync, 'Синхронизация'),
                  (_SettingsPane.appearance, 'Оформление'),
                ])
                  ChoiceChip(
                    label: Text(label),
                    selected: _pane == pane,
                    onSelected: (_) => setState(() {
                      _pane = pane;
                      _feedback = null;
                      _failed = false;
                    }),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            if (_pane == _SettingsPane.sync)
              ListenableBuilder(listenable: widget.sync, builder: _network)
            else
              ListenableBuilder(
                listenable: widget.appearance,
                builder: _appearance,
              ),
            if (_feedback != null) ...[
              const SizedBox(height: 8),
              Semantics(
                liveRegion: true,
                child: Text(
                  _feedback!,
                  style: TextStyle(
                    color: _failed
                        ? theme.colorScheme.error
                        : theme.colorScheme.onSurface,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Готово'),
        ),
      ],
    );
  }

  Widget _network(BuildContext context, Widget? _) {
    final theme = Theme.of(context);
    final addresses = widget.sync.addresses;
    final code = widget.sync.connectionCode.text;
    final last = widget.sync.lastSynced;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Подключение по коду', style: theme.textTheme.titleMedium),
        const SizedBox(height: 5),
        const Text(
          'Откройте Last Leaf на обоих устройствах в одной сети Wi‑Fi. '
          'Код даёт доступ к заметкам аккаунта.',
        ),
        if (_showCode) ...[
          const SizedBox(height: 8),
          SelectableText(code, style: const TextStyle(fontFamily: 'monospace')),
        ],
        Wrap(
          spacing: 4,
          children: [
            TextButton.icon(
              onPressed: _showCode
                  ? () async {
                      await Clipboard.setData(ClipboardData(text: code));
                      _showFeedback('Код скопирован.');
                    }
                  : () => setState(() => _showCode = true),
              icon: Icon(
                _showCode ? Icons.copy_rounded : Icons.visibility_outlined,
                size: 18,
              ),
              label: Text(_showCode ? 'Скопировать код' : 'Показать код'),
            ),
            TextButton.icon(
              onPressed: _busy ? null : _enterCode,
              icon: const Icon(Icons.link_rounded, size: 18),
              label: const Text('Ввести код'),
            ),
          ],
        ),
        const Divider(height: 24),
        Text('Локальная сеть', style: theme.textTheme.titleMedium),
        const SizedBox(height: 6),
        Text(
          last == null
              ? 'Ожидаем устройства с этим кодом.'
              : 'Последний обмен в ${TimeOfDay.fromDateTime(last).format(context)}',
        ),
        const SizedBox(height: 8),
        if (addresses.isEmpty)
          const Text('Локальный адрес пока недоступен.')
        else ...[
          const Text('Адрес этого устройства'),
          for (final address in addresses) SelectableText(address),
        ],
        const SizedBox(height: 12),
        TextField(
          controller: _target,
          enabled: !_busy,
          autocorrect: false,
          onSubmitted: _busy ? null : (_) => _connect(),
          decoration: const InputDecoration(
            labelText: 'Адрес другого устройства',
            hintText: '192.168.1.5:41721',
          ),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: _busy ? null : _connect,
          child: Text(_busy ? 'Подключение…' : 'Подключиться по адресу'),
        ),
      ],
    );
  }

  Widget _appearance(BuildContext context, Widget? _) {
    final theme = Theme.of(context);
    final appearance = widget.appearance;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Режим', style: theme.textTheme.titleMedium),
        const SizedBox(height: 7),
        Wrap(
          spacing: 7,
          children: [
            for (final (mode, label, icon) in [
              (ThemeMode.system, 'Системный', Icons.brightness_auto_outlined),
              (ThemeMode.light, 'Светлый', Icons.light_mode_outlined),
              (ThemeMode.dark, 'Тёмный', Icons.dark_mode_outlined),
            ])
              ChoiceChip(
                avatar: Icon(icon, size: 16),
                label: Text(label),
                selected: appearance.mode == mode,
                onSelected: (_) => _setAppearance(mode: mode),
              ),
          ],
        ),
        const SizedBox(height: 16),
        Text('Палитра', style: theme.textTheme.titleMedium),
        const SizedBox(height: 7),
        Wrap(
          spacing: 6,
          runSpacing: 5,
          children: [
            for (final palette in LeafPalette.values)
              ChoiceChip(
                avatar: CircleAvatar(backgroundColor: palette.seed, radius: 8),
                label: Text(palette.label),
                selected: appearance.palette == palette,
                onSelected: (_) => _setAppearance(palette: palette),
              ),
          ],
        ),
      ],
    );
  }
}

class _EnterCodeDialog extends StatefulWidget {
  const _EnterCodeDialog();

  @override
  State<_EnterCodeDialog> createState() => _EnterCodeDialogState();
}

class _EnterCodeDialogState extends State<_EnterCodeDialog> {
  final _code = TextEditingController();
  String? _error;

  void _confirm() {
    try {
      Navigator.pop(context, ConnectionCode.parse(_code.text));
    } on FormatException {
      setState(
        () => _error = 'Проверьте код подключения. Он начинается с LL1-.',
      );
    }
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Ввести код подключения'),
    scrollable: true,
    content: SizedBox(
      width: 340,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          CodeField(controller: _code, onSubmitted: (_) => _confirm()),
          if (_error case final error?)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                error,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Отмена'),
      ),
      FilledButton(onPressed: _confirm, child: const Text('Продолжить')),
    ],
  );
}
