#!/usr/bin/env bash
set -euo pipefail

distribution=$1
output=$2
case "$distribution" in
  ad-hoc) selected_profile=${IOS_AD_HOC_PROFILE_BASE64:-} ;;
  testflight) selected_profile=${IOS_APP_STORE_PROFILE_BASE64:-} ;;
  *) echo 'Choose ad-hoc or testflight.' >&2; exit 1 ;;
esac

if [[ -z "${IOS_DISTRIBUTION_P12_BASE64:-}" || -z "${IOS_DISTRIBUTION_PASSWORD:-}" || -z "$selected_profile" ]]; then
  echo 'Set the Apple Distribution certificate, its password, and the profile for the selected mode in Actions secrets.' >&2
  exit 1
fi

signing_dir=$(mktemp -d "$RUNNER_TEMP/last-leaf-ios.XXXXXX")
keychain="$signing_dir/signing.keychain-db"
profile_destination=''
cleanup() {
  security delete-keychain "$keychain" >/dev/null 2>&1 || true
  if [[ -n "$profile_destination" ]]; then rm -f "$profile_destination"; fi
  rm -rf "$signing_dir"
}
trap cleanup EXIT
umask 077

printf '%s' "$IOS_DISTRIBUTION_P12_BASE64" | base64 -D > "$signing_dir/distribution.p12"
printf '%s' "$selected_profile" | base64 -D > "$signing_dir/profile.mobileprovision"
unset IOS_DISTRIBUTION_P12_BASE64 IOS_AD_HOC_PROFILE_BASE64 IOS_APP_STORE_PROFILE_BASE64 selected_profile

security cms -D -i "$signing_dir/profile.mobileprovision" > "$signing_dir/profile.plist"
uuid=$(python3 ci/configure-ios-signing.py "$distribution" "$signing_dir/profile.plist" \
  ios/Runner.xcodeproj/project.pbxproj "$signing_dir/ExportOptions.plist")
profiles="$HOME/Library/Developer/Xcode/UserData/Provisioning Profiles"
mkdir -p "$profiles"
profile_destination="$profiles/$uuid.mobileprovision"
cp "$signing_dir/profile.mobileprovision" "$profile_destination"

keychain_password=$(openssl rand -hex 32)
security create-keychain -p "$keychain_password" "$keychain"
security set-keychain-settings -lut 3600 "$keychain"
security unlock-keychain -p "$keychain_password" "$keychain"
security import "$signing_dir/distribution.p12" -k "$keychain" \
  -P "$IOS_DISTRIBUTION_PASSWORD" -T /usr/bin/codesign
security set-key-partition-list -S apple-tool:,apple: -s -k "$keychain_password" "$keychain" >/dev/null
security list-keychains -d user -s "$keychain"
unset IOS_DISTRIBUTION_PASSWORD keychain_password
rm "$signing_dir/distribution.p12"

flutter build ipa --release --no-pub --build-number "$GITHUB_RUN_NUMBER" \
  --export-options-plist "$signing_dir/ExportOptions.plist"
ipas=(build/ios/ipa/*.ipa)
if [[ "${#ipas[@]}" != 1 || ! -f "${ipas[0]}" ]]; then
  echo 'Expected a single IPA in build/ios/ipa.' >&2
  exit 1
fi
cp "${ipas[0]}" "$output"
