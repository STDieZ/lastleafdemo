import 'dart:async';

import 'package:material_ui/material_ui.dart';

import 'src/keys.dart';
import 'src/lan_sync.dart';
import 'src/notebook_store.dart';
import 'src/notes.dart';
import 'src/platform_services.dart';
import 'src/setup.dart';
import 'src/theme.dart';
import 'src/workspace.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LanleafApp());
}

class LanleafApp extends StatefulWidget {
  const LanleafApp({super.key});

  @override
  State<LanleafApp> createState() => _LanleafAppState();
}

class _LanleafAppState extends State<LanleafApp> {
  DeviceStorage? _device;
  LocalAccount? _account;
  NotebookStore? _store;
  LanSync? _sync;
  String? _startupError;
  var _loading = true;

  @override
  void initState() {
    super.initState();
    unawaited(_open());
  }

  Future<void> _open() async {
    setState(() {
      _loading = true;
      _startupError = null;
    });
    try {
      _device ??= await DeviceStorage.open();
      final stored = await _device!.readAccount();
      if (stored != null) await _activate(stored);
    } on StorageInUse {
      _startupError =
          'Приложение уже открыто. Закройте другое окно и попробуйте снова.';
    } catch (_) {
      _startupError = 'Не удалось открыть данные на этом устройстве.';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _activate(LocalAccount account) async {
    final store = await NotebookStore.open(_device!.directory, account.key);
    final sync = LanSync(account, store);
    _store = store;
    _account = account;
    _sync = sync;
    unawaited(sync.start());
  }

  Future<void> _onboard(AccountKey key) async {
    final saved = await _device!.readAccount();
    final account = saved ?? LocalAccount(key, newId());
    if (saved == null) await _device!.writeAccount(account);
    await _activate(account);
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _sync?.dispose();
    final device = _device;
    if (device != null) unawaited(device.close());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final error = _startupError;
    return MaterialApp(
      title: 'Лист',
      debugShowCheckedModeBanner: false,
      theme: leafTheme,
      locale: const Locale('ru'),
      supportedLocales: const [Locale('ru')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      home: _loading
          ? const Scaffold(body: Center(child: CircularProgressIndicator()))
          : error != null
          ? Scaffold(
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(error, textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      FilledButton(
                        onPressed: _open,
                        child: const Text('Попробовать снова'),
                      ),
                    ],
                  ),
                ),
              ),
            )
          : _account == null
          ? SetupPage(onConnect: _onboard)
          : NotesWorkspace(account: _account!, store: _store!, sync: _sync!),
    );
  }
}
