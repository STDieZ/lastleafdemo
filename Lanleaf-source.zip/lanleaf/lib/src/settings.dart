import 'package:cryptography/cryptography.dart';
import 'package:flutter/services.dart';
import 'package:material_ui/material_ui.dart';

import 'appearance_settings.dart';
import 'code_field.dart';
import 'lan_sync.dart';
import 'notes.dart';
import 'peers.dart';
import 'theme.dart';

enum _SettingsPane { sync, appearance }

class SettingsDialog extends StatefulWidget {
  const SettingsDialog({
    super.key,
    required this.sync,
    required this.appearance,
  });

  final LanSync sync;
  final AppearanceSettings appearance;

  @override
  State<SettingsDialog> createState() => _SettingsDialogState();
}

class _SettingsDialogState extends State<SettingsDialog> {
  final _target = TextEditingController();
  final _internetTarget = TextEditingController();
  late final _published = TextEditingController(
    text: widget.sync.publicEndpoint?.toString(),
  );
  _SettingsPane _pane = _SettingsPane.sync;
  bool _showCode = false;
  bool _busy = false;
  String? _feedback;
  bool _failed = false;

  void _showFeedback(String message, {bool failed = false}) {
    if (!mounted) return;
    setState(() {
      _feedback = message;
      _failed = failed;
    });
  }

  Future<void> _connect() async {
    setState(() {
      _busy = true;
      _feedback = null;
    });
    try {
      await widget.sync.syncWith(_target.text);
      if (mounted) _target.clear();
      _showFeedback(
        'Устройство запомнено. Дальше обмен будет идти автоматически.',
      );
    } catch (error) {
      _showFeedback(switch (error) {
        FormatException() => error.message,
        NotebookFull() => 'Недостаточно места в хранилище заметок.',
        SecretBoxAuthenticationError() => 'На устройствах разные аккаунты. Введите код подключения другого устройства.',
        _ => 'Не удалось подключиться. Проверьте адрес и откройте Last Leaf на обоих устройствах.',
      }, failed: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _enterCode() async {
    final code = await showDialog<ConnectionCode>(
      context: context,
      builder: (context) => const _EnterCodeDialog(),
    );
    if (!mounted || code == null) return;
    if (code.key.code != widget.sync.account.key.code) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Подключить другой аккаунт?'),
          content: const Text(
            'Заметки с этого устройства будут добавлены в аккаунт из кода '
            'и станут доступны всем его устройствам после синхронизации.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Подключить'),
            ),
          ],
        ),
      );
      if (!mounted || confirmed != true) return;
    }
    Navigator.pop(context, code);
  }

  Future<void> _setAppearance({LeafPalette? palette, ThemeMode? mode}) async {
    try {
      await widget.appearance.update(palette: palette, mode: mode);
    } catch (_) {
      _showFeedback('Не удалось сохранить оформление.', failed: true);
    }
  }

  Future<void> _renameDevice() async {
    final name = await showDialog<String>(
      context: context,
      builder: (context) => _DeviceNameDialog(initial: widget.sync.deviceName),
    );
    if (!mounted || name == null) return;
    await _syncAction(() async {
      await widget.sync.deviceSettings.update(name: name);
      _showFeedback('Имя устройства сохранено.');
    });
  }

  Future<void> _syncAction(Future<void> Function() operation) async {
    if (_busy || !mounted) return;
    setState(() {
      _busy = true;
      _feedback = null;
    });
    try {
      await operation();
    } on FormatException catch (error) {
      _showFeedback(error.message, failed: true);
    } on SecretBoxAuthenticationError {
      _showFeedback('На устройствах разные коды подключения.', failed: true);
    } catch (_) {
      _showFeedback(
        'Не удалось выполнить действие. Проверьте подключение и настройки.',
        failed: true,
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _savePublished() => _syncAction(() async {
    final text = _published.text.trim();
    final endpoint = InternetEndpoint.tryParse(text);
    if (text.isNotEmpty && endpoint == null) {
      throw const FormatException(
        'Введите публичный IPv4, IPv6 в скобках или DNS-имя с портом.',
      );
    }
    await widget.sync.deviceSettings.update(
      internetAddress: endpoint?.toString() ?? '',
    );
    await widget.sync.syncNow(refreshDiscovery: true);
    _showFeedback(
      endpoint == null
          ? 'Входящие подключения через интернет отключены.'
          : 'Публичный адрес добавлен в код подключения.',
    );
  });

  Future<void> _connectInternet() => _syncAction(() async {
    await widget.sync.syncWithInternet(_internetTarget.text);
    if (mounted) _internetTarget.clear();
    _showFeedback('Обмен через интернет завершён. Адрес сохранён.');
  });

  @override
  void dispose() {
    _target.dispose();
    _internetTarget.dispose();
    _published.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AlertDialog(
      title: const Text('Настройки'),
      scrollable: true,
      content: SizedBox(
        width: 430,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Wrap(
              spacing: 8,
              children: [
                for (final (pane, label) in [
                  (_SettingsPane.sync, 'Синхронизация'),
                  (_SettingsPane.appearance, 'Оформление'),
                ])
                  ChoiceChip(
                    label: Text(label),
                    selected: _pane == pane,
                    onSelected: (_) => setState(() {
                      _pane = pane;
                      _feedback = null;
                      _failed = false;
                    }),
                  ),
              ],
            ),
            const SizedBox(height: 20),
            if (_pane == _SettingsPane.sync)
              ListenableBuilder(listenable: widget.sync, builder: _network)
            else
              ListenableBuilder(
                listenable: widget.appearance,
                builder: _appearance,
              ),
            if (_feedback != null) ...[
              const SizedBox(height: 8),
              Semantics(
                liveRegion: true,
                child: Text(
                  _feedback!,
                  style: TextStyle(
                    color: _failed
                        ? theme.colorScheme.error
                        : theme.colorScheme.onSurface,
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Готово'),
        ),
      ],
    );
  }

  Widget _network(BuildContext context, Widget? _) {
    final theme = Theme.of(context);
    final addresses = widget.sync.addresses;
    final code = widget.sync.connectionCode.text;
    final last = widget.sync.lastSynced;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Подключение по коду', style: theme.textTheme.titleMedium),
        const SizedBox(height: 5),
        const Text(
          'Один код на обоих устройствах даёт доступ к заметкам аккаунта.',
        ),
        if (_showCode) ...[
          const SizedBox(height: 8),
          SelectableText(code, style: const TextStyle(fontFamily: 'monospace')),
        ],
        Wrap(
          spacing: 4,
          children: [
            TextButton.icon(
              onPressed: _showCode
                  ? () async {
                      await Clipboard.setData(ClipboardData(text: code));
                      _showFeedback('Код скопирован.');
                    }
                  : () => setState(() => _showCode = true),
              icon: Icon(
                _showCode ? Icons.copy_rounded : Icons.visibility_outlined,
                size: 18,
              ),
              label: Text(_showCode ? 'Скопировать код' : 'Показать код'),
            ),
            TextButton.icon(
              onPressed: _busy ? null : _enterCode,
              icon: const Icon(Icons.link_rounded, size: 18),
              label: const Text('Ввести код'),
            ),
          ],
        ),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.devices_outlined),
          title: const Text('Имя устройства'),
          subtitle: Text(widget.sync.deviceName),
          trailing: const Icon(Icons.edit_outlined, size: 18),
          onTap: _busy ? null : _renameDevice,
        ),
        const Divider(height: 24),
        Text('Локальная сеть', style: theme.textTheme.titleMedium),
        const SizedBox(height: 6),
        Text(
          last == null
              ? 'Ожидаем устройства с этим кодом.'
              : 'Последний обмен в ${TimeOfDay.fromDateTime(last).format(context)}',
        ),
        const SizedBox(height: 8),
        if (addresses.isEmpty)
          const Text('Локальный адрес пока недоступен.')
        else ...[
          const Text('Адрес этого устройства'),
          for (final address in addresses) SelectableText(address),
        ],
        const SizedBox(height: 12),
        TextField(
          controller: _target,
          enabled: !_busy,
          autocorrect: false,
          onSubmitted: _busy ? null : (_) => _connect(),
          decoration: const InputDecoration(
            labelText: 'Адрес другого устройства',
            hintText: '192.168.1.5:41721',
          ),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: _busy ? null : _connect,
          child: Text(_busy ? 'Подключение…' : 'Подключиться по адресу'),
        ),
        const Divider(height: 24),
        _internet(theme),
        _bluetooth(),
      ],
    );
  }

  Widget _internet(ThemeData theme) {
    final sync = widget.sync;
    return ExpansionTile(
      key: const PageStorageKey('internet-settings'),
      tilePadding: EdgeInsets.zero,
      childrenPadding: const EdgeInsets.only(bottom: 12),
      expandedCrossAxisAlignment: CrossAxisAlignment.stretch,
      title: const Text('Прямое подключение через интернет'),
      children: [
        const Text(
          'Хотя бы одно устройство должно принимать входящие TCP‑соединения. Укажите публичный адрес и порт. На втором устройстве введите обновлённый код или адрес вручную.',
        ),
        const SizedBox(height: 8),
        if (sync.listeningPort case final port?)
          Text('TCP‑порт приложения $port'),
        TextField(
          controller: _published,
          enabled: !_busy,
          autocorrect: false,
          enableSuggestions: false,
          onSubmitted: _busy ? null : (_) => _savePublished(),
          decoration: const InputDecoration(
            labelText: 'Публичный адрес этого устройства',
            hintText: 'notes.example.org:41721',
          ),
        ),
        TextButton(
          onPressed: _busy ? null : _savePublished,
          child: const Text('Сохранить и обновить код'),
        ),
        if (sync.publicEndpoint != null)
          TextButton(
            onPressed: _busy
                ? null
                : () {
                    _published.clear();
                    _savePublished();
                  },
            child: const Text('Отключить входящие подключения'),
          ),
        const SizedBox(height: 8),
        TextField(
          controller: _internetTarget,
          enabled: !_busy,
          autocorrect: false,
          enableSuggestions: false,
          onSubmitted: _busy ? null : (_) => _connectInternet(),
          decoration: const InputDecoration(
            labelText: 'Публичный адрес другого устройства',
          ),
        ),
        TextButton(
          onPressed: _busy ? null : _connectInternet,
          child: const Text('Подключиться через интернет'),
        ),
        for (final endpoint in sync.internetPeers)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            title: Text(endpoint.toString(), style: theme.textTheme.bodySmall),
            trailing: IconButton(
              tooltip: 'Забыть публичный адрес',
              onPressed: _busy
                  ? null
                  : () => _syncAction(() => sync.forgetInternet(endpoint)),
              icon: const Icon(Icons.close_rounded),
            ),
          ),
      ],
    );
  }

  Widget _bluetooth() {
    final sync = widget.sync;
    return ExpansionTile(
      key: const PageStorageKey('bluetooth-settings'),
      tilePadding: EdgeInsets.zero,
      expandedCrossAxisAlignment: CrossAxisAlignment.stretch,
      title: const Text('Bluetooth'),
      children: [
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Обмен после редактирования'),
          value: sync.bluetoothEnabled,
          onChanged: _busy
              ? null
              : (enabled) =>
                    _syncAction(() => sync.setBluetoothEnabled(enabled)),
        ),
        Text(sync.bluetoothStatus),
        TextButton.icon(
          onPressed: _busy || !sync.bluetoothEnabled || sync.bluetoothBusy
              ? null
              : () => sync.syncOverBluetooth(),
          icon: const Icon(Icons.bluetooth_rounded),
          label: const Text('Обменяться по Bluetooth сейчас'),
        ),
      ],
    );
  }

  Widget _appearance(BuildContext context, Widget? _) {
    final theme = Theme.of(context);
    final appearance = widget.appearance;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text('Режим', style: theme.textTheme.titleMedium),
        const SizedBox(height: 7),
        Wrap(
          spacing: 7,
          children: [
            for (final (mode, label, icon) in [
              (ThemeMode.system, 'Системный', Icons.brightness_auto_outlined),
              (ThemeMode.light, 'Светлый', Icons.light_mode_outlined),
              (ThemeMode.dark, 'Тёмный', Icons.dark_mode_outlined),
            ])
              ChoiceChip(
                avatar: Icon(icon, size: 16),
                label: Text(label),
                selected: appearance.mode == mode,
                onSelected: (_) => _setAppearance(mode: mode),
              ),
          ],
        ),
        const SizedBox(height: 16),
        Text('Палитра', style: theme.textTheme.titleMedium),
        const SizedBox(height: 7),
        Wrap(
          spacing: 6,
          runSpacing: 5,
          children: [
            for (final palette in LeafPalette.values)
              ChoiceChip(
                avatar: CircleAvatar(backgroundColor: palette.seed, radius: 8),
                label: Text(palette.label),
                selected: appearance.palette == palette,
                onSelected: (_) => _setAppearance(palette: palette),
              ),
          ],
        ),
      ],
    );
  }
}

class _DeviceNameDialog extends StatefulWidget {
  const _DeviceNameDialog({required this.initial});

  final String initial;

  @override
  State<_DeviceNameDialog> createState() => _DeviceNameDialogState();
}

class _DeviceNameDialogState extends State<_DeviceNameDialog> {
  late final _name = TextEditingController(text: widget.initial);

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Имя устройства'),
    content: TextField(
      controller: _name,
      autofocus: true,
      maxLength: 40,
      decoration: const InputDecoration(hintText: 'Например, домашний ноутбук'),
      onSubmitted: (name) => Navigator.pop(context, name),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Отмена'),
      ),
      FilledButton(
        onPressed: () => Navigator.pop(context, _name.text),
        child: const Text('Сохранить'),
      ),
    ],
  );
}

class _EnterCodeDialog extends StatefulWidget {
  const _EnterCodeDialog();

  @override
  State<_EnterCodeDialog> createState() => _EnterCodeDialogState();
}

class _EnterCodeDialogState extends State<_EnterCodeDialog> {
  final _code = TextEditingController();
  String? _error;

  void _confirm() {
    try {
      Navigator.pop(context, ConnectionCode.parse(_code.text));
    } on FormatException {
      setState(
        () => _error = 'Проверьте код подключения. Он начинается с LL1-.',
      );
    }
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Ввести код подключения'),
    scrollable: true,
    content: SizedBox(
      width: 340,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          CodeField(controller: _code, onSubmitted: (_) => _confirm()),
          if (_error case final error?)
            Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(
                error,
                style: TextStyle(color: Theme.of(context).colorScheme.error),
              ),
            ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Отмена'),
      ),
      FilledButton(onPressed: _confirm, child: const Text('Продолжить')),
    ],
  );
}
