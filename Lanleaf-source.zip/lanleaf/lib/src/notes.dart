import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:characters/characters.dart';

import 'note_edit.dart';

const maxNotebookBytes = 8 * 1024 * 1024;
const maxTitleLength = 160;
const maxBodyLength = 60000;

final _random = Random.secure();
final _idPattern = RegExp(r'^[a-f0-9]{32}$');

Uint8List randomBytes(int length) =>
    Uint8List.fromList(List.generate(length, (_) => _random.nextInt(256)));

String newId() =>
    randomBytes(16)
        .map((byte) => byte.toRadixString(16).padLeft(2, '0'))
        .join();

bool isId(Object? value) => value is String && _idPattern.hasMatch(value);

class NoteVersion {
  NoteVersion({
    required this.author,
    required Map<String, int> clock,
    required this.time,
    required this.title,
    required this.body,
    required this.deleted,
    this.edit,
  }) : clock = Map.unmodifiable(clock);

  factory NoteVersion.fromJson(Object? value) {
    if (value is! Map<String, dynamic>) throw const FormatException();
    final author = value['author'];
    final clock = value['clock'];
    final time = value['time'];
    final title = value['title'];
    final body = value['body'];
    final deleted = value['deleted'];
    if (author is! String ||
        !isId(author) ||
        clock is! Map<String, dynamic> ||
        !clock.containsKey(author) ||
        clock.entries.any(
          (e) =>
              !isId(e.key) ||
              e.value is! int ||
              (e.value as int) < 1 ||
              (e.value as int) > 0x7fffffff,
        ) ||
        time is! int ||
        time < 0 ||
        time > 8640000000000000 ||
        title is! String ||
        title.characters.length > maxTitleLength ||
        body is! String ||
        body.characters.length > maxBodyLength ||
        deleted is! bool ||
        (deleted && (title.isNotEmpty || body.isNotEmpty))) {
      throw const FormatException('Invalid note revision');
    }
    return NoteVersion(
      author: author,
      clock: clock.cast<String, int>(),
      time: time,
      title: title,
      body: body,
      deleted: deleted,
      edit: value['edit'] == null ? null : NoteEdit.fromJson(value['edit']),
    );
  }

  final String author;
  final Map<String, int> clock;
  final int time;
  final String title;
  final String body;
  final bool deleted;
  final NoteEdit? edit;

  String get id => '$author:${clock[author]}';

  bool supersedes(NoteVersion other) {
    for (final entry in other.clock.entries) {
      if ((clock[entry.key] ?? 0) < entry.value) return false;
    }
    return clock.entries.any(
      (entry) => entry.value > (other.clock[entry.key] ?? 0),
    );
  }

  bool matches(NoteVersion other) =>
      id == other.id &&
      time == other.time &&
      title == other.title &&
      body == other.body &&
      deleted == other.deleted &&
      clock.length == other.clock.length &&
      clock.entries.every((e) => other.clock[e.key] == e.value);

  Map<String, Object> toJson({bool includeEdit = true}) => {
    'author': author,
    'clock': {for (final key in clock.keys.toList()..sort()) key: clock[key]},
    'time': time,
    'title': title,
    'body': body,
    'deleted': deleted,
    if (includeEdit && edit != null) 'edit': edit!.toJson(),
  };
}

class Note {
  const Note(this.id, this.versions);

  final String id;
  final List<NoteVersion> versions;

  bool get visible => versions.any((v) => !v.deleted);
  bool get hasConflict => versions.length > 1;
  NoteVersion get latest => versions.firstWhere((v) => !v.deleted);
}

class NotePin implements Comparable<NotePin> {
  const NotePin(this.pinned, this.revision, this.author);

  factory NotePin.fromJson(Object? value) {
    if (value case [final bool pinned, final int revision, final String author]
        when revision > 0 && revision <= 0x7fffffff && isId(author)) {
      return NotePin(pinned, revision, author);
    }
    throw const FormatException('Invalid pin');
  }

  final bool pinned;
  final int revision;
  final String author;

  @override
  int compareTo(NotePin other) {
    final order = revision.compareTo(other.revision);
    if (order != 0) return order;
    final authorOrder = author.compareTo(other.author);
    if (authorOrder != 0) return authorOrder;
    // Keeps both peers in agreement even if an old backup reused a revision.
    return (pinned ? 1 : 0).compareTo(other.pinned ? 1 : 0);
  }

  List<Object> toJson() => [pinned, revision, author];
}

class Notebook {
  Notebook.empty() : notes = const {}, pins = const {};

  Notebook._(Map<String, Note> notes, Map<String, NotePin> pins)
    : notes = Map.unmodifiable(notes),
      pins = Map.unmodifiable(pins);

  factory Notebook.decode(List<int> bytes) {
    if (bytes.length > maxNotebookBytes) throw const NotebookFull();
    final value = jsonDecode(utf8.decode(bytes));
    if (value is! Map<String, dynamic> ||
        value['format'] != 1 ||
        value['notes'] is! Map<String, dynamic>) {
      throw const FormatException('Invalid notebook');
    }
    final notes = <String, Note>{};
    for (final entry in (value['notes'] as Map<String, dynamic>).entries) {
      final versions = entry.value;
      if (!isId(entry.key) || versions is! List || versions.isEmpty) {
        throw const FormatException('Invalid note');
      }
      final frontier = _mergeVersions(
        const [],
        versions.map(NoteVersion.fromJson),
      );
      notes[entry.key] = Note(entry.key, List.unmodifiable(frontier));
    }
    final pins = <String, NotePin>{};
    if (value.containsKey('pins')) {
      final encodedPins = value['pins'];
      if (encodedPins is! Map<String, dynamic>) {
        throw const FormatException('Invalid pins');
      }
      for (final entry in encodedPins.entries) {
        if (!notes.containsKey(entry.key)) {
          throw const FormatException('Pin refers to an unknown note');
        }
        pins[entry.key] = NotePin.fromJson(entry.value);
      }
    }
    return Notebook._(notes, pins);
  }

  final Map<String, Note> notes;
  final Map<String, NotePin> pins;

  bool isPinned(String id) => pins[id]?.pinned ?? false;

  Notebook setPinned(String id, String author, bool pinned) {
    if (!(notes[id]?.visible ?? false) || isPinned(id) == pinned) return this;
    final revision = (pins[id]?.revision ?? 0) + 1;
    return Notebook._(notes, {...pins, id: NotePin(pinned, revision, author)});
  }

  late final Uint8List _encoded = _encodeCanonical(
    includePins: pins.isNotEmpty,
    includeEdits: true,
  );
  late final Uint8List _previousEncoded = pins.isEmpty
      ? _legacyEncoded
      : _encodeCanonical(includePins: true, includeEdits: false);
  late final Uint8List _legacyEncoded = _encodeCanonical(
    includePins: false,
    includeEdits: false,
  );

  Uint8List encode({bool includePins = true, bool includeEdits = true}) {
    if (!includePins) return _legacyEncoded;
    return includeEdits ? _encoded : _previousEncoded;
  }

  Uint8List _encodeCanonical({
    required bool includePins,
    required bool includeEdits,
  }) {
    final bytes = utf8.encode(
      jsonEncode({
        'format': 1,
        'notes': {
          for (final id in notes.keys.toList()..sort())
            id: [
              for (final revision in notes[id]!.versions)
                revision.toJson(includeEdit: includeEdits),
            ],
        },
        if (includePins)
          'pins': {for (final id in pins.keys.toList()..sort()) id: pins[id]},
      }),
    );
    if (bytes.length > maxNotebookBytes) throw const NotebookFull();
    return bytes.asUnmodifiableView();
  }

  Notebook merge(Notebook incoming) {
    final notes = Map.of(this.notes);
    final pins = Map.of(this.pins);
    var changed = false;
    for (final note in incoming.notes.values) {
      final before = notes[note.id]?.versions ?? const <NoteVersion>[];
      final after = _mergeVersions(before, note.versions);
      if (before.length != after.length ||
          before.asMap().entries.any(
            (entry) => !identical(entry.value, after[entry.key]),
          )) {
        notes[note.id] = Note(note.id, List.unmodifiable(after));
        changed = true;
      }
    }
    for (final entry in incoming.pins.entries) {
      final current = pins[entry.key];
      if (current == null || entry.value.compareTo(current) > 0) {
        pins[entry.key] = entry.value;
        changed = true;
      }
    }
    return changed ? Notebook._(notes, pins) : this;
  }

  ({Notebook notebook, NoteVersion version}) revise({
    required String id,
    required String author,
    required Iterable<NoteVersion> basedOn,
    required String title,
    required String body,
    bool deleted = false,
    NoteEdit? edit,
  }) {
    if (title.characters.length > maxTitleLength ||
        body.characters.length > maxBodyLength) {
      throw const NotebookFull();
    }
    final clock = <String, int>{};
    for (final version in basedOn) {
      for (final entry in version.clock.entries) {
        clock.update(
          entry.key,
          (old) => max(old, entry.value),
          ifAbsent: () => entry.value,
        );
      }
    }
    final versions = notes[id]?.versions ?? const <NoteVersion>[];
    var count = clock[author] ?? 0;
    for (final version in versions) {
      count = max(count, version.clock[author] ?? 0);
    }
    clock[author] = count + 1;
    final version = NoteVersion(
      author: author,
      clock: clock,
      time: DateTime.now().millisecondsSinceEpoch,
      title: deleted ? '' : title,
      body: deleted ? '' : body,
      deleted: deleted,
      edit: edit,
    );
    return (
      notebook: Notebook._({
        ...notes,
        id: Note(id, List.unmodifiable(_mergeVersions(versions, [version]))),
      }, pins),
      version: version,
    );
  }
}

List<NoteVersion> _mergeVersions(
  List<NoteVersion> before,
  Iterable<NoteVersion> additions,
) {
  final versions = List.of(before);
  for (final incoming in additions) {
    final same = versions
        .where((version) => version.id == incoming.id)
        .firstOrNull;
    if (same != null) {
      if (!same.matches(incoming)) {
        throw const FormatException('Revision identifier reused');
      }
      if (same.edit == null && incoming.edit != null) {
        versions[versions.indexOf(same)] = incoming;
      }
      continue;
    }
    if (versions.any((version) => version.supersedes(incoming))) continue;
    versions.removeWhere(incoming.supersedes);
    versions.add(incoming);
  }
  versions.sort((a, b) {
    if (a.deleted != b.deleted) return a.deleted ? 1 : -1;
    final time = b.time.compareTo(a.time);
    return time != 0 ? time : a.id.compareTo(b.id);
  });
  return versions;
}

class NotebookFull implements Exception {
  const NotebookFull();
}
