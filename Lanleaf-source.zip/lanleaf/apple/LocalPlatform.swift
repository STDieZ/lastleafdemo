import Darwin
import Foundation
import Security

#if os(iOS)
import Flutter
#else
import FlutterMacOS
#endif

func registerLocalPlatform(_ messenger: FlutterBinaryMessenger) {
  let channel = FlutterMethodChannel(name: "com.lanleaf/local", binaryMessenger: messenger)
  channel.setMethodCallHandler { call, result in
    switch call.method {
    case "applicationSupport":
      let directory = FileManager.default.urls(
        for: .applicationSupportDirectory, in: .userDomainMask
      ).first
      result(directory?.path)
    case "excludeBackup":
      guard let path = call.arguments as? String else {
        result(FlutterError(code: "arguments", message: nil, details: nil))
        return
      }
      var url = URL(fileURLWithPath: path, isDirectory: true)
      var values = URLResourceValues()
      values.isExcludedFromBackup = true
      do {
        try url.setResourceValues(values)
        result(nil)
      } catch {
        result(FlutterError(code: "local-storage", message: error.localizedDescription, details: nil))
      }
    case "readIdentity", "readIdentityWithAuthorization":
      var query = identityQuery()
      query[kSecReturnData as String] = true
      query[kSecMatchLimit as String] = kSecMatchLimitOne
      var value: CFTypeRef?
      let status = performKeychainOperation(allowInteraction: call.method == "readIdentityWithAuthorization") {
        SecItemCopyMatching(query as CFDictionary, &value)
      }
      if status == errSecSuccess, let data = value as? Data {
        result(FlutterStandardTypedData(bytes: data))
      } else if status == errSecItemNotFound {
        result(nil)
      } else {
        result(keychainError(status))
      }
    case "writeIdentity", "writeIdentityWithAuthorization":
      guard let data = call.arguments as? FlutterStandardTypedData else {
        result(FlutterError(code: "arguments", message: nil, details: nil))
        return
      }
      var query = identityQuery()
      query[kSecValueData as String] = data.data
      query[kSecAttrLabel as String] = "Last Leaf — локальный ключ"
      #if os(iOS)
      query[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
      #endif
      let status = performKeychainOperation(allowInteraction: call.method == "writeIdentityWithAuthorization") {
        let added = SecItemAdd(query as CFDictionary, nil)
        guard added == errSecDuplicateItem else { return added }
        let update = [kSecValueData as String: data.data]
        return SecItemUpdate(identityQuery() as CFDictionary, update as CFDictionary)
      }
      result(status == errSecSuccess ? nil : keychainError(status))
    case "localInterfaces":
      result(localInterfaces())
    default:
      result(FlutterMethodNotImplemented)
    }
  }
}

private func identityQuery() -> [String: Any] {
  let bundle = Bundle.main.bundleIdentifier ?? "com.lanleaf.lanleaf"
  return [
    kSecClass as String: kSecClassGenericPassword,
    kSecAttrService as String: "\(bundle).local",
    kSecAttrAccount as String: "lanleaf-identity-v1"
  ]
}

private func keychainError(_ status: OSStatus) -> FlutterError {
  #if os(macOS)
  switch status {
  case errSecInteractionNotAllowed, errSecInteractionRequired, errSecAuthFailed, errSecUserCanceled:
    return FlutterError(code: "keychain-access-required", message: nil, details: Int(status))
  default:
    break
  }
  #endif
  return FlutterError(code: "keychain", message: nil, details: Int(status))
}

private func performKeychainOperation(
  allowInteraction: Bool,
  _ operation: () -> OSStatus
) -> OSStatus {
  #if os(macOS)
  if !allowInteraction {
    // Existing Mac installs use the file-based keychain. Keep interaction off
    // only for this synchronous platform-channel operation.
    var previous = DarwinBoolean(false)
    let readStatus = SecKeychainGetUserInteractionAllowed(&previous)
    guard readStatus == errSecSuccess else { return readStatus }
    if previous.boolValue {
      let changeStatus = SecKeychainSetUserInteractionAllowed(false)
      guard changeStatus == errSecSuccess else { return changeStatus }
      defer { _ = SecKeychainSetUserInteractionAllowed(true) }
      return operation()
    }
  }
  #endif
  return operation()
}

private func localInterfaces() -> [String] {
  var first: UnsafeMutablePointer<ifaddrs>?
  guard getifaddrs(&first) == 0, let first = first else { return [] }
  defer { freeifaddrs(first) }
  var addresses: [String] = []
  var cursor: UnsafeMutablePointer<ifaddrs>? = first

  while let entry = cursor?.pointee {
    cursor = entry.ifa_next
    let flags = entry.ifa_flags
    guard flags & UInt32(IFF_UP) != 0,
      flags & UInt32(IFF_RUNNING) != 0,
      flags & UInt32(IFF_LOOPBACK | IFF_POINTOPOINT) == 0,
      let address = entry.ifa_addr,
      let netmask = entry.ifa_netmask,
      address.pointee.sa_family == UInt8(AF_INET)
    else { continue }
    var ipv4 = address.withMemoryRebound(to: sockaddr_in.self, capacity: 1) {
      $0.pointee.sin_addr
    }
    let prefix = netmask.withMemoryRebound(to: sockaddr_in.self, capacity: 1) {
      $0.pointee.sin_addr.s_addr.nonzeroBitCount
    }
    var buffer = [CChar](repeating: 0, count: Int(INET_ADDRSTRLEN))
    let converted = buffer.withUnsafeMutableBufferPointer {
      inet_ntop(AF_INET, &ipv4, $0.baseAddress, socklen_t($0.count)) != nil
    }
    if converted {
      let bytes = buffer.prefix { $0 != 0 }.map(UInt8.init(bitPattern:))
      addresses.append("\(String(decoding: bytes, as: UTF8.self))/\(prefix)")
    }
  }
  return addresses
}
