import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/lan_sync.dart';
import 'package:lanleaf/src/notebook_store.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/platform_services.dart';
import 'package:lanleaf/src/setup.dart';
import 'package:lanleaf/src/theme.dart';
import 'package:lanleaf/src/workspace.dart';
import 'package:material_ui/material_ui.dart';

Widget app(Widget home) => MaterialApp(
  theme: leafTheme,
  locale: const Locale('ru'),
  supportedLocales: const [Locale('ru')],
  localizationsDelegates: GlobalMaterialLocalizations.delegates,
  home: home,
);

void main() {
  testWidgets('phone pairing validates and accepts the account code', (
    tester,
  ) async {
    final key = AccountKey.generate();
    AccountKey? submitted;
    await tester.binding.setSurfaceSize(const Size(390, 780));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      app(SetupPage(onConnect: (value) async => submitted = value)),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('У меня есть код подключения'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField), '1234');
    await tester.tap(find.text('Подключить устройство'));
    await tester.pumpAndSettle();
    expect(submitted, isNull);
    expect(find.textContaining('Проверьте код'), findsOneWidget);
    await tester.enterText(find.byType(TextField), key.code);
    await tester.tap(find.text('Подключить устройство'));
    await tester.pumpAndSettle();
    expect(submitted?.code, key.code);
  });

  testWidgets('search and editor work across desktop and phone layouts', (
    tester,
  ) async {
    final account = LocalAccount(AccountKey.generate(), newId());
    final store = (await tester.runAsync(() async {
      final directory = await Directory.systemTemp.createTemp('lanleaf-ui-');
      addTearDown(() => directory.delete(recursive: true));
      final store = await NotebookStore.open(directory, account.key);
      await store.revise(
        id: newId(),
        author: account.device,
        basedOn: [],
        title: 'Маршрут',
        body: 'Текст для поиска',
      );
      await store.revise(
        id: newId(),
        author: account.device,
        basedOn: [],
        title: 'Покупки',
        body: 'Яблоки',
      );
      return store;
    }))!;
    final sync = LanSync(account, store);
    addTearDown(sync.dispose);
    await tester.binding.setSurfaceSize(const Size(1060, 760));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      app(NotesWorkspace(account: account, store: store, sync: sync)),
    );
    await tester.pumpAndSettle();
    expect(find.text('Откройте заметку'), findsOneWidget);
    await tester.enterText(find.byType(TextField), 'текст для поиска');
    await tester.pumpAndSettle();
    expect(find.text('Покупки'), findsNothing);
    await tester.tap(find.text('Маршрут'));
    await tester.pumpAndSettle();
    expect(find.text('Сохранено на устройстве'), findsOneWidget);
    await tester.binding.setSurfaceSize(const Size(390, 780));
    await tester.pumpAndSettle();
    expect(find.byTooltip('К списку заметок'), findsOneWidget);
    await tester.tap(find.byTooltip('К списку заметок'));
    await tester.pumpAndSettle();
    expect(find.text('Новая заметка'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });
}
