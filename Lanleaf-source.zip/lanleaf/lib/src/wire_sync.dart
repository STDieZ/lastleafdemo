import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

import 'keys.dart';
import 'notes.dart';
import 'peers.dart';

const _peerBytes = 34;
const _frameLimit = maxNotebookBytes + 40;
const _executionTime = Duration(seconds: 12);
final _exchange = X25519();
final _sha256 = Sha256();

typedef MergeNotebook = Future<Notebook> Function(Notebook remote);

class PeerNeedsLegacyProtocol implements Exception {
  const PeerNeedsLegacyProtocol();
}

Future<PeerIdentity?> receiveSync(
  Socket socket,
  AccountKey account,
  Notebook Function() snapshot,
  MergeNotebook merge, {
  PeerIdentity? identity,
}) => _useSocket(socket, (stream) async {
  final hello = await stream.read(36);
  final protocol = hello[2];
  final modern = protocol == 2 && identity != null;
  if (hello[0] != 0x4c ||
      hello[1] != 0x4c ||
      hello[3] != 0 ||
      (protocol != 1 && !modern)) {
    throw const FormatException('Invalid sync protocol');
  }

  final clientPublic = hello.sublist(4);
  final keyPair = await _exchange.newKeyPair();
  final serverPublic = (await keyPair.extractPublicKey()).bytes;
  final keys = await _session(
    account,
    keyPair,
    clientPublic,
    clientPublic,
    serverPublic,
    protocol,
  );
  socket.add(serverPublic);
  socket.add(await seal(modern ? _encodePeer(identity) : const [], keys.proof));
  await socket.flush();

  final request = await unseal(
    await stream.read(72 + (modern ? _peerBytes : 0)),
    keys.client,
  );
  final peer = modern ? _decodePeer(request.sublist(32)) : null;
  final local = await _sha256.hash(snapshot().encode(includePins: modern));
  final needsUpdate = local != Hash(request.sublist(0, 32));
  socket.add(await seal([if (needsUpdate) 1 else 0], keys.server));
  await socket.flush();

  if (needsUpdate) {
    final remote = Notebook.decode(
      await unseal(await stream.frame(), keys.client),
    );
    final merged = await merge(remote);
    await stream.writeFrame(
      await seal(merged.encode(includePins: modern), keys.server),
    );
  }
  if (modern) {
    await unseal(await stream.read(40), keys.client);
  }
  return peer;
});

Future<PeerIdentity?> sendSync(
  Socket socket,
  AccountKey account,
  Notebook Function() snapshot,
  MergeNotebook merge, {
  PeerIdentity? identity,
}) => _useSocket(socket, (stream) async {
  final modern = identity != null;
  final protocol = modern ? 2 : 1;
  final keyPair = await _exchange.newKeyPair();
  final clientPublic = (await keyPair.extractPublicKey()).bytes;
  socket.add([0x4c, 0x4c, protocol, 0, ...clientPublic]);
  await socket.flush();

  final Uint8List serverPublic;
  try {
    serverPublic = await stream.read(32);
  } on SocketException {
    if (modern) throw const PeerNeedsLegacyProtocol();
    rethrow;
  }
  final keys = await _session(
    account,
    keyPair,
    serverPublic,
    clientPublic,
    serverPublic,
    protocol,
  );
  final proof = await unseal(
    await stream.read(40 + (modern ? _peerBytes : 0)),
    keys.proof,
  );
  final peer = modern ? _decodePeer(proof) : null;
  final contents = snapshot().encode(includePins: modern);
  final digest = await _sha256.hash(contents);
  socket.add(
    await seal([
      ...digest.bytes,
      if (modern) ..._encodePeer(identity),
    ], keys.client),
  );
  await socket.flush();
  final update = await unseal(await stream.read(41), keys.server);
  if (update.single == 1) {
    await stream.writeFrame(await seal(contents, keys.client));
    final remote = Notebook.decode(
      await unseal(await stream.frame(), keys.server),
    );
    await merge(remote);
  } else if (update.single != 0) {
    throw const FormatException('Invalid sync response');
  }
  if (modern) {
    // The responder can keep the connection open until this copy is stored.
    socket.add(await seal(const [], keys.client));
    await socket.flush();
  }
  return peer;
});

List<int> _encodePeer(PeerIdentity peer) => [
  peer.port >> 8,
  peer.port & 255,
  ...ascii.encode(peer.device),
];

PeerIdentity _decodePeer(List<int> data) {
  if (data.length != _peerBytes) {
    throw const FormatException('Invalid peer identity');
  }
  final port = (data[0] << 8) | data[1];
  final device = ascii.decode(data.sublist(2));
  if (port == 0 || !isId(device)) {
    throw const FormatException('Invalid peer identity');
  }
  return PeerIdentity(device, port);
}

Future<SessionKeys> _session(
  AccountKey account,
  KeyPair keyPair,
  List<int> remotePublic,
  List<int> clientPublic,
  List<int> serverPublic,
  int protocol,
) async {
  final sharedSecret = await _exchange.sharedSecretKey(
    keyPair: keyPair,
    remotePublicKey: SimplePublicKey(remotePublic, type: KeyPairType.x25519),
  );
  if ((await sharedSecret.extractBytes()).every((byte) => byte == 0)) {
    throw const FormatException('Invalid public key');
  }
  return account.session(
    sharedSecret: sharedSecret,
    clientPublic: clientPublic,
    serverPublic: serverPublic,
    protocol: protocol,
  );
}

Future<T> _useSocket<T>(
  Socket socket,
  Future<T> Function(_SocketFrames connection) operation,
) async {
  final stream = _SocketFrames(socket);
  unawaited(
    socket.done.then<void>((_) {}, onError: (Object _, StackTrace _) {}),
  );
  try {
    return await (() async {
      final result = await operation(stream);
      await socket.close();
      return result;
    })().timeout(_executionTime);
  } finally {
    socket.destroy();
    unawaited(
      stream.chunks.cancel().then<void>(
        (_) {},
        onError: (Object _, StackTrace _) {},
      ),
    );
  }
}

class _SocketFrames {
  _SocketFrames(this.socket) : chunks = StreamIterator(socket);

  final Socket socket;
  final StreamIterator<Uint8List> chunks;
  Uint8List _chunk = Uint8List(0);
  int _offset = 0;

  Future<Uint8List> read(int size) async {
    final result = Uint8List(size);
    var position = 0;
    while (position < size) {
      if (_offset == _chunk.length) {
        if (!await chunks.moveNext()) {
          throw const SocketException('Connection closed');
        }
        _chunk = chunks.current;
        _offset = 0;
      }
      final available = _chunk.length - _offset;
      final length = available < size - position ? available : size - position;
      result.setRange(position, position + length, _chunk, _offset);
      position += length;
      _offset += length;
    }
    return result;
  }

  Future<Uint8List> frame() async {
    final size = (await read(4)).buffer.asByteData().getUint32(0);
    if (size < 40 || size > _frameLimit) {
      throw const FormatException('Invalid frame size');
    }
    return read(size);
  }

  Future<void> writeFrame(List<int> data) async {
    final length = ByteData(4)..setUint32(0, data.length);
    socket.add(length.buffer.asUint8List());
    socket.add(data);
    await socket.flush();
  }
}
