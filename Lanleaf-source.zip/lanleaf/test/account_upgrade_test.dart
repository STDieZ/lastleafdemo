import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/main.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/notebook_store.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/peers.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as path;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets(
    'an existing installation joins another code and keeps its notes',
    (tester) async {
      final previous = AccountKey.generate();
      final device = newId();
      final noteId = newId();
      final next = AccountKey.generate();
      Uint8List identity = utf8.encode(
        jsonEncode({'key': previous.code, 'device': device}),
      );
      final root = (await tester.runAsync(() async {
        final directory = await Directory.systemTemp.createTemp(
          'last-leaf-account-',
        );
        addTearDown(() => directory.delete(recursive: true));
        final oldFolder = await Directory(path.join(directory.path, 'Lanleaf'))
            .create();
        final store = await NotebookStore.open(oldFolder, previous);
        await store.revise(
          id: noteId,
          author: device,
          basedOn: [],
          title: 'Моя заметка',
          body: 'Текст до обновления',
        );
        return directory;
      }))!;
      const platform = MethodChannel('com.lanleaf/local');
      final messenger =
          TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
      messenger.setMockMethodCallHandler(
        platform,
        (call) async => switch (call.method) {
          'applicationSupport' => root.path,
          'readIdentity' => identity,
          'writeIdentity' => identity = call.arguments as Uint8List,
          'localInterfaces' => <String>[],
          _ => null,
        },
      );
      addTearDown(() => messenger.setMockMethodCallHandler(platform, null));

      await tester.pumpWidget(const LastLeafApp());
      await _pumpUntil(
        tester,
        () => find.byTooltip('Настройки').evaluate().isNotEmpty,
      );
      expect(find.text('Моя заметка'), findsOneWidget);

      await tester.tap(find.byTooltip('Настройки'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Ввести код'));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byType(TextField).last,
        ConnectionCode(next).text,
      );
      await tester.tap(find.text('Продолжить'));
      await tester.pumpAndSettle();
      await tester.tap(find.widgetWithText(FilledButton, 'Подключить'));
      await _pumpUntil(
        tester,
        () => (jsonDecode(utf8.decode(identity)) as Map)['key'] == next.code,
      );
      await tester.pumpAndSettle();
      expect(find.text('Моя заметка'), findsOneWidget);

      await tester.runAsync(() async {
        final profile =
            jsonDecode(utf8.decode(identity)) as Map<String, dynamic>;
        expect(profile['device'], device);
        final previousFolder = Directory(path.join(root.path, 'Lanleaf'));
        final nextFolder = Directory(
          path.join(
            previousFolder.path,
            'accounts',
            profile['storage'] as String,
          ),
        );
        final old = await NotebookStore.open(previousFolder, previous);
        final imported = await NotebookStore.open(nextFolder, next);
        expect(old.notebook.notes[noteId]!.latest.body, 'Текст до обновления');
        expect(
          imported.notebook.notes[noteId]!.latest.body,
          'Текст до обновления',
        );
      });
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
    },
    skip: Platform.isWindows,
  );
}

Future<void> _pumpUntil(WidgetTester tester, bool Function() condition) async {
  final watch = Stopwatch()..start();
  while (!condition() && watch.elapsed < const Duration(seconds: 5)) {
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 12)),
    );
    await tester.pump(const Duration(milliseconds: 20));
  }
  expect(condition(), isTrue);
}
