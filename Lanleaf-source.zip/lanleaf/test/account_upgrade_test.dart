import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/main.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/notebook_store.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/peers.dart';
import 'package:lanleaf/src/profile_vault.dart';
import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as path;

const _password = 'мой пароль Last Leaf';
const _noteTitle = 'Мои заметки до обновления';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets(
    'a previous account restores from its code and opens with a local password after restart',
    (tester) async {
      final previous = await _previousInstallation(tester, scoped: true);
      await tester.pumpWidget(const LastLeafApp());
      await _waitFor(tester, 'Восстановить по коду');

      await tester.tap(find.text('Восстановить по коду'));
      await tester.pumpAndSettle();
      await tester.enterText(
        _field('Код подключения'),
        AccountKey.generate().code,
      );
      await tester.tap(find.text('Открыть прежние заметки'));
      await _waitFor(
        tester,
        'По этому коду не удалось открыть сохранённые заметки. Проверьте код прежнего аккаунта.',
      );
      expect(await tester.runAsync(() => previous.vault.exists()), isFalse);

      await tester.enterText(
        _field('Код подключения'),
        ConnectionCode(previous.key).text,
      );
      await tester.tap(find.text('Открыть прежние заметки'));
      await _setPassword(tester);
      await _waitFor(tester, _noteTitle);

      await tester.pumpWidget(const SizedBox.shrink());
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 80)),
      );
      await tester.pumpWidget(const LastLeafApp());
      await _waitFor(tester, 'Открыть заметки');
      expect(find.text(_noteTitle), findsNothing);
      await tester.enterText(_field('Пароль Last Leaf'), _password);
      await tester.tap(find.text('Открыть заметки'));
      await _waitFor(tester, _noteTitle);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
    },
    skip: Platform.isWindows,
  );

  testWidgets(
    'starting a new account preserves the old notebook and later joining its code restores it',
    (tester) async {
      final previous = await _previousInstallation(tester);
      final oldFile = NotebookStore.fileIn(previous.directory);
      final original = await tester.runAsync(oldFile.readAsBytes);
      await tester.pumpWidget(const LastLeafApp());
      await _waitFor(tester, 'Создать новый аккаунт');
      await tester.tap(find.text('Создать новый аккаунт'));
      await _setPassword(tester);
      await _waitFor(tester, 'Новая заметка');
      expect(find.text(_noteTitle), findsNothing);
      expect(await tester.runAsync(oldFile.readAsBytes), original);

      await tester.tap(find.byTooltip('Настройки'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Ввести код'));
      await tester.pumpAndSettle();
      await tester.enterText(_field('Код подключения'), previous.key.code);
      await tester.tap(find.text('Продолжить'));
      await tester.pumpAndSettle();
      await tester.tap(find.widgetWithText(FilledButton, 'Подключить'));
      await _waitFor(tester, _noteTitle);

      final session = (await tester.runAsync(
        () => previous.vault.unlock(_password),
      ))!;
      expect(session.account.key.code, previous.key.code);
      expect(session.account.storageTag, isNull);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox.shrink());
    },
    skip: Platform.isWindows,
  );
}

Future<({AccountKey key, Directory directory, ProfileVault vault})>
_previousInstallation(WidgetTester tester, {bool scoped = false}) async {
  final key = AccountKey.generate();
  final result = (await tester.runAsync(() async {
    final support = await Directory.systemTemp.createTemp(
      'last-leaf-code-upgrade-',
    );
    addTearDown(() => support.delete(recursive: true));
    final root = Directory(path.join(support.path, 'Lanleaf'));
    final tag = await key.discoveryTag();
    final directory =
        await (scoped ? Directory(path.join(root.path, 'accounts', tag)) : root)
            .create(recursive: true);
    final store = await NotebookStore.open(directory, key);
    await store.revise(
      id: newId(),
      author: newId(),
      basedOn: [],
      title: _noteTitle,
      body: 'Сохранённый текст',
    );
    return (support: support, directory: directory, vault: ProfileVault(root));
  }))!;
  const platform = MethodChannel('com.lanleaf/local');
  final messenger =
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
  final calls = <String>[];
  messenger.setMockMethodCallHandler(platform, (call) async {
    calls.add(call.method);
    return switch (call.method) {
      'applicationSupport' => result.support.path,
      'localInterfaces' => <String>[],
      'excludeBackup' => null,
      _ => throw StateError('Unexpected native call: ${call.method}'),
    };
  });
  addTearDown(() {
    messenger.setMockMethodCallHandler(platform, null);
    expect(
      calls.toSet().difference({
        'applicationSupport',
        'localInterfaces',
        'excludeBackup',
      }),
      isEmpty,
    );
  });
  return (key: key, directory: result.directory, vault: result.vault);
}

Finder _field(String name) => find.byWidgetPredicate(
  (widget) => widget is TextField && widget.decoration?.labelText == name,
);

Future<void> _setPassword(WidgetTester tester) async {
  await _waitFor(tester, 'Сохранить пароль');
  await tester.enterText(_field('Новый пароль Last Leaf'), _password);
  await tester.enterText(_field('Повторить пароль'), _password);
  await tester.tap(find.text('Сохранить пароль'));
}

Future<void> _waitFor(WidgetTester tester, String text) async {
  final label = find.text(text);
  final watch = Stopwatch()..start();
  do {
    await tester.runAsync(
      () => Future<void>.delayed(const Duration(milliseconds: 15)),
    );
    await tester.pump(const Duration(milliseconds: 25));
  } while (label.evaluate().isEmpty &&
      watch.elapsed < const Duration(seconds: 10));
  expect(label, findsOneWidget);
  await tester.pumpAndSettle();
}
