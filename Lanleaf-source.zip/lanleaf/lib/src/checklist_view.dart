import 'package:flutter/services.dart';
import 'package:material_ui/material_ui.dart';

import 'checklist.dart';

class ChecklistContinuation extends TextInputFormatter {
  const ChecklistContinuation();

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final cursor = newValue.selection.baseOffset;
    if (!newValue.composing.isCollapsed ||
        !newValue.selection.isCollapsed ||
        !oldValue.selection.isCollapsed ||
        cursor < 1 ||
        newValue.text.length != oldValue.text.length + 1 ||
        newValue.text[cursor - 1] != '\n') {
      return newValue;
    }
    final before = newValue.text.substring(0, cursor - 1);
    final lineStart = before.lastIndexOf('\n') + 1;
    final item = checklistItem(before.substring(lineStart));
    if (item == null) return newValue;
    final after = newValue.text.substring(cursor);
    final prefix = item.text.trim().isEmpty
        ? before.substring(0, lineStart)
        : '$before\n$uncheckedItem';
    return TextEditingValue(
      text: '$prefix$after',
      selection: TextSelection.collapsed(offset: prefix.length),
    );
  }
}

class ChecklistView extends StatelessWidget {
  const ChecklistView({
    super.key,
    required this.body,
    required this.onToggle,
    required this.onEdit,
  });

  final String body;
  final void Function(int line, bool checked) onToggle;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final lines = body.split('\n');
    final widgets = <Widget>[];
    final paragraph = <String>[];
    void flushParagraph() {
      if (paragraph.isEmpty) return;
      widgets.add(
        InkWell(
          onTap: onEdit,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Text(paragraph.join('\n'), style: theme.textTheme.bodyLarge),
          ),
        ),
      );
      paragraph.clear();
    }

    for (var i = 0; i < lines.length; i++) {
      final item = checklistItem(lines[i]);
      if (item == null) {
        paragraph.add(lines[i]);
        continue;
      }
      flushParagraph();
      widgets.add(
        Row(
          children: [
            Semantics(
              label: item.text.trim().isEmpty ? 'Пункт списка' : item.text,
              child: Checkbox(
                value: item.checked,
                shape: const CircleBorder(),
                onChanged: (value) => onToggle(i, value ?? false),
              ),
            ),
            Expanded(
              child: InkWell(
                onTap: onEdit,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 9),
                  child: Text(
                    item.text.isEmpty ? 'Пустой пункт' : item.text,
                    style: theme.textTheme.bodyLarge?.copyWith(
                      color: item.checked
                          ? theme.colorScheme.onSurfaceVariant
                          : null,
                      decoration: item.checked
                          ? TextDecoration.lineThrough
                          : null,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }
    flushParagraph();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: widgets,
    );
  }
}
