import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

import 'keys.dart';
import 'notes.dart';
import 'peers.dart';

const _peerBytes = 34;
const _frameLimit = maxNotebookBytes + 40;
const _executionTime = Duration(seconds: 12);
final _exchange = X25519();
final _sha256 = Sha256();

typedef MergeNotebook = Future<Notebook> Function(Notebook remote);

class PeerNeedsLegacyProtocol implements Exception {
  const PeerNeedsLegacyProtocol();
}

class SyncChannel {
  const SyncChannel({
    required this.incoming,
    required this.write,
    required this.dispose,
    this.finish,
    this.timeout = _executionTime,
    this.readTimeout = _executionTime,
    this.compress = false,
  });

  final Stream<Uint8List> incoming;
  final Future<void> Function(List<int>) write;
  final void Function() dispose;
  final Future<void> Function()? finish;
  final Duration timeout;
  final Duration readTimeout;
  final bool compress;
}

Future<PeerIdentity?> receiveSync(
  Socket socket,
  AccountKey account,
  Notebook Function() snapshot,
  MergeNotebook merge, {
  PeerIdentity? identity,
  bool requireLatest = false,
}) => receiveChannelSync(
  _socketChannel(socket),
  account,
  snapshot,
  merge,
  identity: identity,
  requireLatest: requireLatest,
);

Future<PeerIdentity?> receiveChannelSync(
  SyncChannel channel,
  AccountKey account,
  Notebook Function() snapshot,
  MergeNotebook merge, {
  PeerIdentity? identity,
  bool requireLatest = false,
}) => _useChannel(channel, (stream) async {
  final hello = await stream.read(36);
  final protocol = hello[2];
  final modern = (protocol == 2 || protocol == 3) && identity != null;
  if (hello[0] != 0x4c ||
      hello[1] != 0x4c ||
      hello[3] != 0 ||
      (requireLatest && protocol != 3) ||
      (protocol != 1 && !modern)) {
    throw const FormatException('Invalid sync protocol');
  }

  final clientPublic = hello.sublist(4);
  final keyPair = await _exchange.newKeyPair();
  final serverPublic = (await keyPair.extractPublicKey()).bytes;
  final keys = await _session(
    account,
    keyPair,
    clientPublic,
    clientPublic,
    serverPublic,
    protocol,
  );
  await channel.write([
    ...serverPublic,
    ...await seal(modern ? _encodePeer(identity) : const [], keys.proof),
  ]);

  final request = await unseal(
    await stream.read(72 + (modern ? _peerBytes : 0)),
    keys.client,
  );
  final peer = modern ? _decodePeer(request.sublist(32)) : null;
  final local = await _sha256.hash(_encode(snapshot(), protocol));
  final needsUpdate = local != Hash(request.sublist(0, 32));
  await channel.write(await seal([if (needsUpdate) 1 else 0], keys.server));

  if (needsUpdate) {
    final remote = await stream.readNotebook(keys.client);
    final merged = await merge(remote);
    await stream.writeNotebook(_encode(merged, protocol), keys.server);
  }
  if (modern) {
    await unseal(await stream.read(40), keys.client);
  }
  return peer;
});

Future<PeerIdentity?> sendSync(
  Socket socket,
  AccountKey account,
  Notebook Function() snapshot,
  MergeNotebook merge, {
  PeerIdentity? identity,
  int? protocol,
}) => sendChannelSync(
  _socketChannel(socket),
  account,
  snapshot,
  merge,
  identity: identity,
  version: protocol,
);

Future<PeerIdentity?> sendChannelSync(
  SyncChannel channel,
  AccountKey account,
  Notebook Function() snapshot,
  MergeNotebook merge, {
  PeerIdentity? identity,
  int? version,
}) => _useChannel(channel, (stream) async {
  final protocol = version ?? (identity == null ? 1 : 3);
  final modern = protocol >= 2;
  final keyPair = await _exchange.newKeyPair();
  final clientPublic = (await keyPair.extractPublicKey()).bytes;
  await channel.write([0x4c, 0x4c, protocol, 0, ...clientPublic]);

  final Uint8List serverPublic;
  try {
    serverPublic = await stream.read(32);
  } on SocketException {
    if (modern) throw const PeerNeedsLegacyProtocol();
    rethrow;
  }
  final keys = await _session(
    account,
    keyPair,
    serverPublic,
    clientPublic,
    serverPublic,
    protocol,
  );
  final proof = await unseal(
    await stream.read(40 + (modern ? _peerBytes : 0)),
    keys.proof,
  );
  final peer = modern ? _decodePeer(proof) : null;
  final contents = _encode(snapshot(), protocol);
  final digest = await _sha256.hash(contents);
  await channel.write(
    await seal([
      ...digest.bytes,
      if (modern) ..._encodePeer(identity!),
    ], keys.client),
  );
  final update = await unseal(await stream.read(41), keys.server);
  if (update.single == 1) {
    await stream.writeNotebook(contents, keys.client);
    final remote = await stream.readNotebook(keys.server);
    await merge(remote);
  } else if (update.single != 0) {
    throw const FormatException('Invalid sync response');
  }
  if (modern) {
    // The responder can keep the connection open until this copy is stored.
    await channel.write(await seal(const [], keys.client));
  }
  return peer;
});

Uint8List _encode(Notebook notebook, int protocol) =>
    notebook.encode(includePins: protocol >= 2, includeEdits: protocol >= 3);

List<int> _encodePeer(PeerIdentity peer) => [
  peer.port >> 8,
  peer.port & 255,
  ...ascii.encode(peer.device),
];

PeerIdentity _decodePeer(List<int> data) {
  if (data.length != _peerBytes) {
    throw const FormatException('Invalid peer identity');
  }
  final port = (data[0] << 8) | data[1];
  final device = ascii.decode(data.sublist(2));
  if (port == 0 || !isId(device)) {
    throw const FormatException('Invalid peer identity');
  }
  return PeerIdentity(device, port);
}

Future<SessionKeys> _session(
  AccountKey account,
  KeyPair keyPair,
  List<int> remotePublic,
  List<int> clientPublic,
  List<int> serverPublic,
  int protocol,
) async {
  final sharedSecret = await _exchange.sharedSecretKey(
    keyPair: keyPair,
    remotePublicKey: SimplePublicKey(remotePublic, type: KeyPairType.x25519),
  );
  if ((await sharedSecret.extractBytes()).every((byte) => byte == 0)) {
    throw const FormatException('Invalid public key');
  }
  return account.session(
    sharedSecret: sharedSecret,
    clientPublic: clientPublic,
    serverPublic: serverPublic,
    protocol: protocol,
  );
}

SyncChannel _socketChannel(Socket socket) {
  unawaited(
    socket.done.then<void>((_) {}, onError: (Object _, StackTrace _) {}),
  );
  return SyncChannel(
    incoming: socket,
    write: (bytes) async {
      socket.add(bytes);
      await socket.flush();
    },
    finish: () async {
      await socket.close();
    },
    dispose: socket.destroy,
  );
}

Future<T> _useChannel<T>(
  SyncChannel channel,
  Future<T> Function(_ChannelFrames connection) operation,
) async {
  final stream = _ChannelFrames(channel);
  try {
    return await (() async {
      final result = await operation(stream);
      await channel.finish?.call();
      return result;
    })().timeout(channel.timeout);
  } finally {
    channel.dispose();
    unawaited(
      stream.chunks.cancel().then<void>(
        (_) {},
        onError: (Object _, StackTrace _) {},
      ),
    );
  }
}

class _ChannelFrames {
  _ChannelFrames(this.channel) : chunks = StreamIterator(channel.incoming);

  final SyncChannel channel;
  final StreamIterator<Uint8List> chunks;
  Uint8List _chunk = Uint8List(0);
  int _offset = 0;

  Future<Uint8List> read(int size) async {
    final result = Uint8List(size);
    var position = 0;
    while (position < size) {
      if (_offset == _chunk.length) {
        if (!await chunks.moveNext().timeout(channel.readTimeout)) {
          throw const SocketException('Connection closed');
        }
        _chunk = chunks.current;
        _offset = 0;
      }
      final available = _chunk.length - _offset;
      final length = available < size - position ? available : size - position;
      result.setRange(position, position + length, _chunk, _offset);
      position += length;
      _offset += length;
    }
    return result;
  }

  Future<Uint8List> frame() async {
    final size = (await read(4)).buffer.asByteData().getUint32(0);
    if (size < 40 || size > _frameLimit + (channel.compress ? 1 : 0)) {
      throw const FormatException('Invalid frame size');
    }
    return read(size);
  }

  Future<Notebook> readNotebook(SecretKey key) async {
    final clear = await unseal(await frame(), key);
    if (!channel.compress) return Notebook.decode(clear);
    if (clear.isEmpty) throw const FormatException('Missing compression tag');
    if (clear.first == 0) return Notebook.decode(clear.sublist(1));
    if (clear.first != 1) {
      throw const FormatException('Unknown compression tag');
    }
    final output = _NotebookSink();
    gzip.decoder.startChunkedConversion(output)
      ..add(clear.sublist(1))
      ..close();
    return Notebook.decode(output.bytes.takeBytes());
  }

  Future<void> writeNotebook(Uint8List source, SecretKey key) async {
    final List<int> message;
    if (channel.compress) {
      final compressed = gzip.encode(source);
      message = compressed.length < source.length
          ? [1, ...compressed]
          : [0, ...source];
    } else {
      message = source;
    }
    final data = await seal(message, key);
    final length = ByteData(4)..setUint32(0, data.length);
    await channel.write(length.buffer.asUint8List());
    await channel.write(data);
  }
}

class _NotebookSink implements Sink<List<int>> {
  final bytes = BytesBuilder(copy: false);

  @override
  void add(List<int> data) {
    if (bytes.length + data.length > maxNotebookBytes) {
      throw const NotebookFull();
    }
    bytes.add(data);
  }

  @override
  void close() {}
}
