import 'package:flutter/gestures.dart';
import 'package:material_ui/material_ui.dart';

import 'checklist.dart';
import 'notes.dart';

class NoteRow extends StatefulWidget {
  const NoteRow({
    super.key,
    required this.note,
    required this.pinned,
    required this.selected,
    required this.revealed,
    required this.onOpen,
    required this.onReveal,
    required this.onPin,
    required this.onDelete,
    this.fontScale = 1,
  });

  final Note note;
  final bool pinned;
  final bool selected;
  final bool revealed;
  final VoidCallback? onOpen;
  final ValueChanged<bool> onReveal;
  final VoidCallback? onPin;
  final VoidCallback? onDelete;
  final double fontScale;

  @override
  State<NoteRow> createState() => _NoteRowState();
}

class _NoteRowState extends State<NoteRow> {
  static const _actionWidth = 144.0;
  final _editTip = GlobalKey<TooltipState>();
  double? _drag;
  Duration? _lastScroll;
  double _scroll = 0;

  void _handleScroll(PointerSignalEvent event) {
    if (widget.onOpen == null ||
        event is! PointerScrollEvent ||
        event.scrollDelta.dx.abs() <= event.scrollDelta.dy.abs()) {
      return;
    }
    GestureBinding.instance.pointerSignalResolver.register(event, (_) {
      final previous = _lastScroll;
      if (previous == null ||
          event.timeStamp - previous > const Duration(milliseconds: 200)) {
        _scroll = 0;
      }
      _lastScroll = event.timeStamp;
      _scroll += event.scrollDelta.dx;
      if (_scroll.abs() >= 36) {
        final open = _scroll > 0;
        _scroll = 0;
        if (open != widget.revealed) {
          widget.onReveal(open);
        } else if (!open) {
          _editTip.currentState?.ensureTooltipVisible();
        }
      }
    });
  }

  void _endDrag(DragEndDetails details) {
    final offset = _drag ?? (widget.revealed ? _actionWidth : 0);
    final velocity = details.primaryVelocity ?? 0;
    final open = velocity.abs() > 180
        ? velocity < 0
        : offset >= _actionWidth * 0.4;
    setState(() => _drag = null);
    if (!widget.revealed && offset < -30) {
      _editTip.currentState?.ensureTooltipVisible();
      return;
    }
    widget.onReveal(open);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final version = widget.note.latest;
    final editedAt = DateTime.fromMillisecondsSinceEpoch(version.time);
    final date = MaterialLocalizations.of(context).formatShortDate(editedAt);
    final time = TimeOfDay.fromDateTime(editedAt).format(context);
    final title = version.title.trim().isEmpty
        ? 'Без заголовка'
        : version.title;
    final preview = notePreview(version.body);
    final offset = _drag ?? (widget.revealed ? _actionWidth : 0.0);
    final edit = version.edit;
    final author =
        edit?.device ?? 'Устройство · ${version.author.substring(0, 4)}';

    return Tooltip(
      key: _editTip,
      waitDuration: const Duration(milliseconds: 650),
      message: [
        '$author · $date, $time',
        ...?edit?.describe(version.title),
      ].join('\n'),
      child: Listener(
        onPointerSignal: _handleScroll,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: GestureDetector(
              onHorizontalDragStart: widget.onOpen == null
                  ? null
                  : (_) {
                      _drag = widget.revealed ? _actionWidth : 0;
                    },
              onHorizontalDragUpdate: widget.onOpen == null
                  ? null
                  : (details) {
                      setState(() {
                        _drag = ((_drag ?? 0) - (details.primaryDelta ?? 0))
                            .clamp(widget.revealed ? 0.0 : -54.0, _actionWidth);
                      });
                    },
              onHorizontalDragEnd: widget.onOpen == null ? null : _endDrag,
              onHorizontalDragCancel: () => setState(() => _drag = null),
              child: Stack(
                children: [
                  if (offset < 0)
                    Positioned.fill(
                      child: ColoredBox(
                        color: colors.secondaryContainer,
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 12),
                            child: Icon(
                              Icons.history_rounded,
                              color: colors.onSecondaryContainer,
                            ),
                          ),
                        ),
                      ),
                    ),
                  Positioned.fill(
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: ExcludeFocus(
                        excluding: !widget.revealed,
                        child: ExcludeSemantics(
                          excluding: !widget.revealed,
                          child: IgnorePointer(
                            ignoring: !widget.revealed,
                            child: SizedBox(
                              width: _actionWidth,
                              height: double.infinity,
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  _Action(
                                    label: widget.pinned
                                        ? 'Открепить'
                                        : 'Закрепить',
                                    icon: widget.pinned
                                        ? Icons.push_pin_rounded
                                        : Icons.push_pin_outlined,
                                    background: colors.primaryContainer,
                                    foreground: colors.onPrimaryContainer,
                                    onTap: widget.onPin,
                                  ),
                                  _Action(
                                    label: 'Удалить',
                                    icon: Icons.delete_outline_rounded,
                                    background: colors.errorContainer,
                                    foreground: colors.onErrorContainer,
                                    onTap: widget.onDelete,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  TweenAnimationBuilder<double>(
                    tween: Tween(end: offset),
                    duration: _drag == null
                        ? const Duration(milliseconds: 160)
                        : Duration.zero,
                    builder: (context, value, child) => Transform.translate(
                      offset: Offset(-value, 0),
                      child: child,
                    ),
                    child: Material(
                      color: widget.selected
                          ? colors.secondaryContainer
                          : colors.surfaceContainerLow,
                      child: InkWell(
                        onTap: widget.revealed
                            ? () => widget.onReveal(false)
                            : widget.onOpen,
                        onSecondaryTap: widget.onOpen == null
                            ? null
                            : () => widget.onReveal(!widget.revealed),
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(13, 10, 4, 10),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        if (widget.pinned)
                                          Padding(
                                            padding: const EdgeInsets.only(
                                              right: 5,
                                            ),
                                            child: Tooltip(
                                              message: 'Закреплено',
                                              child: Icon(
                                                Icons.push_pin_rounded,
                                                size: 15,
                                                color: colors.primary,
                                              ),
                                            ),
                                          ),
                                        Expanded(
                                          child: Text(
                                            title,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(
                                              fontSize: 14 * widget.fontScale,
                                              fontWeight: FontWeight.w700,
                                              color: widget.selected
                                                  ? colors.onSecondaryContainer
                                                  : colors.onSurface,
                                            ),
                                          ),
                                        ),
                                        if (widget.note.hasConflict)
                                          Padding(
                                            padding: const EdgeInsets.only(
                                              left: 4,
                                            ),
                                            child: Tooltip(
                                              message: 'Несколько версий',
                                              child: Icon(
                                                Icons.layers_outlined,
                                                size: 16,
                                                color: colors.primary,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                    if (preview.isNotEmpty)
                                      Text(
                                        preview,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 13 * widget.fontScale,
                                          color: colors.onSurfaceVariant,
                                        ),
                                      ),
                                    const SizedBox(height: 4),
                                    Text(
                                      date,
                                      style: TextStyle(
                                        color: colors.onSurfaceVariant,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              IconButton(
                                tooltip: 'Действия с заметкой',
                                icon: const Icon(
                                  Icons.more_horiz_rounded,
                                  size: 19,
                                ),
                                onPressed: widget.onOpen == null
                                    ? null
                                    : () => widget.onReveal(!widget.revealed),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _Action extends StatelessWidget {
  const _Action({
    required this.label,
    required this.icon,
    required this.background,
    required this.foreground,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final Color background;
  final Color foreground;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) => Expanded(
    child: Material(
      color: background,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: foreground, size: 19),
              const SizedBox(height: 4),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  label,
                  style: TextStyle(
                    color: foreground,
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
