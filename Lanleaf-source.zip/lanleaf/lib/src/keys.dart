import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

import 'notes.dart';

final _hkdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
final _aead = Xchacha20.poly1305Aead();

class AccountKey {
  AccountKey._(this._bytes);

  factory AccountKey.generate() => AccountKey._(randomBytes(32));

  factory AccountKey.parse(String input) {
    final code = input.replaceAll(RegExp(r'\s'), '');
    if (!RegExp(r'^LL1-[A-Za-z0-9_-]{43}$').hasMatch(code)) {
      throw const FormatException('Invalid account code');
    }
    final key = AccountKey._(base64Url.decode('${code.substring(4)}='));
    if (key.code != code) throw const FormatException('Invalid account code');
    return key;
  }

  final Uint8List _bytes;
  String get code => 'LL1-${base64Url.encode(_bytes).replaceAll('=', '')}';

  Future<SecretKey> diskKey() => _hkdf.deriveKey(
    secretKey: SecretKey(_bytes),
    info: utf8.encode('lanleaf-v1/disk'),
  );

  Future<String> discoveryTag() async {
    final value = await _hkdf.deriveKey(
      secretKey: SecretKey(_bytes),
      info: utf8.encode('lanleaf-v1/discovery'),
    );
    return (await value.extractBytes())
        .take(12)
        .map((byte) => byte.toRadixString(16).padLeft(2, '0'))
        .join();
  }

  Future<SessionKeys> session({
    required SecretKey sharedSecret,
    required List<int> clientPublic,
    required List<int> serverPublic,
  }) async {
    final master = SecretKey([..._bytes, ...await sharedSecret.extractBytes()]);
    final transcript = [...clientPublic, ...serverPublic];
    Future<SecretKey> derive(String purpose) => _hkdf.deriveKey(
      secretKey: master,
      nonce: transcript,
      info: utf8.encode('lanleaf-v1/$purpose'),
    );
    final keys = await Future.wait([
      derive('server-proof'),
      derive('client-data'),
      derive('server-data'),
    ]);
    return SessionKeys(keys[0], keys[1], keys[2]);
  }
}

class SessionKeys {
  const SessionKeys(this.proof, this.client, this.server);

  final SecretKey proof;
  final SecretKey client;
  final SecretKey server;
}

Future<Uint8List> seal(List<int> data, SecretKey key) async {
  final box = await _aead.encrypt(data, secretKey: key, nonce: randomBytes(24));
  return box.concatenation();
}

Future<List<int>> unseal(List<int> data, SecretKey key) {
  if (data.length < 40) {
    throw const FormatException('Invalid encrypted message');
  }
  final box = SecretBox.fromConcatenation(data, nonceLength: 24, macLength: 16);
  return _aead.decrypt(box, secretKey: key);
}
