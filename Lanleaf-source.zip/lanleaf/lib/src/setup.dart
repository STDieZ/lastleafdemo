import 'package:material_ui/material_ui.dart';

import 'code_field.dart';
import 'keys.dart';
import 'peers.dart';
import 'theme.dart';

class SetupPage extends StatefulWidget {
  const SetupPage({super.key, required this.onConnect});

  final Future<void> Function(ConnectionCode code) onConnect;

  @override
  State<SetupPage> createState() => _SetupPageState();
}

class _SetupPageState extends State<SetupPage> {
  final _code = TextEditingController();
  bool _joining = false;
  bool _busy = false;
  String? _error;

  Future<void> _connect({required bool join}) async {
    if (_busy) return;
    final ConnectionCode code;
    try {
      code = join
          ? ConnectionCode.parse(_code.text)
          : ConnectionCode(AccountKey.generate());
    } on FormatException {
      setState(
        () => _error = 'Проверьте код подключения. Он начинается с LL1-.',
      );
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.onConnect(code);
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'Не удалось сохранить аккаунт на устройстве.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final text = theme.textTheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: LeafMark(large: true),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    appName,
                    style: text.displayMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _joining
                        ? 'Скопируйте код из настроек Last Leaf на другом устройстве. Откройте приложение на обоих устройствах в одной сети Wi‑Fi.'
                        : 'Текстовые заметки на ваших устройствах. Синхронизация по локальной сети, без облака.',
                    style: text.bodyLarge?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 28),
                  if (_joining) ...[
                    CodeField(
                      controller: _code,
                      enabled: !_busy,
                      onSubmitted: (_) => _connect(join: true),
                    ),
                    const SizedBox(height: 14),
                  ],
                  if (_error != null) ...[
                    Text(
                      _error!,
                      style: TextStyle(color: theme.colorScheme.error),
                    ),
                    const SizedBox(height: 12),
                  ],
                  FilledButton.icon(
                    onPressed: _busy ? null : () => _connect(join: _joining),
                    icon: Icon(
                      _joining ? Icons.link_rounded : Icons.add_rounded,
                    ),
                    label: Text(
                      _joining
                          ? 'Подключить устройство'
                          : 'Создать локальный аккаунт',
                    ),
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: _busy
                        ? null
                        : () => setState(() {
                            _joining = !_joining;
                            _error = null;
                            if (!_joining) _code.clear();
                          }),
                    child: Text(
                      _joining ? 'Назад' : 'У меня есть код подключения',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
