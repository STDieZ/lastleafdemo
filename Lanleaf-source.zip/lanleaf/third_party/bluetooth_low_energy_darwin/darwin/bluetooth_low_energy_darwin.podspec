#
# To learn more about a Podspec see http://guides.cocoapods.org/syntax/podspec.html.
# Run `pod lib lint bluetooth_low_energy_darwin.podspec` to validate before publishing.
#
Pod::Spec.new do |s|
  s.name             = 'bluetooth_low_energy_darwin'
  s.version          = '0.0.1'
  s.summary          = 'A new Flutter plugin project.'
  s.description      = <<-DESC
A new Flutter plugin project.
                       DESC
  s.homepage         = 'http://example.com'
  s.license          = { :file => '../LICENSE' }
  s.author           = { 'Your Company' => 'email@example.com' }
  s.source           = { :path => '.' }
  s.source_files = 'bluetooth_low_energy_darwin/Sources/bluetooth_low_energy_darwin/**/*'

  # Flutter.framework does not contain a i386 slice.
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES', 'EXCLUDED_ARCHS[sdk=iphonesimulator*]' => 'i386' }
  s.swift_version = '5.0'

  # If your plugin requires a privacy manifest, for example if it uses any
  # required reason APIs, update the PrivacyInfo.xcprivacy file to describe your
  # plugin's privacy impact, and then uncomment this line. For more information,
  # see https://developer.apple.com/documentation/bundleresources/privacy_manifest_files
  # s.resource_bundles = {'bluetooth_low_energy_darwin_privacy' => ['bluetooth_low_energy_darwin/Sources/bluetooth_low_energy_darwin/PrivacyInfo.xcprivacy']}
  
  s.ios.dependency 'Flutter'
  s.ios.deployment_target = '13.0'

  s.osx.dependency 'FlutterMacOS'
  s.osx.deployment_target = '10.15'
end
