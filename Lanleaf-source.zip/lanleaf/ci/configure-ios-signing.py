"""Set Runner signing and export options from the selected Apple profile."""

import argparse
import json
import plistlib
import re
from datetime import datetime, timezone
from pathlib import Path
from uuid import UUID


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('distribution', choices=('ad-hoc', 'testflight'))
    parser.add_argument('profile', type=Path)
    parser.add_argument('project', type=Path)
    parser.add_argument('export_options', type=Path)
    args = parser.parse_args()

    with args.profile.open('rb') as source:
        profile = plistlib.load(source)

    if profile['ExpirationDate'].replace(tzinfo=timezone.utc) <= datetime.now(timezone.utc):
        raise SystemExit('The provisioning profile has expired.')
    if 'iOS' not in profile.get('Platform', []):
        raise SystemExit('Choose an iOS provisioning profile.')
    entitlements = profile['Entitlements']
    if entitlements.get('get-task-allow') or profile.get('ProvisionsAllDevices'):
        raise SystemExit('Choose an Ad Hoc or App Store Connect distribution profile.')
    if bool(profile.get('ProvisionedDevices')) != (args.distribution == 'ad-hoc'):
        raise SystemExit('The provisioning profile does not match the selected distribution.')

    team = profile['TeamIdentifier'][0]
    _, _, bundle_id = entitlements['application-identifier'].partition('.')
    if not re.fullmatch(r'[A-Z0-9]{10}', team) or not re.fullmatch(
        r'[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+', bundle_id
    ):
        raise SystemExit('The provisioning profile must use an explicit iOS Bundle ID.')
    name = profile['Name']
    uuid = UUID(profile['UUID'])

    indent = '\t' * 4
    anchor = f'{indent}PRODUCT_BUNDLE_IDENTIFIER = com.lanleaf.lanleaf;'
    project = args.project.read_text(encoding='utf-8')
    if project.count(anchor) != 3:
        raise SystemExit('Could not locate the three Runner signing configurations.')
    settings = {
        'PRODUCT_BUNDLE_IDENTIFIER': bundle_id,
        'DEVELOPMENT_TEAM': team,
        'CODE_SIGN_STYLE': 'Manual',
        '"CODE_SIGN_IDENTITY[sdk=iphoneos*]"': 'Apple Distribution',
        'PROVISIONING_PROFILE_SPECIFIER': name,
    }
    replacement = '\n'.join(
        f'{indent}{key} = {json.dumps(value, ensure_ascii=False)};'
        for key, value in settings.items()
    )
    args.project.write_text(project.replace(anchor, replacement), encoding='utf-8')

    with args.export_options.open('wb') as destination:
        plistlib.dump({
            'method': 'release-testing' if args.distribution == 'ad-hoc' else 'app-store-connect',
            'teamID': team,
            'signingStyle': 'manual',
            'signingCertificate': 'Apple Distribution',
            'provisioningProfiles': {bundle_id: name},
            'manageAppVersionAndBuildNumber': False,
        }, destination)
    print(str(uuid).upper())


if __name__ == '__main__':
    main()
