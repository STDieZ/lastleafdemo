import 'dart:async';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:bluetooth_low_energy/bluetooth_low_energy.dart';

import 'bluetooth_bluez.dart';
import 'bluetooth_mailbox.dart';
import 'keys.dart';
import 'notebook_store.dart';
import 'peers.dart';
import 'wire_sync.dart';

final _characteristicUuid = UUID.fromString(
  'b11cbb89-0048-44ed-a781-bd072ec80210',
);
const _operationTime = Duration(seconds: 8);

class BluetoothSync {
  BluetoothSync(this.key, this.store, this.identity, this.onSynced);

  final AccountKey key;
  final NotebookStore store;
  final PeerIdentity Function() identity;
  final void Function() onSynced;
  late final _uuid = key.discoveryTag().then(
    (tag) => UUID.fromString(
      '1ea53c01-${tag.substring(0, 4)}-${tag.substring(4, 8)}-${tag.substring(8, 12)}-${tag.substring(12)}',
    ),
  );
  late final _mailbox = BluetoothMailbox(_receive);
  CentralManager? _central;
  PeripheralManager? _peripheral;
  GATTService? _service;
  BluezAdvertisement? _bluez;
  StreamSubscription<GATTCharacteristicWriteRequestedEventArgs>? _writes;
  StreamSubscription<GATTCharacteristicReadRequestedEventArgs>? _reads;
  final _connections = <Peripheral>{};
  Future<(bool, bool)>? _starting;
  Future<void>? _closing;
  Completer<void>? _scan;
  bool _closed = false;

  Future<(bool, bool)> prepare({bool askPermission = false}) =>
      _starting ??= _prepare(askPermission)
          .whenComplete(() => _starting = null);

  Future<(bool, bool)> _prepare(bool askPermission) async {
    if (_closed) return (false, false);
    final central = _central ??= CentralManager();
    final scanning = await _poweredOn(central, askPermission);
    if (_closed) return (false, false);
    if (_service != null || _bluez != null) return (scanning, true);
    final serviceUuid = await _uuid;
    try {
      if (Platform.isLinux) {
        _bluez = await BluezAdvertisement.start(
          serviceUuid.toString(),
          _characteristicUuid.toString(),
          _mailbox,
        );
      } else {
        final peripheral = _peripheral ??= PeripheralManager();
        if (!await _poweredOn(peripheral, askPermission) || _closed) {
          return (scanning, false);
        }
        await _advertise(peripheral, serviceUuid);
      }
      return (scanning, true);
    } catch (_) {
      await _stopAdvertising();
      return (scanning, false);
    }
  }

  Future<bool> _poweredOn(BluetoothLowEnergyManager manager, bool ask) async {
    var state = manager.state;
    if (state == BluetoothLowEnergyState.unknown) {
      try {
        state =
            (await manager.stateChanged
                    .firstWhere(
                      (event) => event.state != BluetoothLowEnergyState.unknown,
                    )
                    .timeout(const Duration(seconds: 4)))
                .state;
      } on TimeoutException {
        return false;
      }
    }
    if (ask &&
        Platform.isAndroid &&
        state == BluetoothLowEnergyState.unauthorized) {
      if (await manager.authorize()) state = manager.state;
    }
    return state == BluetoothLowEnergyState.poweredOn;
  }

  Future<void> _advertise(PeripheralManager manager, UUID serviceUuid) async {
    final characteristic = GATTCharacteristic.mutable(
      uuid: _characteristicUuid,
      properties: [
        GATTCharacteristicProperty.read,
        GATTCharacteristicProperty.write,
      ],
      permissions: [
        GATTCharacteristicPermission.read,
        GATTCharacteristicPermission.write,
      ],
      descriptors: [],
    );
    _writes = manager.characteristicWriteRequested.listen((event) async {
      if (event.characteristic.uuid != _characteristicUuid) return;
      try {
        final request = event.request;
        if (request.offset != 0) {
          await manager.respondWriteRequestWithError(
            request,
            error: GATTError.invalidOffset,
          );
        } else if (_mailbox.write(
          event.central.uuid.toString(),
          request.value,
        )) {
          await manager.respondWriteRequest(request);
        } else {
          await manager.respondWriteRequestWithError(
            request,
            error: GATTError.writeNotPermitted,
          );
        }
      } catch (_) {}
    });
    _reads = manager.characteristicReadRequested.listen((event) async {
      if (event.characteristic.uuid != _characteristicUuid) return;
      try {
        if (event.request.offset != 0) {
          await manager.respondReadRequestWithError(
            event.request,
            error: GATTError.invalidOffset,
          );
          return;
        }
        var packetSize = bleDefaultPacket;
        try {
          packetSize = await manager
              .getMaximumNotifyLength(event.central)
              .timeout(const Duration(seconds: 1));
        } catch (_) {}
        await manager.respondReadRequestWithValue(
          event.request,
          value: _mailbox.read(event.central.uuid.toString(), packetSize - 1),
        );
      } catch (_) {}
    });
    final service = _service = GATTService(
      uuid: serviceUuid,
      isPrimary: true,
      includedServices: [],
      characteristics: [characteristic],
    );
    await manager.addService(service).timeout(_operationTime);
    await manager
        .startAdvertising(Advertisement(serviceUUIDs: [serviceUuid]))
        .timeout(_operationTime);
  }

  Future<void> _receive(SyncChannel channel) async {
    final local = identity();
    final peer = await receiveChannelSync(
      channel,
      key,
      () => store.notebook,
      store.merge,
      identity: local,
      requireLatest: true,
    );
    if (!_closed && peer?.device != local.device) onSynced();
  }

  Future<bool> exchange() async {
    final (canScan, _) = await prepare();
    if (!canScan || _closed) return false;
    final central = _central!;
    final uuid = await _uuid;
    final found = <UUID, Peripheral>{};
    final scan = _scan = Completer<void>();
    final discovery = central.discovered.listen((event) {
      if (found.length < 4 && event.advertisement.serviceUUIDs.contains(uuid)) {
        found[event.peripheral.uuid] = event.peripheral;
      }
      if (found.length == 4 && !scan.isCompleted) scan.complete();
    });
    try {
      await central
          .startDiscovery(serviceUUIDs: [uuid])
          .timeout(_operationTime);
      await scan.future.timeout(const Duration(seconds: 4), onTimeout: () {});
    } finally {
      _scan = null;
      await discovery.cancel();
      await _quiet(central.stopDiscovery);
    }
    var synced = false;
    for (final peripheral in found.values) {
      if (_closed) break;
      try {
        if (await _send(central, peripheral, uuid)) synced = true;
      } catch (_) {
        // Continue looking for another nearby device with the same account.
      }
    }
    return synced;
  }

  Future<bool> _send(
    CentralManager manager,
    Peripheral peripheral,
    UUID uuid,
  ) async {
    _connections.add(peripheral);
    try {
      await manager.connect(peripheral).timeout(_operationTime);
      final services = await manager
          .discoverGATT(peripheral)
          .timeout(_operationTime);
      final characteristic = services
          .where((service) => service.uuid == uuid)
          .firstOrNull
          ?.characteristics
          .where((item) => item.uuid == _characteristicUuid)
          .firstOrNull;
      if (characteristic == null || _closed) return false;
      if (Platform.isAndroid) {
        try {
          await manager
              .requestMTU(peripheral, mtu: 247)
              .timeout(const Duration(seconds: 3));
        } catch (_) {}
      }
      var packetSize = bleDefaultPacket;
      try {
        packetSize = await manager
            .getMaximumWriteLength(
              peripheral,
              type: GATTCharacteristicWriteType.withoutResponse,
            )
            .timeout(_operationTime);
      } catch (_) {}
      final payloadSize = packetSize.clamp(bleDefaultPacket, bleMaxPacket) - 1;
      var finished = false;
      Future<void> write(Uint8List value) => manager
          .writeCharacteristic(
            peripheral,
            characteristic,
            value: value,
            type: GATTCharacteristicWriteType.withResponse,
          )
          .timeout(_operationTime);
      Stream<Uint8List> read() async* {
        while (!finished && !_closed) {
          final response = await manager
              .readCharacteristic(peripheral, characteristic)
              .timeout(_operationTime);
          if (response.isEmpty || response.first == bleDone) return;
          if (response.first == bleData && response.length > 1) {
            yield Uint8List.sublistView(response, 1);
          } else if (response.length == 1 && response.first == bleStart) {
            await Future<void>.delayed(const Duration(milliseconds: 42));
          } else {
            throw const FormatException('Invalid Bluetooth fragment');
          }
        }
      }

      await write(Uint8List.fromList([bleStart]));
      final local = identity();
      final peer = await sendChannelSync(
        SyncChannel(
          incoming: read(),
          write: (bytes) async {
            for (var index = 0; index < bytes.length; index += payloadSize) {
              if (_closed || finished) {
                throw const SocketException('Bluetooth sync is stopped');
              }
              final end = min(index + payloadSize, bytes.length);
              final chunk = Uint8List(end - index + 1)..[0] = bleData;
              chunk.setRange(1, chunk.length, bytes, index);
              await write(chunk);
            }
          },
          dispose: () => finished = true,
          timeout: bleSessionTimeout,
          readTimeout: const Duration(seconds: 12),
          compress: true,
        ),
        key,
        () => store.notebook,
        store.merge,
        identity: local,
      );
      if (peer?.device == local.device || _closed) return false;
      onSynced();
      return true;
    } finally {
      await _quiet(() => manager.disconnect(peripheral));
      _connections.remove(peripheral);
    }
  }

  Future<void> _stopAdvertising() async {
    final bluez = _bluez;
    _bluez = null;
    if (bluez != null) await _quiet(bluez.close);
    await _reads?.cancel();
    await _writes?.cancel();
    _reads = null;
    _writes = null;
    final service = _service;
    _service = null;
    if (_peripheral case final manager? when service != null) {
      await _quiet(manager.stopAdvertising);
      await _quiet(() => manager.removeService(service));
    }
  }

  Future<void> close() => _closing ??= _close();

  Future<void> _close() async {
    _closed = true;
    _mailbox.close();
    if (_scan case final scan? when !scan.isCompleted) scan.complete();
    if (_central case final manager?) {
      await Future.wait(
        _connections.toList().map(
          (peer) => _quiet(() => manager.disconnect(peer)),
        ),
      );
    }
    final starting = _starting;
    if (starting != null) {
      await _quiet(() async {
        await starting;
      });
    }
    await _stopAdvertising();
  }
}

Future<void> _quiet(Future<void> Function() operation) async {
  try {
    await operation().timeout(const Duration(seconds: 5));
  } catch (_) {}
}
