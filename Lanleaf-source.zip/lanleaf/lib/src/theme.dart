import 'package:material_ui/material_ui.dart';

const appName = 'Last Leaf';

enum LeafPalette {
  green('Зелёный', Color(0xff35664e)),
  blue('Синий', Color(0xff3a65b7)),
  teal('Бирюзовый', Color(0xff218180)),
  purple('Фиолетовый', Color(0xff7956ae)),
  pink('Розовый', Color(0xffb74d81)),
  red('Красный', Color(0xffc2484e)),
  orange('Оранжевый', Color(0xffb95e21)),
  yellow('Жёлтый', Color(0xffa47716));

  const LeafPalette(this.label, this.seed);

  final String label;
  final Color seed;
}

ThemeData buildLeafTheme(LeafPalette palette, Brightness brightness) {
  final generated = ColorScheme.fromSeed(
    seedColor: palette.seed,
    brightness: brightness,
  );
  final colors = palette == LeafPalette.green && brightness == Brightness.light
      ? generated.copyWith(
          primary: const Color(0xff274e3e),
          onPrimary: Colors.white,
          surface: const Color(0xfffaf9f5),
          onSurface: const Color(0xff252c26),
          onSurfaceVariant: const Color(0xff59645a),
          surfaceContainerLow: const Color(0xffeeeee6),
          secondaryContainer: const Color(0xffdce7db),
          outlineVariant: const Color(0xffdaddd1),
        )
      : generated;
  final outline = OutlineInputBorder(
    borderRadius: BorderRadius.circular(12),
    borderSide: BorderSide(color: colors.outlineVariant),
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: colors,
    scaffoldBackgroundColor: colors.surface,
    dividerColor: colors.outlineVariant,
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: colors.surface,
      border: outline,
      enabledBorder: outline,
    ),
    textTheme: const TextTheme(
      headlineMedium: TextStyle(
        fontWeight: FontWeight.w700,
        letterSpacing: -0.7,
      ),
      titleMedium: TextStyle(fontWeight: FontWeight.w700),
      bodyMedium: TextStyle(height: 1.35),
      bodyLarge: TextStyle(height: 1.4),
    ),
  );
}

class LeafMark extends StatelessWidget {
  const LeafMark({super.key, this.large = false});

  final bool large;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      width: large ? 64 : 40,
      height: large ? 64 : 40,
      decoration: BoxDecoration(
        color: colors.primary,
        borderRadius: BorderRadius.circular(large ? 20 : 13),
      ),
      child: Icon(
        Icons.eco_outlined,
        color: colors.onPrimary,
        size: large ? 34 : 23,
      ),
    );
  }
}
