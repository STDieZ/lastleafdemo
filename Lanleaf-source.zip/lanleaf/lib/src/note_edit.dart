import 'package:characters/characters.dart';

import 'checklist.dart';
import 'device_settings.dart';

class NoteEdit {
  const NoteEdit._({
    required this.device,
    this.previousTitle,
    this.removed,
    this.added,
    this.checkItem,
    this.checked,
    this.created = false,
    this.resolved = false,
  });

  factory NoteEdit.fromJson(Object value) {
    if (value
        case {
          'device': final String device,
          'title': final String? title,
          'removed': final String? removed,
          'added': final String? added,
          'item': final String? item,
          'checked': final bool? checked,
          'created': final bool created,
          'resolved': final bool resolved,
        }
        when device.isNotEmpty &&
            device == normalizeDeviceName(device) &&
            [
              title,
              removed,
              added,
              item,
            ].every((s) => s == null || s.length <= 160) &&
            (item == null) == (checked == null)) {
      return NoteEdit._(
        device: device,
        previousTitle: title,
        removed: removed,
        added: added,
        checkItem: item,
        checked: checked,
        created: created,
        resolved: resolved,
      );
    }
    throw const FormatException('Invalid edit metadata');
  }

  factory NoteEdit.between({
    required String device,
    required String? beforeTitle,
    required String beforeBody,
    required String title,
    required String body,
    bool resolved = false,
  }) {
    if (beforeTitle == null) return NoteEdit._(device: device, created: true);
    final previousTitle = beforeTitle == title ? null : _preview(beforeTitle);
    final check = _singleCheckChange(beforeBody, body);
    final (removed, added) = check == null
        ? _textDifference(beforeBody, body)
        : (null, null);
    return NoteEdit._(
      device: device,
      previousTitle: previousTitle,
      removed: removed,
      added: added,
      checkItem: check == null ? null : _preview(check.text),
      checked: check?.checked,
      resolved: resolved,
    );
  }

  final String device;
  final String? previousTitle;
  final String? removed;
  final String? added;
  final String? checkItem;
  final bool? checked;
  final bool created;
  final bool resolved;

  Map<String, Object?> toJson() => {
    'device': device,
    'title': previousTitle,
    'removed': removed,
    'added': added,
    'item': checkItem,
    'checked': checked,
    'created': created,
    'resolved': resolved,
  };

  List<String> describe(String title) => [
    if (created) 'Создана заметка',
    if (resolved) 'Выбрана версия заметки',
    if (previousTitle != null)
      'Заголовок «${_orEmpty(previousTitle!, 'без заголовка')}» → «${_orEmpty(_preview(title), 'без заголовка')}»',
    if (removed != null) '− ${_orEmpty(removed!, 'пробелы и переносы')}',
    if (added != null) '+ ${_orEmpty(added!, 'пробелы и переносы')}',
    if (checkItem != null)
      '${checked! ? 'Отмечен' : 'Снят флажок у'} пункт «${_orEmpty(checkItem!, 'без текста')}»',
  ];
}

String _orEmpty(String value, String fallback) =>
    value.isEmpty ? fallback : value;

String _preview(String value) {
  final runes = value.replaceAll(RegExp(r'\s+'), ' ').trim().runes;
  final preview = runes.take(61).toList();
  return preview.length <= 60
      ? String.fromCharCodes(preview)
      : '${String.fromCharCodes(preview.take(60))}…';
}

({String text, bool checked})? _singleCheckChange(String before, String after) {
  if (before == after) return null;
  final previous = before.split('\n');
  final next = after.split('\n');
  if (previous.length != next.length) return null;
  ({String text, bool checked})? change;
  for (var i = 0; i < next.length; i++) {
    if (previous[i] == next[i]) continue;
    final oldItem = checklistItem(previous[i]);
    final newItem = checklistItem(next[i]);
    if (change != null ||
        oldItem == null ||
        newItem == null ||
        oldItem.text != newItem.text ||
        oldItem.checked == newItem.checked) {
      return null;
    }
    change = newItem;
  }
  return change;
}

(String?, String?) _textDifference(String before, String after) {
  if (before == after) return (null, null);
  final previous = before.characters.toList();
  final next = after.characters.toList();
  var prefix = 0;
  var oldEnd = previous.length;
  var newEnd = next.length;
  while (prefix < oldEnd &&
      prefix < newEnd &&
      previous[prefix] == next[prefix]) {
    prefix++;
  }
  while (oldEnd > prefix &&
      newEnd > prefix &&
      previous[oldEnd - 1] == next[newEnd - 1]) {
    oldEnd--;
    newEnd--;
  }
  return (
    oldEnd == prefix
        ? null
        : _preview(previous.getRange(prefix, oldEnd).join()),
    newEnd == prefix ? null : _preview(next.getRange(prefix, newEnd).join()),
  );
}
