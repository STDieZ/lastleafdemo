import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';

import 'keys.dart';
import 'theme.dart';

class SetupPage extends StatefulWidget {
  const SetupPage({super.key, required this.onConnect});

  final Future<void> Function(AccountKey key) onConnect;

  @override
  State<SetupPage> createState() => _SetupPageState();
}

class _SetupPageState extends State<SetupPage> {
  final _code = TextEditingController();
  bool _joining = false;
  bool _busy = false;
  String? _error;

  Future<void> _connect({required bool join}) async {
    if (_busy) return;
    final AccountKey key;
    try {
      key = join ? AccountKey.parse(_code.text) : AccountKey.generate();
    } on FormatException {
      setState(
        () => _error = 'Проверьте код подключения. Он начинается с LL1-.',
      );
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await widget.onConnect(key);
    } catch (_) {
      if (mounted) {
        setState(() => _error = 'Не удалось сохранить аккаунт на устройстве.');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: LeafMark(large: true),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Лист',
                    style: text.displayMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    _joining
                        ? 'Откройте настройки «Листа» на другом устройстве и скопируйте код подключения.'
                        : 'Текстовые заметки на ваших устройствах. Синхронизация по локальной сети, без облака.',
                    style: text.bodyLarge?.copyWith(color: muted),
                  ),
                  const SizedBox(height: 28),
                  if (_joining) ...[
                    TextField(
                      controller: _code,
                      enabled: !_busy,
                      obscureText: true,
                      autocorrect: false,
                      enableSuggestions: false,
                      textInputAction: TextInputAction.go,
                      onSubmitted: (_) => _connect(join: true),
                      decoration: InputDecoration(
                        labelText: 'Код подключения',
                        suffixIcon: IconButton(
                          tooltip: 'Вставить из буфера',
                          icon: const Icon(Icons.content_paste_rounded),
                          onPressed: _busy
                              ? null
                              : () async {
                                  final data = await Clipboard.getData(
                                    Clipboard.kTextPlain,
                                  );
                                  if (mounted && data?.text != null) {
                                    _code.text = data!.text!;
                                  }
                                },
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                  ],
                  if (_error != null) ...[
                    Text(
                      _error!,
                      style: TextStyle(
                        color: Theme.of(context).colorScheme.error,
                      ),
                    ),
                    const SizedBox(height: 12),
                  ],
                  FilledButton.icon(
                    onPressed: _busy ? null : () => _connect(join: _joining),
                    icon: Icon(
                      _joining ? Icons.link_rounded : Icons.add_rounded,
                    ),
                    label: Text(
                      _joining
                          ? 'Подключить устройство'
                          : 'Создать локальный аккаунт',
                    ),
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                    ),
                  ),
                  const SizedBox(height: 8),
                  TextButton(
                    onPressed: _busy
                        ? null
                        : () => setState(() {
                            _joining = !_joining;
                            _error = null;
                            if (!_joining) _code.clear();
                          }),
                    child: Text(
                      _joining ? 'Назад' : 'У меня есть код подключения',
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
