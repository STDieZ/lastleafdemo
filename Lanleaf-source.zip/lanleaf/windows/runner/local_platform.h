#ifndef RUNNER_LOCAL_PLATFORM_H_
#define RUNNER_LOCAL_PLATFORM_H_

#include <flutter/binary_messenger.h>

void RegisterLocalPlatform(flutter::BinaryMessenger* messenger);

#endif
