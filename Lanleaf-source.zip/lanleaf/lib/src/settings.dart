import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';

import 'lan_sync.dart';
import 'notes.dart';
import 'platform_services.dart';

class SettingsDialog extends StatefulWidget {
  const SettingsDialog({super.key, required this.account, required this.sync});

  final LocalAccount account;
  final LanSync sync;

  @override
  State<SettingsDialog> createState() => _SettingsDialogState();
}

class _SettingsDialogState extends State<SettingsDialog> {
  final _target = TextEditingController();
  var _showCode = false;
  var _busy = false;
  String? _feedback;
  bool _failed = false;

  Future<void> _connect() async {
    setState(() {
      _busy = true;
      _feedback = null;
      _failed = false;
    });
    try {
      await widget.sync.syncWith(_target.text);
      if (mounted) setState(() => _feedback = 'Синхронизация завершена.');
    } catch (error) {
      if (mounted) {
        setState(() {
          _failed = true;
          _feedback = switch (error) {
            FormatException() => error.message,
            NotebookFull() => 'Недостаточно места в хранилище заметок.',
            _ => 'Не удалось подключиться. Проверьте адрес, сеть и код аккаунта на обоих устройствах.',
          };
        });
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _target.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AlertDialog(
      title: const Text('Аккаунт и синхронизация'),
      scrollable: true,
      content: SizedBox(
        width: 430,
        child: ListenableBuilder(
          listenable: widget.sync,
          builder: (context, _) {
            final addresses = widget.sync.addresses;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Подключить устройство',
                  style: theme.textTheme.titleMedium,
                ),
                const SizedBox(height: 5),
                const Text(
                  'Введите этот код в «Листе» на другом устройстве. Код даёт доступ к заметкам аккаунта.',
                ),
                const SizedBox(height: 8),
                if (_showCode) ...[
                  SelectableText(
                    widget.account.key.code,
                    style: const TextStyle(fontFamily: 'monospace'),
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () async {
                        await Clipboard.setData(
                          ClipboardData(text: widget.account.key.code),
                        );
                        if (mounted) {
                          setState(() {
                            _failed = false;
                            _feedback = 'Код скопирован.';
                          });
                        }
                      },
                      icon: const Icon(Icons.copy_rounded, size: 18),
                      label: const Text('Скопировать код'),
                    ),
                  ),
                ] else
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton.icon(
                      onPressed: () => setState(() => _showCode = true),
                      icon: const Icon(Icons.visibility_outlined, size: 18),
                      label: const Text('Показать код'),
                    ),
                  ),
                const Divider(height: 28),
                Text('Локальная сеть', style: theme.textTheme.titleMedium),
                const SizedBox(height: 5),
                const Text(
                  'Откройте «Лист» на обоих устройствах в одной сети Wi‑Fi.',
                ),
                const SizedBox(height: 8),
                if (addresses.isEmpty)
                  const Text('Локальный адрес пока недоступен.')
                else ...[
                  const Text('Адрес этого устройства'),
                  for (final address in addresses) SelectableText(address),
                ],
                const SizedBox(height: 12),
                TextField(
                  controller: _target,
                  enabled: !_busy,
                  autocorrect: false,
                  onSubmitted: _busy ? null : (_) => _connect(),
                  decoration: const InputDecoration(
                    labelText: 'Адрес другого устройства',
                    hintText: '192.168.1.5:12345',
                  ),
                ),
                const SizedBox(height: 8),
                OutlinedButton(
                  onPressed: _busy ? null : _connect,
                  child: Text(
                    _busy ? 'Подключение…' : 'Синхронизировать по адресу',
                  ),
                ),
                if (_feedback != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      _feedback!,
                      style: TextStyle(
                        color: _failed ? theme.colorScheme.error : null,
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('Готово'),
        ),
      ],
    );
  }
}
