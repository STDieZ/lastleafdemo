import 'dart:async';
import 'dart:collection';
import 'dart:math';
import 'dart:typed_data';

import 'notes.dart';
import 'wire_sync.dart';

const bleStart = 0;
const bleData = 1;
const bleDone = 2;
const bleMaxPacket = 512;
const bleDefaultPacket = 20;
const bleSessionTimeout = Duration(minutes: 3);

/// Moves the encrypted wire bytes through acknowledged GATT writes and reads.
/// An idle device advertises the service without sending any note data.
class BluetoothMailbox {
  BluetoothMailbox(this._receive);

  final Future<void> Function(SyncChannel channel) _receive;
  _MailboxSession? _session;
  bool _closed = false;

  bool write(String peer, Uint8List message) {
    if (_closed || message.isEmpty || message.length > bleMaxPacket) {
      return false;
    }
    final current = _session;
    if (message.first == bleStart && message.length == 1) {
      if (current != null && current.peer != peer && !current.closed) {
        return false;
      }
      current?.close();
      final session = _session = _MailboxSession(peer);
      unawaited(_serve(session));
      return true;
    }
    if (current == null || current.peer != peer) return false;
    if (message.first == bleDone && message.length == 1) {
      current.close();
      return true;
    }
    if (message.first != bleData || message.length < 2 || current.closed) {
      return false;
    }
    return current.add(Uint8List.sublistView(message, 1));
  }

  Future<void> _serve(_MailboxSession session) async {
    try {
      await _receive(session.channel);
    } catch (_) {
      // Dropped links, wrong account keys, and invalid wire frames end this exchange.
    } finally {
      session.close();
      if (identical(_session, session)) _session = null;
    }
  }

  Uint8List read(String peer, int maximum) {
    final session = _session;
    if (session == null || session.peer != peer || session.closed) {
      return Uint8List.fromList([bleDone]);
    }
    return session.take(maximum.clamp(1, bleMaxPacket - 1));
  }

  void close() {
    _closed = true;
    _session?.close();
    _session = null;
  }
}

class _MailboxSession {
  _MailboxSession(this.peer);

  final String peer;
  final _incoming = StreamController<Uint8List>();
  final _outgoing = Queue<List<int>>();
  int _received = 0;
  int _offset = 0;
  bool closed = false;

  late final channel = SyncChannel(
    incoming: _incoming.stream,
    write: (bytes) async {
      if (closed) throw const FormatException('Bluetooth session is closed');
      _outgoing.add(bytes);
    },
    dispose: close,
    timeout: bleSessionTimeout,
    readTimeout: const Duration(seconds: 12),
    compress: true,
  );

  bool add(Uint8List data) {
    _received += data.length;
    if (_received > maxNotebookBytes + 1024) {
      close();
      return false;
    }
    _incoming.add(data);
    return true;
  }

  Uint8List take(int maximum) {
    if (_outgoing.isEmpty) return Uint8List.fromList([bleStart]);
    final first = _outgoing.first;
    final count = min(maximum, first.length - _offset);
    final result = Uint8List(count + 1)..[0] = bleData;
    result.setRange(1, count + 1, first, _offset);
    _offset += count;
    if (_offset == first.length) {
      _outgoing.removeFirst();
      _offset = 0;
    }
    return result;
  }

  void close() {
    if (closed) return;
    closed = true;
    _outgoing.clear();
    unawaited(_incoming.close());
  }
}
