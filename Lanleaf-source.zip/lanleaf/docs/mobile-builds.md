# Сборка Last Leaf 0.4.0 для Android, iPhone и iPad

## 1. Загрузите файлы в репозиторий GitHub

1. Замените в корне репозитория `Lanleaf-source.zip` новым архивом. Сохраните именно это имя, в том числе регистр букв.
2. Через **Add file → Create new file** создайте `.github/workflows/build-android.yml` и вставьте содержимое одноимённого файла. Повторите для `.github/workflows/build-ios.yml`. Оба файла есть внутри архива. Сохраните их в основной ветке репозитория, обычно `main`.
3. Откройте вкладку **Actions**. После запуска откройте страницу конкретной сборки и прокрутите до **Artifacts**, чтобы скачать результат.

В репозитории с архивом должны получиться такие пути. Сценарии Windows и macOS можно запускать с этим же архивом.

```text
Lanleaf-source.zip
.github/
  workflows/
    build-android.yml
    build-ios.yml
```

Если вы храните распакованный проект в Git, положите содержимое папки `lanleaf/` в корень репозитория. Тогда сценарии используют этот проект. При наличии архива они берут исходники из архива.

Сборки запускаются вручную. Кнопка **Run workflow** появится после того, как файл сценария попадёт в основную ветку. [Запуск сценариев GitHub вручную](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow)

## 2. Android 7 и новее

### Пробный APK через GitHub

1. Откройте **Actions → Build Last Leaf for Android → Run workflow** и выберите `debug`.
2. Скачайте `Last-Leaf-Android-debug.apk` в разделе **Artifacts**. Перенесите APK на телефон и откройте его. Если Android попросит разрешить установку, разрешите её для приложения, из которого открываете файл.
3. Найдите **Last Leaf (Debug)** на телефоне. Для проверки синхронизации подключите телефон и компьютер к одной Wi‑Fi сети, откройте Last Leaf на обоих и введите код действующего аккаунта.

У тестовой версии свой идентификатор `com.lanleaf.lanleaf.debug` и своё локальное хранилище. При каждом запуске GitHub может подписывать `debug` новым временным ключом, поэтому Android может отклонить обновление поверх предыдущего APK. Для повседневного использования соберите `release` с постоянным ключом.

### Подписанный APK через GitHub

1. На компьютере с JDK 21 создайте ключ. `keytool` запросит пароль. Сохраните копию файла и пароля в безопасном месте. Этот же ключ подписывает последующие обновления приложения.

   ```sh
   keytool -genkeypair -storetype PKCS12 -keystore last-leaf.p12 -alias last-leaf -keyalg RSA -keysize 3072 -validity 10000
   ```

2. Переведите содержимое `last-leaf.p12` в Base64 одной строкой. На Mac команда помещает значение в буфер обмена.

   ```sh
   base64 -i last-leaf.p12 | tr -d '\r\n' | pbcopy
   ```

   В PowerShell на Windows используйте команду ниже.

   ```powershell
   [Convert]::ToBase64String([IO.File]::ReadAllBytes((Resolve-Path .\last-leaf.p12).Path)) | Set-Clipboard
   ```

   В Linux скопируйте строку из вывода `base64 -w0 last-leaf.p12`.

3. В репозитории откройте **Settings → Secrets and variables → Actions → Secrets → New repository secret**. Создайте `ANDROID_KEYSTORE_BASE64` со строкой Base64 и `ANDROID_KEYSTORE_PASSWORD` с паролем файла. Для существующего ключа с другим именем можно задать переменную `ANDROID_KEY_ALIAS` во вкладке **Variables**. Если у ключа отдельный пароль, добавьте секрет `ANDROID_KEY_PASSWORD`.
4. Запустите **Build Last Leaf for Android** с типом `release`. Скачайте `Last-Leaf-Android-release.apk` и установите его. Обычная версия называется **Last Leaf** и использует идентификатор `com.lanleaf.lanleaf`.

При обновлении используйте тот же ключ и увеличивайте число после `+` в `version:` файла `pubspec.yaml`. Можно установить APK по USB с включённой отладкой командой `adb install -r Last-Leaf-Android-release.apk`. [Подпись Android-приложений](https://developer.android.com/studio/publish/app-signing)

### Сборка Android на своём компьютере

Подойдут Windows, macOS и Linux. Установите Flutter 3.50.0, JDK 21 и Android Studio. В **SDK Manager** установите Android SDK Platform 36, Build Tools 36.0.0, Platform Tools, Command-line Tools и NDK (Side by side) `28.2.13676358`. Для выбора версии NDK включите **Show Package Details**. Затем из распакованной папки `lanleaf/` выполните команды. [Настройка Android для Flutter](https://docs.flutter.dev/platform-integration/android/setup)

```sh
flutter doctor --android-licenses
flutter doctor -v
flutter pub get --enforce-lockfile
flutter build apk --debug
```

Готовый файл находится в `build/app/outputs/flutter-apk/app-debug.apk`. Локально можно стабильно обновлять тестовую сборку, пока используется тот же отладочный ключ SDK.

Для локальной подписи `release` задайте абсолютный путь к ключу и передайте пароль через переменную окружения. Например, из Bash можно ввести пароль скрыто. Результат будет в `build/app/outputs/flutter-apk/app-release.apk`.

```bash
export LAST_LEAF_SIGNING_STORE='/абсолютный/путь/last-leaf.p12'
read -r -s -p 'Пароль ключа: ' LAST_LEAF_SIGNING_PASSWORD
echo
export LAST_LEAF_SIGNING_PASSWORD
flutter build apk --release
unset LAST_LEAF_SIGNING_PASSWORD LAST_LEAF_SIGNING_STORE
```

В PowerShell 7.2 и новее используйте те же переменные окружения.

```powershell
$env:LAST_LEAF_SIGNING_STORE = 'C:\путь\last-leaf.p12'
$env:LAST_LEAF_SIGNING_PASSWORD = Read-Host -MaskInput 'Пароль ключа'
try { flutter build apk --release }
finally {
    Remove-Item Env:LAST_LEAF_SIGNING_PASSWORD, Env:LAST_LEAF_SIGNING_STORE
}
```

## 3. iOS и iPadOS 15 и новее

Проект Xcode собирает одно приложение для iPhone и iPad. В **Actions → Build Last Leaf for iPhone and iPad → Run workflow** выберите подходящий режим.

| Режим | Результат | Что потребуется |
| --- | --- | --- |
| `simulator` | `Last-Leaf-iOS-Simulator.zip` с `Runner.app` для симулятора на Mac с Apple Silicon | Mac с Xcode и установленным симулятором |
| `ad-hoc` | `Last-Leaf-iOS-iPadOS.ipa` для iPhone и iPad, включённых в профиль | Членство Apple Developer Program, сертификат и профиль Ad Hoc |
| `testflight` | `Last-Leaf-iOS-iPadOS.ipa` для загрузки в App Store Connect | Членство Apple Developer Program, сертификат, профиль App Store Connect и запись приложения |

### Симулятор

Запустите `simulator`, скачайте ZIP из **Artifacts** и распакуйте его. На Mac откройте Simulator, запустите нужную модель iPhone или iPad и из папки с `Runner.app` выполните команды. Для проверки синхронизации по Wi‑Fi используйте физический iPhone или iPad.

```sh
open -a Simulator
xcrun simctl install booted "$PWD/Runner.app"
xcrun simctl launch booted com.lanleaf.lanleaf
```

### Подготовка подписи для Ad Hoc или TestFlight

1. В Apple Developer создайте явный App ID со своим уникальным Bundle ID, например `com.vashe-imya.lastleaf`. При сборке сценарий возьмёт Bundle ID и команду из профиля.
2. В Xcode откройте **Settings → Accounts → ваша команда → Manage Certificates**. Создайте сертификат **Apple Distribution** или выберите существующий с доступным приватным ключом. Экспортируйте сертификат с ключом в `distribution.p12` и задайте пароль.
3. В кабинете Apple Developer создайте профиль с этим App ID и сертификатом. Для `ad-hoc` зарегистрируйте UDID каждого iPhone и iPad и включите эти устройства в профиль **Ad Hoc**. Для `testflight` выберите профиль **App Store Connect**. Скачайте `.mobileprovision`.
4. В GitHub откройте **Settings → Secrets and variables → Actions → Secrets**. Создайте `IOS_DISTRIBUTION_P12_BASE64` и `IOS_DISTRIBUTION_PASSWORD`. Добавьте `IOS_AD_HOC_PROFILE_BASE64` для `ad-hoc` или `IOS_APP_STORE_PROFILE_BASE64` для `testflight`.

По очереди скопируйте Base64 для сертификата и профиля. Вставляйте каждое значение в соответствующий секрет. Замените имя файла профиля в команде на своё.

```sh
base64 -i distribution.p12 | tr -d '\r\n' | pbcopy
base64 -i LastLeaf.mobileprovision | tr -d '\r\n' | pbcopy
```

GitHub создаёт временную связку ключей на своей сборочной машине для подписи IPA. Установленный Last Leaf хранит заметки и профиль в зашифрованной папке приложения и запускается без запроса к Связке ключей. Храните `.p12`, пароль и профили подписи в секретах GitHub.

[Профиль Ad Hoc](https://developer.apple.com/help/account/provisioning-profiles/create-an-ad-hoc-provisioning-profile/) · [Профиль App Store Connect](https://developer.apple.com/help/account/provisioning-profiles/create-an-app-store-provisioning-profile/) · [Секреты GitHub Actions](https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets)

### Установка IPA

- **Ad Hoc.** Запустите режим `ad-hoc`. Скачайте IPA, подключите зарегистрированный iPhone или iPad к Mac и откройте **Xcode → Window → Devices and Simulators**. Выберите устройство и добавьте IPA в **Installed Apps**. Можно также установить IPA на подключённое устройство через Apple Configurator. [Распространение на зарегистрированные устройства](https://developer.apple.com/documentation/xcode/distributing-your-app-to-registered-devices)
- **TestFlight.** Создайте запись приложения в App Store Connect с Bundle ID из профиля. Запустите `testflight`, скачайте IPA и загрузите его в эту запись через Transporter на Mac. После обработки сборки заполните вопрос об экспортном контроле шифрования, если Apple его покажет. Добавьте тестеров во вкладке **TestFlight**. Для следующей загрузки запустите новый **Run workflow**, чтобы получить новый номер сборки. [Загрузка сборок](https://developer.apple.com/help/app-store-connect/manage-builds/upload-builds/) · [TestFlight](https://developer.apple.com/help/app-store-connect/test-a-beta-version/testflight-overview/)

### Сборка и запуск iPhone или iPad со своего Mac

Для запуска на собственном устройстве можно использовать Xcode и бесплатную **Personal Team**. Подключите устройство к Mac, подтвердите доверие и включите **Режим разработчика**, если его запросит система. Установите Flutter 3.50.0 и Xcode. Из распакованной папки `lanleaf/` выполните команды. [Настройка iOS для Flutter](https://docs.flutter.dev/platform-integration/ios/setup)

```sh
flutter pub get --enforce-lockfile
flutter build ios --config-only --no-codesign
open ios/Runner.xcworkspace
```

В Xcode выберите проект и цель **Runner → Signing & Capabilities**, включите **Automatically manage signing**, выберите свою команду и задайте уникальный **Bundle Identifier**. Выберите подключённый iPhone или iPad вверху окна и нажмите **Run**. Можно также из терминала выполнить `flutter devices`, затем `flutter run -d ID`, подставив идентификатор устройства.

Для локальной сборки IPA с платной командой используйте настроенную подпись Xcode и `flutter build ipa`. Экспорт также доступен в Xcode через **Product → Archive → Distribute App**. При обновлении оставьте Bundle ID прежним, чтобы система установила новую сборку поверх старой. [Сборка и выпуск Flutter для iOS](https://docs.flutter.dev/deployment/ios)
