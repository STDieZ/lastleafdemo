import 'dart:convert';

import 'package:material_ui/material_ui.dart';

import 'code_field.dart';
import 'peers.dart';
import 'profile_vault.dart';
import 'theme.dart';

class VaultUnlockPage extends StatefulWidget {
  const VaultUnlockPage({
    super.key,
    required this.onUnlock,
    required this.onRecover,
  });

  final Future<void> Function(String password) onUnlock;
  final Future<void> Function(ConnectionCode code, String newPassword)
  onRecover;

  @override
  State<VaultUnlockPage> createState() => _VaultUnlockPageState();
}

class _VaultUnlockPageState extends State<VaultUnlockPage> {
  final _password = TextEditingController();
  final _confirmation = TextEditingController();
  final _code = TextEditingController();
  bool _recovering = false;
  bool _busy = false;
  String? _error;

  void _toggleRecovery() {
    setState(() {
      _recovering = !_recovering;
      _password.clear();
      _confirmation.clear();
      _code.clear();
      _error = null;
    });
  }

  Future<void> _submit() async {
    if (_busy) return;
    final password = _password.text;
    ConnectionCode? code;
    String? validation;
    if (_recovering) {
      validation = _validateNewPassword(password, _confirmation.text);
      try {
        code = ConnectionCode.parse(_code.text);
      } on FormatException {
        validation = 'Введите код подключения, который начинается с LL1-.';
      }
    } else if (password.isEmpty) {
      validation = 'Введите пароль Last Leaf.';
    }
    if (validation != null) {
      setState(() => _error = validation);
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      if (code == null) {
        await widget.onUnlock(password);
      } else {
        await widget.onRecover(code, password);
      }
    } on VaultAuthenticationFailed {
      _showError(
        _recovering
            ? 'Код не подошёл к этому хранилищу.'
            : 'Неверный пароль Last Leaf.',
      );
    } catch (_) {
      _showError('Не удалось открыть локальное хранилище.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _showError(String text) {
    if (mounted) setState(() => _error = text);
  }

  @override
  void dispose() {
    _password.dispose();
    _confirmation.dispose();
    _code.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: LeafMark(large: true),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    _recovering ? 'Восстановить доступ' : appName,
                    style: theme.textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _recovering
                        ? 'Возьмите код подключения этого аккаунта с другого устройства и задайте новый пароль.'
                        : 'Введите пароль, который вы задали в Last Leaf на этом устройстве.',
                    style: TextStyle(color: theme.colorScheme.onSurfaceVariant),
                  ),
                  const SizedBox(height: 20),
                  if (_recovering) ...[
                    CodeField(controller: _code, enabled: !_busy),
                    const SizedBox(height: 12),
                  ],
                  _PasswordField(
                    controller: _password,
                    label: _recovering
                        ? 'Новый пароль Last Leaf'
                        : 'Пароль Last Leaf',
                    enabled: !_busy,
                    onSubmit: _recovering ? null : _submit,
                  ),
                  if (_recovering) ...[
                    const SizedBox(height: 12),
                    _PasswordField(
                      controller: _confirmation,
                      label: 'Повторить пароль',
                      enabled: !_busy,
                      onSubmit: _submit,
                    ),
                  ],
                  if (_error case final error?) ...[
                    const SizedBox(height: 10),
                    Text(
                      error,
                      style: TextStyle(color: theme.colorScheme.error),
                    ),
                  ],
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: Text(
                      _busy
                          ? 'Открываем хранилище…'
                          : _recovering
                          ? 'Задать пароль и открыть'
                          : 'Открыть заметки',
                    ),
                  ),
                  TextButton(
                    onPressed: _busy ? null : _toggleRecovery,
                    child: Text(_recovering ? 'Назад' : 'Восстановить по коду'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class SetVaultPasswordDialog extends StatefulWidget {
  const SetVaultPasswordDialog({super.key});

  @override
  State<SetVaultPasswordDialog> createState() => _SetVaultPasswordDialogState();
}

class _SetVaultPasswordDialogState extends State<SetVaultPasswordDialog> {
  final _password = TextEditingController();
  final _confirmation = TextEditingController();
  String? _error;

  void _save() {
    final error = _validateNewPassword(_password.text, _confirmation.text);
    if (error != null) {
      setState(() => _error = error);
    } else {
      Navigator.pop(context, _password.text);
    }
  }

  @override
  void dispose() {
    _password.dispose();
    _confirmation.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Пароль Last Leaf'),
    scrollable: true,
    content: SizedBox(
      width: 320,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            'Придумайте пароль из 8 или более символов. Он защищает хранилище '
            'и будет нужен при запуске Last Leaf на этом устройстве.',
          ),
          const SizedBox(height: 14),
          _PasswordField(
            controller: _password,
            label: 'Новый пароль Last Leaf',
          ),
          const SizedBox(height: 10),
          _PasswordField(
            controller: _confirmation,
            label: 'Повторить пароль',
            onSubmit: _save,
          ),
          if (_error case final error?) ...[
            const SizedBox(height: 10),
            Text(
              error,
              style: TextStyle(color: Theme.of(context).colorScheme.error),
            ),
          ],
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Отмена'),
      ),
      FilledButton(onPressed: _save, child: const Text('Сохранить пароль')),
    ],
  );
}

class _PasswordField extends StatelessWidget {
  const _PasswordField({
    required this.controller,
    required this.label,
    this.enabled = true,
    this.onSubmit,
  });

  final TextEditingController controller;
  final String label;
  final bool enabled;
  final VoidCallback? onSubmit;

  @override
  Widget build(BuildContext context) => TextField(
    controller: controller,
    enabled: enabled,
    obscureText: true,
    autocorrect: false,
    enableSuggestions: false,
    enableIMEPersonalizedLearning: false,
    textInputAction: onSubmit == null
        ? TextInputAction.next
        : TextInputAction.done,
    onSubmitted: onSubmit == null ? null : (_) => onSubmit!(),
    decoration: InputDecoration(labelText: label),
  );
}

String? _validateNewPassword(String password, String confirmation) {
  if (password.characters.length < minPasswordLength) {
    return 'Введите не меньше 8 символов.';
  }
  if (utf8.encode(password).length > maxPasswordBytes) {
    return 'Пароль слишком длинный.';
  }
  if (password != confirmation) return 'Пароли не совпадают.';
  return null;
}
