import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/src/appearance_settings.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/lan_sync.dart';
import 'package:lanleaf/src/notebook_store.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/peers.dart';
import 'package:lanleaf/src/platform_services.dart';
import 'package:lanleaf/src/setup.dart';
import 'package:lanleaf/src/theme.dart';
import 'package:lanleaf/src/workspace.dart';
import 'package:material_ui/material_ui.dart';

Widget app(Widget home, {AppearanceSettings? appearance}) {
  MaterialApp build() => MaterialApp(
    theme: buildLeafTheme(
      appearance?.palette ?? LeafPalette.green,
      Brightness.light,
    ),
    darkTheme: buildLeafTheme(
      appearance?.palette ?? LeafPalette.green,
      Brightness.dark,
    ),
    themeMode: appearance?.mode ?? ThemeMode.system,
    locale: const Locale('ru'),
    supportedLocales: const [Locale('ru')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    home: home,
  );
  return appearance == null
      ? build()
      : ListenableBuilder(listenable: appearance, builder: (_, _) => build());
}

void main() {
  testWidgets('phone pairing validates and accepts the account code', (
    tester,
  ) async {
    final key = AccountKey.generate();
    final endpoint = LanEndpoint.tryParse('192.168.1.23:41721')!;
    ConnectionCode? submitted;
    await tester.binding.setSurfaceSize(const Size(390, 780));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      app(
        SetupPage(
          onConnect: (value, {required restore}) async => submitted = value,
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('У меня есть код подключения'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField), '1234');
    await tester.tap(find.text('Подключить устройство'));
    await tester.pumpAndSettle();
    expect(submitted, isNull);
    expect(find.textContaining('Проверьте код'), findsOneWidget);
    await tester.enterText(
      find.byType(TextField),
      ConnectionCode(key, [endpoint]).text,
    );
    await tester.tap(find.text('Подключить устройство'));
    await tester.pumpAndSettle();
    expect(submitted?.key.code, key.code);
    expect(submitted?.endpoints, [endpoint]);
  });

  testWidgets('search and editor work across desktop and phone layouts', (
    tester,
  ) async {
    final account = LocalAccount(AccountKey.generate(), newId());
    final store = (await tester.runAsync(() async {
      final directory = await Directory.systemTemp.createTemp('lanleaf-ui-');
      addTearDown(() => directory.delete(recursive: true));
      final store = await NotebookStore.open(directory, account.key);
      await store.revise(
        id: newId(),
        author: account.device,
        basedOn: [],
        title: 'Маршрут',
        body: 'Текст для поиска',
      );
      await store.revise(
        id: newId(),
        author: account.device,
        basedOn: [],
        title: 'Покупки',
        body: 'Яблоки',
      );
      return store;
    }))!;
    final sync = LanSync(account, store);
    addTearDown(sync.dispose);
    await tester.binding.setSurfaceSize(const Size(1060, 760));
    addTearDown(() => tester.binding.setSurfaceSize(null));
    await tester.pumpWidget(
      app(
        NotesWorkspace(
          account: account,
          store: store,
          sync: sync,
          appearance: AppearanceSettings(),
          onJoinCode: (_) async {},
        ),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Откройте заметку'), findsOneWidget);
    await tester.enterText(find.byType(TextField), 'текст для поиска');
    await tester.pumpAndSettle();
    expect(find.text('Покупки'), findsNothing);
    await tester.tap(find.text('Маршрут'));
    await tester.pumpAndSettle();
    expect(find.text('Сохранено на устройстве'), findsOneWidget);
    await tester.binding.setSurfaceSize(const Size(390, 780));
    await tester.pumpAndSettle();
    expect(find.byTooltip('К списку заметок'), findsOneWidget);
    await tester.tap(find.byTooltip('К списку заметок'));
    await tester.pumpAndSettle();
    expect(find.text('Новая заметка'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets('a left swipe reveals pin and delete within the selected row', (
    tester,
  ) async {
    final fixture = await _workspace(tester);
    final old = find.byKey(ValueKey(fixture.oldId));
    final recent = find.byKey(ValueKey(fixture.recentId));
    expect(
      tester.getTopLeft(old).dy,
      greaterThan(tester.getTopLeft(recent).dy),
    );

    await tester.drag(old, const Offset(-150, 0));
    await tester.pumpAndSettle();
    final pin = find.descendant(of: old, matching: find.text('Закрепить'));
    await tester.runAsync(() async {
      await tester.tap(pin);
      await fixture.store.idle;
    });
    await tester.pumpAndSettle();
    expect(fixture.store.notebook.isPinned(fixture.oldId), isTrue);
    expect(tester.getTopLeft(old).dy, lessThan(tester.getTopLeft(recent).dy));

    await tester.tap(find.text('Первая заметка'));
    await tester.pumpAndSettle();
    await tester.drag(recent, const Offset(-150, 0));
    await tester.pumpAndSettle();
    await tester.runAsync(
      () => tester.tap(
        find.descendant(of: recent, matching: find.text('Удалить')),
      ),
    );
    await tester.pumpAndSettle();
    expect(find.text('Удалить заметку?'), findsOneWidget);
    await tester.runAsync(() async {
      await tester.tap(find.widgetWithText(FilledButton, 'Удалить'));
      await fixture.store.idle;
    });
    await tester.pumpAndSettle();
    expect(recent, findsNothing);
    expect(fixture.store.notebook.notes[fixture.recentId]!.visible, isFalse);
    expect(find.text('Сохранено на устройстве'), findsOneWidget);
    await tester.pumpWidget(const SizedBox());
  });

  testWidgets(
    'settings change palette and dark mode and accept a code after setup',
    (tester) async {
      ConnectionCode? submitted;
      final fixture = await _workspace(
        tester,
        onJoinCode: (code) async => submitted = code,
      );
      await tester.tap(find.byTooltip('Настройки'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Оформление'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Фиолетовый'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Тёмный'));
      await tester.pumpAndSettle();
      final theme = Theme.of(tester.element(find.text('Настройки')));
      expect(theme.brightness, Brightness.dark);
      expect(fixture.appearance.palette, LeafPalette.purple);
      expect(
        theme.colorScheme.primary,
        buildLeafTheme(LeafPalette.purple, Brightness.dark).colorScheme.primary,
      );

      await tester.tap(find.text('Синхронизация'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('Ввести код'));
      await tester.pumpAndSettle();
      final code = ConnectionCode(AccountKey.generate(), [
        LanEndpoint.tryParse('192.168.1.33:41721')!,
      ]);
      await tester.enterText(find.byType(TextField).last, code.text);
      await tester.tap(find.text('Продолжить'));
      await tester.pumpAndSettle();
      expect(find.text('Подключить другой аккаунт?'), findsOneWidget);
      await tester.tap(find.widgetWithText(FilledButton, 'Подключить'));
      await tester.pumpAndSettle();
      expect(submitted?.text, code.text);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
    },
  );
}

Future<
  ({
    NotebookStore store,
    AppearanceSettings appearance,
    String oldId,
    String recentId,
  })
>
_workspace(
  WidgetTester tester, {
  Future<void> Function(ConnectionCode)? onJoinCode,
}) async {
  final account = LocalAccount(AccountKey.generate(), newId());
  final oldId = newId();
  final recentId = newId();
  final store = (await tester.runAsync(() async {
    final directory = await Directory.systemTemp.createTemp('last-leaf-ui-');
    addTearDown(() => directory.delete(recursive: true));
    final store = await NotebookStore.open(directory, account.key);
    await store.revise(
      id: oldId,
      author: account.device,
      basedOn: [],
      title: 'Первая заметка',
      body: 'Текст',
    );
    await Future<void>.delayed(const Duration(milliseconds: 5));
    await store.revise(
      id: recentId,
      author: account.device,
      basedOn: [],
      title: 'Вторая заметка',
      body: 'Ещё текст',
    );
    return store;
  }))!;
  final sync = LanSync(account, store);
  final appearance = AppearanceSettings();
  addTearDown(sync.dispose);
  addTearDown(appearance.dispose);
  await tester.binding.setSurfaceSize(const Size(1060, 760));
  addTearDown(() => tester.binding.setSurfaceSize(null));
  await tester.pumpWidget(
    app(
      NotesWorkspace(
        account: account,
        store: store,
        sync: sync,
        appearance: appearance,
        onJoinCode: onJoinCode ?? (_) async {},
      ),
      appearance: appearance,
    ),
  );
  await tester.pumpAndSettle();
  return (
    store: store,
    appearance: appearance,
    oldId: oldId,
    recentId: recentId,
  );
}
