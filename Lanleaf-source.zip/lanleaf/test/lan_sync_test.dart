import 'dart:async';
import 'dart:io';

import 'package:bonsoir/bonsoir.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lanleaf/src/bonjour_discovery.dart';
import 'package:lanleaf/src/keys.dart';
import 'package:lanleaf/src/lan_sync.dart';
import 'package:lanleaf/src/notebook_store.dart';
import 'package:lanleaf/src/notes.dart';
import 'package:lanleaf/src/peers.dart';
import 'package:lanleaf/src/platform_services.dart';

void main() {
  test(
    'a connection code retains its local endpoints and accepts legacy codes',
    () {
      final key = AccountKey.generate();
      final endpoint = LanEndpoint.tryParse('192.168.1.25:41721')!;
      final code = ConnectionCode(key, [endpoint]);
      final parsed = ConnectionCode.parse(
        ' ${code.text.replaceFirst('|', '\n|')} ',
      );
      expect(parsed.key.code, key.code);
      expect(parsed.endpoints, [endpoint]);
      expect(ConnectionCode.parse(key.code).endpoints, isEmpty);
      expect(
        () => ConnectionCode.parse('${key.code}|https://example.com'),
        throwsFormatException,
      );
    },
  );

  test(
    'Bonsoir can use the numeric endpoint from TXT before hostname resolution',
    () {
      final service = BonsoirService(
        name: 'other-device',
        type: '_lanleaf-v1._tcp',
        port: 0,
        attributes: {'ipv4': '192.168.1.20:41721,broken,10.0.0.10:41721'},
      );
      expect(advertisedEndpoints(service).map((e) => e.toString()), [
        '192.168.1.20:41721',
        '10.0.0.10:41721',
      ]);
    },
  );

  test(
    'the same account discovers a peer and replaces a stale address',
    () async {
      final network = _SimulatedBonjour();
      final first = await _device(AccountKey.generate(), network.factory);
      final code = ConnectionCode.parse(first.account.key.code);
      final second = await _device(code.key, network.factory);
      final id = await first.write(body: 'Синхронизация по старому коду');

      await Future.wait([first.sync.start(), second.sync.start()]);
      await _until(() => second.body(id) == 'Синхронизация по старому коду');
      await _until(
        () => first.sync.lastSynced != null && second.sync.lastSynced != null,
      );
      final previous = second.endpoint;
      await second.stop();
      final occupied = await ServerSocket.bind(
        InternetAddress.anyIPv4,
        previous.port,
      );
      final occupiedSockets = occupied.listen((socket) => socket.destroy());
      addTearDown(() async {
        await occupiedSockets.cancel();
        await occupied.close();
      });

      await first.write(
        id: id,
        body: 'Правка, пока другое устройство было офлайн',
      );
      final reconnecting = await _device(
        code.key,
        network.factory,
        account: second.account,
        directory: second.store.directory,
      );
      await reconnecting.sync.start();
      expect(reconnecting.endpoint, isNot(previous));
      await _until(
        () =>
            reconnecting.body(id) ==
            'Правка, пока другое устройство было офлайн',
      );
      await _until(() async {
        final history = await PeerHistory.open(first.store.directory, code.key);
        return history.endpoints.contains(reconnecting.endpoint) &&
            !history.endpoints.contains(previous);
      });
    },
  );

  test('the code carries an address when Bonjour is unavailable', () async {
    final first = await _device(AccountKey.generate(), _noBonjour);
    final note = await first.write(body: 'Первое подключение по коду');
    await first.sync.start();
    final code = ConnectionCode.parse(first.sync.connectionCode.text);
    expect(code.endpoints, [first.endpoint]);

    final second = await _device(code.key, _noBonjour);
    await second.sync.start(hints: code.endpoints);
    await _until(() => second.body(note) == 'Первое подключение по коду');

    await second.write(id: note, body: 'Ответ через тот же код');
    await _until(() => first.body(note) == 'Ответ через тот же код');
  });

  test('one address pairs both peers, then auto-sync survives restart and reconnect', () async {
    final key = AccountKey.generate();
    final first = await _device(key, _noBonjour);
    final second = await _device(key, _noBonjour);
    final id = await first.write(body: 'Первая версия');
    await Future.wait([first.sync.start(), second.sync.start()]);

    // No code contains an address and discovery supplies none.
    expect(second.body(id), isNull);
    await first.sync.syncWith(second.endpoint.toString());
    await _until(
      () => first.sync.lastSynced != null && second.sync.lastSynced != null,
    );
    expect(second.body(id), 'Первая версия');
    expect(
      (await PeerHistory.open(second.store.directory, key)).endpoints,
      contains(first.endpoint),
    );

    await second.store.setPinned(id, second.account.device, true);
    await _until(() => first.store.notebook.isPinned(id));
    await second.write(id: id, body: 'Правка с другого устройства');
    await _until(() => first.body(id) == 'Правка с другого устройства');

    final firstEndpoint = first.endpoint;
    final secondEndpoint = second.endpoint;
    await first.stop();
    await second.stop();
    await first.write(id: id, body: 'Правка после остановки');

    final relaunchedA = await _device(
      key,
      _noBonjour,
      account: first.account,
      directory: first.store.directory,
    );
    final relaunchedB = await _device(
      key,
      _noBonjour,
      account: second.account,
      directory: second.store.directory,
    );
    await Future.wait([relaunchedA.sync.start(), relaunchedB.sync.start()]);
    expect(relaunchedA.endpoint, firstEndpoint);
    expect(relaunchedB.endpoint, secondEndpoint);
    await _until(() => relaunchedB.body(id) == 'Правка после остановки');

    relaunchedB.onNetwork = false;
    await _until(() => !relaunchedB.sync.hasNetwork);
    await relaunchedA.write(id: id, body: 'Изменение при отключённой сети');
    expect(relaunchedB.body(id), 'Правка после остановки');
    relaunchedB.onNetwork = true;
    await _until(
      () => relaunchedB.body(id) == 'Изменение при отключённой сети',
    );
    expect(relaunchedB.store.notebook.isPinned(id), isTrue);
  });

  test('an address on another account is never remembered', () async {
    final first = await _device(AccountKey.generate(), _noBonjour);
    final second = await _device(AccountKey.generate(), _noBonjour);
    final id = await first.write(body: 'Содержимое только первого аккаунта');
    await Future.wait([first.sync.start(), second.sync.start()]);
    await expectLater(
      first.sync.syncWith(second.endpoint.toString()),
      throwsA(anything),
    );
    expect(second.body(id), isNull);
    final history = await PeerHistory.open(
      first.store.directory,
      first.account.key,
    );
    expect(history.endpoints, isEmpty);
  });
}

Future<_Device> _device(
  AccountKey key,
  PeerDiscoveryFactory discovery, {
  Directory? directory,
  LocalAccount? account,
}) async {
  if (directory == null) {
    directory = await Directory.systemTemp.createTemp('last-leaf-lan-');
    final temporary = directory;
    addTearDown(() => temporary.delete(recursive: true));
  }
  final device = _Device(
    account ?? LocalAccount(key, newId()),
    await NotebookStore.open(directory, key),
    discovery,
  );
  addTearDown(device.stop);
  return device;
}

class _Device {
  _Device(this.account, this.store, PeerDiscoveryFactory discovery) {
    sync = LanSync(
      account,
      store,
      readInterfaces: () async => onNetwork ? [_LoopbackRoute()] : [],
      discovery: discovery,
      pollInterval: const Duration(milliseconds: 220),
    );
  }

  final LocalAccount account;
  final NotebookStore store;
  late final LanSync sync;
  bool onNetwork = true;
  bool _stopped = false;

  LanEndpoint get endpoint => LanEndpoint.tryParse(sync.addresses.single)!;
  String? body(String id) => store.notebook.notes[id]?.latest.body;

  Future<String> write({String? id, required String body}) async {
    id ??= newId();
    await store.revise(
      id: id,
      author: account.device,
      basedOn: store.notebook.notes[id]?.versions ?? [],
      title: 'План',
      body: body,
    );
    return id;
  }

  Future<void> stop() async {
    if (_stopped) return;
    _stopped = true;
    await sync.close();
    sync.dispose();
  }
}

class _LoopbackRoute extends LanInterface {
  _LoopbackRoute() : super(InternetAddress.loopbackIPv4, 8);

  @override
  bool contains(InternetAddress remote) => remote.isLoopback;
}

Future<void> _until(FutureOr<bool> Function() condition) async {
  final watch = Stopwatch()..start();
  while (!await condition() && watch.elapsed < const Duration(seconds: 6)) {
    await Future<void>.delayed(const Duration(milliseconds: 25));
  }
  expect(
    await condition(),
    isTrue,
    reason: 'Timed out waiting for automatic sync',
  );
}

PeerDiscovery _noBonjour(
  String name,
  String group,
  List<LanEndpoint> endpoints,
  void Function() changed,
) => _NoBonjour();

class _NoBonjour implements PeerDiscovery {
  @override
  Iterable<LanEndpoint> get endpoints => const [];
  @override
  bool get healthy => true;
  @override
  Future<void> start() async {}
  @override
  Future<void> close() async {}
}

class _SimulatedBonjour {
  final _services = <_Advertisement>{};

  PeerDiscovery factory(
    String name,
    String group,
    List<LanEndpoint> endpoints,
    void Function() changed,
  ) => _Advertisement(this, group, endpoints, changed);
}

class _Advertisement implements PeerDiscovery {
  _Advertisement(this.network, this.group, this.advertised, this.changed);

  final _SimulatedBonjour network;
  final String group;
  final List<LanEndpoint> advertised;
  final void Function() changed;
  var _active = false;

  @override
  bool get healthy => _active;
  @override
  Iterable<LanEndpoint> get endpoints => network._services
      .where((service) => service != this && service.group == group)
      .expand((service) => service.advertised);

  @override
  Future<void> start() async {
    _active = true;
    network._services.add(this);
    for (final service in network._services) {
      service.changed();
    }
  }

  @override
  Future<void> close() async {
    _active = false;
    network._services.remove(this);
    for (final service in network._services) {
      service.changed();
    }
  }
}
