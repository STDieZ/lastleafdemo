import 'dart:typed_data';

import 'package:dbus/dbus.dart';

import 'bluetooth_mailbox.dart';

const _bluez = 'org.bluez';
const _gattManager = 'org.bluez.GattManager1';
const _leManager = 'org.bluez.LEAdvertisingManager1';
const _service = 'org.bluez.GattService1';
const _characteristic = 'org.bluez.GattCharacteristic1';
const _advertisement = 'org.bluez.LEAdvertisement1';
const _root = '/com/lanleaf/bluetooth';

class BluezAdvertisement {
  BluezAdvertisement._(this._client, this._adapter);

  final DBusClient _client;
  final DBusRemoteObject _adapter;

  static Future<BluezAdvertisement> start(
    String serviceUuid,
    String characteristicUuid,
    BluetoothMailbox mailbox,
  ) async {
    final client = DBusClient.system();
    try {
      final owner = await client.getNameOwner(_bluez);
      if (owner == null) throw StateError('BlueZ is not running');
      final objects = await DBusRemoteObjectManager(
        client,
        name: _bluez,
        path: DBusObjectPath('/'),
      ).getManagedObjects();
      final adapterPath = objects.entries
          .where((entry) {
            final interfaces = entry.value;
            return interfaces.containsKey(_gattManager) &&
                interfaces.containsKey(_leManager) &&
                interfaces['org.bluez.Adapter1']?['Powered']?.asBoolean() ==
                    true;
          })
          .firstOrNull
          ?.key;
      if (adapterPath == null) {
        throw StateError('No Bluetooth LE advertising adapter');
      }
      final adapter = DBusRemoteObject(client, name: _bluez, path: adapterPath);
      final root = DBusObject(DBusObjectPath(_root), isObjectManager: true);
      final service = _BluezObject('$_root/service', _service, {
        'UUID': DBusString(serviceUuid),
        'Primary': const DBusBoolean(true),
      });
      final characteristic = _BluezObject(
        '$_root/service/channel',
        _characteristic,
        {
          'UUID': DBusString(characteristicUuid),
          'Service': service.path,
          'Flags': DBusArray.string(['read', 'write']),
        },
        handle: (call) => _gattRequest(call, owner, mailbox),
      );
      final advertisement = _BluezObject(
        '/com/lanleaf/advertisement',
        _advertisement,
        {
          'Type': const DBusString('peripheral'),
          'ServiceUUIDs': DBusArray.string([serviceUuid]),
        },
        handle: (call) => call.sender == owner && call.name == 'Release'
            ? DBusMethodSuccessResponse()
            : DBusMethodErrorResponse.unknownMethod(),
      );
      for (final object in [root, service, characteristic, advertisement]) {
        await client.registerObject(object);
      }
      await adapter.callMethod(_gattManager, 'RegisterApplication', [
        root.path,
        DBusDict.stringVariant({}),
      ]);
      await adapter.callMethod(_leManager, 'RegisterAdvertisement', [
        advertisement.path,
        DBusDict.stringVariant({}),
      ]);
      return BluezAdvertisement._(client, adapter);
    } catch (_) {
      await client.close();
      rethrow;
    }
  }

  Future<void> close() async {
    try {
      await _adapter
          .callMethod(_leManager, 'UnregisterAdvertisement', [
            DBusObjectPath('/com/lanleaf/advertisement'),
          ])
          .timeout(const Duration(seconds: 2));
    } catch (_) {}
    try {
      await _adapter
          .callMethod(_gattManager, 'UnregisterApplication', [
            DBusObjectPath(_root),
          ])
          .timeout(const Duration(seconds: 2));
    } catch (_) {}
    await _client.close();
  }
}

DBusMethodResponse _gattRequest(
  DBusMethodCall call,
  String owner,
  BluetoothMailbox mailbox,
) {
  DBusMethodResponse rejected() =>
      DBusMethodErrorResponse('org.bluez.Error.NotPermitted');
  if (call.sender != owner) return rejected();
  final first = call.values.firstOrNull;
  final options = call.values.lastOrNull;
  if (options is! DBusDict || options.signature.value != 'a{sv}') {
    return rejected();
  }
  final properties = options.asStringVariantDict();
  final device = properties['device'];
  if (device is! DBusObjectPath) return rejected();
  if (properties['offset'] case final DBusUint16 offset
      when offset.value != 0) {
    return DBusMethodErrorResponse('org.bluez.Error.InvalidOffset');
  }
  if (call.name == 'ReadValue' && call.values.length == 1) {
    final mtu = properties['mtu'];
    final maximum = mtu is DBusUint16 ? mtu.value - 4 : bleDefaultPacket - 1;
    return DBusMethodSuccessResponse([
      DBusArray.byte(mailbox.read(device.value, maximum)),
    ]);
  }
  if (call.name == 'WriteValue' &&
      call.values.length == 2 &&
      first is DBusArray &&
      first.signature.value == 'ay' &&
      mailbox.write(
        device.value,
        Uint8List.fromList(first.asByteArray().toList()),
      )) {
    return DBusMethodSuccessResponse();
  }
  return rejected();
}

class _BluezObject extends DBusObject {
  _BluezObject(String path, this.interface, this.properties, {this.handle})
    : super(DBusObjectPath(path));

  final String interface;
  final Map<String, DBusValue> properties;
  final DBusMethodResponse Function(DBusMethodCall)? handle;

  @override
  Map<String, Map<String, DBusValue>> get interfacesAndProperties => {
    interface: properties,
  };

  @override
  Future<DBusMethodResponse> getProperty(String interface, String name) async {
    final value = interface == this.interface ? properties[name] : null;
    return value == null
        ? DBusMethodErrorResponse.unknownProperty()
        : DBusGetPropertyResponse(value);
  }

  @override
  Future<DBusMethodResponse> getAllProperties(String interface) async =>
      DBusGetAllPropertiesResponse(
        interface == this.interface ? properties : {},
      );

  @override
  Future<DBusMethodResponse> handleMethodCall(DBusMethodCall call) async =>
      call.interface == interface && handle != null
      ? handle!(call)
      : DBusMethodErrorResponse.unknownMethod();
}
