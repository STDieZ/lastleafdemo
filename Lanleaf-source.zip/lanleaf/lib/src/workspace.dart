import 'dart:async';
import 'dart:ui' show AppExitResponse;

import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';

import 'appearance_settings.dart';
import 'lan_sync.dart';
import 'note_row.dart';
import 'notebook_store.dart';
import 'notes.dart';
import 'peers.dart';
import 'platform_services.dart';
import 'settings.dart';
import 'theme.dart';

class NotesWorkspace extends StatefulWidget {
  const NotesWorkspace({
    super.key,
    required this.account,
    required this.store,
    required this.sync,
    required this.appearance,
    required this.onJoinCode,
  });

  final LocalAccount account;
  final NotebookStore store;
  final LanSync sync;
  final AppearanceSettings appearance;
  final Future<void> Function(ConnectionCode code) onJoinCode;

  @override
  State<NotesWorkspace> createState() => _NotesWorkspaceState();
}

class _NotesWorkspaceState extends State<NotesWorkspace> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  final _search = TextEditingController();
  final _titleFocus = FocusNode();
  late final AppLifecycleListener _lifecycle;
  String? _id;
  String? _revealed;
  NoteVersion? _base;
  bool _dirty = false;
  bool _inDialog = false;
  int _generation = 0;
  String? _saveError;
  Timer? _autosave;
  Future<bool>? _saving;

  Notebook get _notebook => widget.store.notebook;
  Note? get _selected => _notebook.notes[_id];

  @override
  void initState() {
    super.initState();
    widget.store.addListener(_notebookChanged);
    _lifecycle = AppLifecycleListener(
      onResume: () => unawaited(widget.sync.syncNow(refreshDiscovery: true)),
      onInactive: () => unawaited(_save()),
      onPause: () => unawaited(_save()),
      onExitRequested: () async =>
          await _save() ? AppExitResponse.exit : AppExitResponse.cancel,
    );
  }

  @override
  void dispose() {
    widget.store.removeListener(_notebookChanged);
    _lifecycle.dispose();
    _autosave?.cancel();
    _titleFocus.dispose();
    _search.dispose();
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  void _notebookChanged() {
    if (_dirty || _saving != null || _inDialog) {
      setState(() {});
    } else {
      setState(_refreshSelection);
    }
  }

  void _refreshSelection() {
    final note = _selected;
    if (note == null) return;
    if (!note.visible) {
      _setSelection(null, null);
      return;
    }
    if (_base == null ||
        !note.versions.any((version) => version.id == _base!.id)) {
      _setSelection(note.id, note.latest);
    }
  }

  void _setSelection(String? id, NoteVersion? version) {
    _id = id;
    _revealed = null;
    _base = version;
    _dirty = false;
    _saveError = null;
    _title.text = version?.title ?? '';
    _body.text = version?.body ?? '';
  }

  Future<void> _openNote(
    String? id, {
    String? versionId,
    bool create = false,
  }) async {
    if (_inDialog || !await _save() || !mounted || _inDialog) return;
    if (create) {
      setState(() => _setSelection(newId(), null));
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _titleFocus.requestFocus();
      });
      return;
    }
    final note = _notebook.notes[id];
    final version = note?.versions
        .where((v) => !v.deleted && v.id == versionId)
        .firstOrNull;
    final open = note?.visible ?? false;
    setState(
      () => _setSelection(
        open ? id : null,
        open ? version ?? note!.latest : null,
      ),
    );
  }

  void _changed(String _) {
    _autosave?.cancel();
    setState(() {
      _dirty = true;
      _generation++;
      _saveError = null;
    });
    _autosave = Timer(
      const Duration(milliseconds: 380),
      () => unawaited(_save()),
    );
  }

  Future<bool> _save() {
    _autosave?.cancel();
    if (!_dirty) return Future.value(true);
    return _saving ??= _writeDraft().whenComplete(() {
      _saving = null;
      if (mounted && !_dirty && !_inDialog) setState(_refreshSelection);
    });
  }

  Future<bool> _writeDraft() async {
    while (_dirty && mounted) {
      final id = _id!;
      final generation = _generation;
      final base = _base;
      final title = _title.text;
      final body = _body.text;
      if ((base == null && title.isEmpty && body.isEmpty) ||
          (base != null && title == base.title && body == base.body)) {
        setState(() => _dirty = false);
        return true;
      }
      try {
        final version = await widget.store.revise(
          id: id,
          author: widget.account.device,
          basedOn: [?base],
          title: title,
          body: body,
        );
        if (!mounted) return false;
        setState(() {
          _base = version;
          _dirty = generation != _generation;
          _saveError = null;
        });
      } catch (error) {
        if (mounted) setState(() => _saveError = _errorText(error));
        return false;
      }
    }
    return true;
  }

  String _errorText(Object error) => error is NotebookFull
      ? 'Хранилище заполнено. Сократите заметку и повторите сохранение.'
      : 'Не удалось сохранить. Попробуйте ещё раз.';

  Future<void> _deleteOrResolve(String id, {required bool delete}) async {
    if (_inDialog || !await _save() || !mounted || _inDialog) return;
    final note = _notebook.notes[id];
    if (note == null || !note.visible) return;
    final base = id == _id ? _base ?? note.latest : note.latest;
    setState(() {
      _inDialog = true;
      _revealed = null;
    });
    try {
      if (delete) {
        final yes = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Удалить заметку?'),
            content: const Text(
              'Она будет удалена и с остальных подключённых устройств после синхронизации.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('Отмена'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('Удалить'),
              ),
            ],
          ),
        );
        if (yes != true || !mounted) return;
      }
      final version = await widget.store.revise(
        id: note.id,
        author: widget.account.device,
        basedOn: note.versions,
        title: base.title,
        body: base.body,
        deleted: delete,
      );
      if (mounted && _id == note.id) {
        setState(
          () => _setSelection(delete ? null : note.id, delete ? null : version),
        );
      }
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(_errorText(error))));
      }
    } finally {
      if (mounted) {
        setState(() {
          _inDialog = false;
          _refreshSelection();
        });
      }
    }
  }

  Future<void> _setPinned(String id, bool pinned) async {
    setState(() => _revealed = null);
    try {
      await widget.store.setPinned(id, widget.account.device, pinned);
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(_errorText(error))));
      }
    }
  }

  Future<void> _openSettings() async {
    if (_inDialog) return;
    setState(() => _revealed = null);
    final code = await showDialog<ConnectionCode>(
      context: context,
      builder: (context) =>
          SettingsDialog(sync: widget.sync, appearance: widget.appearance),
    );
    if (code == null || !mounted || !await _save() || !mounted) return;
    setState(() => _inDialog = true);
    try {
      await widget.onJoinCode(code);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Код принят. Ищем устройства в локальной сети.'),
          ),
        );
      }
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text(
              'Не удалось подключить аккаунт. Ваши заметки доступны на устройстве.',
            ),
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _inDialog = false;
          _refreshSelection();
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return CallbackShortcuts(
      bindings: {
        const SingleActivator(LogicalKeyboardKey.keyS, control: true): () =>
            unawaited(_save()),
        const SingleActivator(LogicalKeyboardKey.keyS, meta: true): () =>
            unawaited(_save()),
        const SingleActivator(LogicalKeyboardKey.keyN, control: true): () =>
            unawaited(_openNote(null, create: true)),
        const SingleActivator(LogicalKeyboardKey.keyN, meta: true): () =>
            unawaited(_openNote(null, create: true)),
      },
      child: Focus(
        autofocus: true,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final narrow = constraints.maxWidth < 720;
            return PopScope(
              canPop: !narrow || _id == null,
              onPopInvokedWithResult: (popped, _) {
                if (!popped && narrow && _id != null) {
                  unawaited(_openNote(null));
                }
              },
              child: Scaffold(
                body: SafeArea(
                  child: narrow
                      ? (_id == null ? _buildList(true) : _buildEditor(true))
                      : Row(
                          children: [
                            SizedBox(width: 326, child: _buildList(false)),
                            const VerticalDivider(width: 1),
                            Expanded(child: _buildEditor(false)),
                          ],
                        ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildList(bool narrow) {
    final colors = Theme.of(context).colorScheme;
    final query = _search.text.trim().toLowerCase();
    final notes =
        _notebook.notes.values
            .where(
              (note) =>
                  note.visible &&
                  (query.isEmpty ||
                      note.versions.any(
                        (version) =>
                            !version.deleted &&
                            (version.title.toLowerCase().contains(query) ||
                                version.body.toLowerCase().contains(query)),
                      )),
            )
            .toList()
          ..sort((first, second) {
            final firstPinned = _notebook.isPinned(first.id);
            final secondPinned = _notebook.isPinned(second.id);
            if (firstPinned != secondPinned) return firstPinned ? -1 : 1;
            final order = second.latest.time.compareTo(first.latest.time);
            return order != 0 ? order : first.id.compareTo(second.id);
          });
    return ColoredBox(
      color: colors.surfaceContainerLow,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const LeafMark(),
                const SizedBox(width: 11),
                Expanded(
                  child: Text(
                    appName,
                    style: Theme.of(context).textTheme.headlineSmall
                        ?.copyWith(fontWeight: FontWeight.w700),
                  ),
                ),
                IconButton(
                  tooltip: 'Настройки',
                  onPressed: _inDialog ? null : _openSettings,
                  icon: const Icon(Icons.settings_outlined),
                ),
              ],
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _inDialog ? null : () => _openNote(null, create: true),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Новая заметка'),
              style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(46),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _search,
              autocorrect: false,
              enableSuggestions: false,
              enableIMEPersonalizedLearning: false,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                hintText: 'Поиск по заметкам',
                prefixIcon: const Icon(Icons.search_rounded, size: 20),
                suffixIcon: query.isEmpty
                    ? null
                    : IconButton(
                        tooltip: 'Очистить поиск',
                        onPressed: () => setState(_search.clear),
                        icon: const Icon(Icons.close_rounded, size: 18),
                      ),
                isDense: true,
              ),
            ),
            const SizedBox(height: 12),
            if (notes.isEmpty)
              Expanded(
                child: Center(
                  child: Text(
                    query.isEmpty
                        ? 'Здесь будут ваши заметки'
                        : 'Ничего не найдено',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: colors.onSurfaceVariant),
                  ),
                ),
              )
            else
              Expanded(
                child: ListView.builder(
                  itemCount: notes.length,
                  findChildIndexCallback: (key) {
                    final index = notes.indexWhere(
                      (note) => ValueKey(note.id) == key,
                    );
                    return index < 0 ? null : index;
                  },
                  itemBuilder: (context, i) {
                    final note = notes[i];
                    final pinned = _notebook.isPinned(note.id);
                    return NoteRow(
                      key: ValueKey(note.id),
                      note: note,
                      pinned: pinned,
                      selected: note.id == _id,
                      revealed: note.id == _revealed,
                      onOpen: _inDialog ? null : () => _openNote(note.id),
                      onReveal: (open) => setState(() {
                        if (open) {
                          _revealed = note.id;
                        } else if (_revealed == note.id) {
                          _revealed = null;
                        }
                      }),
                      onPin: _inDialog
                          ? null
                          : () => _setPinned(note.id, !pinned),
                      onDelete: _inDialog
                          ? null
                          : () => _deleteOrResolve(note.id, delete: true),
                    );
                  },
                ),
              ),
            const Divider(height: 1),
            ListenableBuilder(
              listenable: widget.sync,
              builder: (context, _) => SizedBox(
                height: narrow ? 48 : 46,
                child: Row(
                  children: [
                    Icon(
                      widget.sync.hasNetwork
                          ? Icons.wifi_rounded
                          : Icons.wifi_off_rounded,
                      size: 17,
                      color: colors.onSurfaceVariant,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _syncLabel,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: colors.onSurfaceVariant,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Синхронизировать',
                      onPressed: () =>
                          widget.sync.syncNow(refreshDiscovery: true),
                      icon: const Icon(Icons.sync_rounded, size: 19),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String get _syncLabel {
    if (!widget.sync.hasNetwork) return 'Вне локальной сети';
    final last = widget.sync.lastSynced;
    if (last == null) return 'Ожидание устройств';
    return 'Последний обмен в ${TimeOfDay.fromDateTime(last).format(context)}';
  }

  Widget _buildEditor(bool narrow) {
    final colors = Theme.of(context).colorScheme;
    if (_id == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.description_outlined, color: colors.primary, size: 48),
            const SizedBox(height: 14),
            Text(
              'Откройте заметку',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: () => _openNote(null, create: true),
              icon: const Icon(Icons.add_rounded),
              label: const Text('Создать новую'),
            ),
          ],
        ),
      );
    }
    final conflict = _selected;
    return Column(
      children: [
        Padding(
          padding: EdgeInsets.fromLTRB(narrow ? 6 : 20, 8, 10, 8),
          child: Row(
            children: [
              if (narrow)
                IconButton(
                  tooltip: 'К списку заметок',
                  onPressed: _inDialog ? null : () => _openNote(null),
                  icon: const Icon(Icons.arrow_back_rounded),
                ),
              Expanded(
                child: Text(
                  _saveError ??
                      (_dirty
                          ? 'Сохранение…'
                          : _base == null
                          ? 'Новая заметка'
                          : 'Сохранено на устройстве'),
                  style: TextStyle(
                    color: _saveError == null
                        ? colors.onSurfaceVariant
                        : colors.error,
                    fontSize: 12,
                  ),
                ),
              ),
              if (_dirty)
                IconButton(
                  tooltip: 'Сохранить',
                  onPressed: _inDialog ? null : _save,
                  icon: const Icon(Icons.save_outlined),
                ),
              if (_base != null)
                IconButton(
                  tooltip: 'Удалить заметку',
                  onPressed: _inDialog
                      ? null
                      : () => _deleteOrResolve(_id!, delete: true),
                  icon: const Icon(Icons.delete_outline_rounded),
                ),
            ],
          ),
        ),
        const Divider(height: 1),
        Expanded(
          child: SingleChildScrollView(
            key: ValueKey(_id),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            padding: EdgeInsets.fromLTRB(
              narrow ? 20 : 38,
              24,
              narrow ? 20 : 38,
              32,
            ),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    if (conflict != null && conflict.hasConflict)
                      _conflictPanel(conflict),
                    TextField(
                      controller: _title,
                      autocorrect: false,
                      enableSuggestions: false,
                      enableIMEPersonalizedLearning: false,
                      focusNode: _titleFocus,
                      enabled: !_inDialog,
                      onChanged: _changed,
                      maxLength: maxTitleLength,
                      style: Theme.of(context).textTheme.headlineMedium,
                      decoration: InputDecoration(
                        hintText: 'Заголовок',
                        hintStyle: TextStyle(color: colors.onSurfaceVariant),
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        counterText: '',
                        filled: false,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _body,
                      autocorrect: false,
                      enableSuggestions: false,
                      enableIMEPersonalizedLearning: false,
                      enabled: !_inDialog,
                      onChanged: _changed,
                      keyboardType: TextInputType.multiline,
                      maxLength: maxBodyLength,
                      minLines: 9,
                      maxLines: null,
                      style: Theme.of(context).textTheme.bodyLarge
                          ?.copyWith(height: 1.6),
                      decoration: InputDecoration(
                        hintText: 'Напишите заметку…',
                        hintStyle: TextStyle(color: colors.onSurfaceVariant),
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        counterText: '',
                        filled: false,
                        contentPadding: EdgeInsets.zero,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _conflictPanel(Note note) {
    final colors = Theme.of(context).colorScheme;
    final live = note.versions.where((v) => !v.deleted).toList();
    return Card(
      margin: const EdgeInsets.only(bottom: 18),
      color: colors.secondaryContainer,
      elevation: 0,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              note.versions.any((v) => v.deleted)
                  ? 'На другом устройстве заметка была удалена.'
                  : 'На устройствах сохранены разные версии.',
              style: TextStyle(
                fontWeight: FontWeight.w600,
                color: colors.onSecondaryContainer,
              ),
            ),
            if (live.length > 1)
              Wrap(
                spacing: 7,
                children: [
                  for (var i = 0; i < live.length; i++)
                    ChoiceChip(
                      label: Text('Версия ${i + 1}'),
                      selected: live[i].id == _base?.id,
                      onSelected: _inDialog
                          ? null
                          : (_) => _openNote(note.id, versionId: live[i].id),
                    ),
                ],
              ),
            TextButton(
              onPressed: _inDialog
                  ? null
                  : () => _deleteOrResolve(note.id, delete: false),
              child: const Text('Оставить эту версию'),
            ),
          ],
        ),
      ),
    );
  }
}
