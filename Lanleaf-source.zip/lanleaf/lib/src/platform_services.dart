import 'dart:convert';
import 'dart:io';

import 'package:cryptography/cryptography.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as path;

import 'keys.dart';
import 'notebook_store.dart';
import 'notes.dart';

const _platform = MethodChannel('com.lanleaf/local');

class LocalAccount {
  const LocalAccount(this.key, this.device, {this.storageTag});

  final AccountKey key;
  final String device;
  final String? storageTag;

  Map<String, Object?> toJson() => {
    'key': key.code,
    'device': device,
    'storage': storageTag,
  };

  static Future<LocalAccount> fromJson(Object? value) async {
    if (value is! Map<String, dynamic> ||
        value['key'] is! String ||
        !isId(value['device'])) {
      throw const FormatException('Invalid local identity');
    }
    final key = AccountKey.parse(value['key'] as String);
    final tag = value['storage'];
    if (tag != null && tag != await key.discoveryTag()) {
      throw const FormatException('Invalid local account directory');
    }
    return LocalAccount(
      key,
      value['device'] as String,
      storageTag: tag as String?,
    );
  }
}

class DeviceStorage {
  DeviceStorage._(this.directory, this._lock);

  static Future<DeviceStorage> open() async {
    final Directory directory;
    if (Platform.isWindows) {
      final base = Platform.environment['LOCALAPPDATA'];
      if (base == null || base.isEmpty) {
        throw const FileSystemException('LOCALAPPDATA is unavailable');
      }
      directory = Directory(path.join(base, 'Lanleaf'));
    } else {
      final support = await _platform.invokeMethod<String>(
        'applicationSupport',
      );
      if (support == null) {
        throw const FileSystemException('Application Support is unavailable');
      }
      directory = Directory(path.join(support, 'Lanleaf'));
    }
    await directory.create(recursive: true);
    if (Platform.isIOS || Platform.isMacOS) {
      await _platform.invokeMethod<void>('excludeBackup', directory.path);
    }
    final lock = await File(path.join(directory.path, 'app.lock'))
        .open(mode: FileMode.append);
    try {
      await lock.lock(FileLock.exclusive);
    } catch (_) {
      await lock.close();
      throw const StorageInUse();
    }
    return DeviceStorage._(directory, lock);
  }

  final Directory directory;
  final RandomAccessFile _lock;

  Directory get _accounts => Directory(path.join(directory.path, 'accounts'));

  Directory _accountDirectory(String tag) =>
      Directory(path.join(_accounts.path, tag));

  Future<Directory> directoryFor(LocalAccount account) async {
    final tag = account.storageTag;
    return tag == null
        ? directory
        : _accountDirectory(tag).create(recursive: true);
  }

  Future<bool> hasPreviousNotes() async {
    if (await NotebookStore.fileIn(directory).exists()) return true;
    if (!await _accounts.exists()) return false;
    await for (final entity in _accounts.list(followLinks: false)) {
      if (entity is Directory && await NotebookStore.fileIn(entity).exists()) {
        return true;
      }
    }
    return false;
  }

  Future<({LocalAccount account, NotebookStore store})> openForCode(
    AccountKey key, {
    String? device,
    bool requireExisting = false,
  }) async {
    final tag = await key.discoveryTag();
    final id = device ?? newId();
    final scoped = _accountDirectory(tag);
    final scopedExists = await NotebookStore.fileIn(scoped).exists();
    final legacy = await _openLegacyNotebook(key);

    if (legacy != null && !scopedExists) {
      return (account: LocalAccount(key, id), store: legacy);
    }
    if (requireExisting && !scopedExists) throw const NoNotesForCode();

    final account = LocalAccount(key, id, storageTag: tag);
    final store = await NotebookStore.open(await directoryFor(account), key);
    if (legacy != null) await store.merge(legacy.notebook);
    return (account: account, store: store);
  }

  Future<NotebookStore?> _openLegacyNotebook(AccountKey key) async {
    if (!await NotebookStore.fileIn(directory).exists()) return null;
    try {
      return await NotebookStore.open(directory, key);
    } on SecretBoxAuthenticationError {
      return null;
    } on FormatException {
      return null;
    } on NotebookFull {
      return null;
    }
  }

  Future<LocalAccount?> readLegacyWindowsAccount() async {
    if (!Platform.isWindows) return null;
    final previous = File(path.join(directory.path, 'identity.v1'));
    try {
      if (!await previous.exists() || await previous.length() > 65536) {
        return null;
      }
      final bytes = await _platform.invokeMethod<Uint8List>(
        'readLegacyWindowsIdentity',
        await previous.readAsBytes(),
      );
      if (bytes == null) return null;
      return await LocalAccount.fromJson(jsonDecode(utf8.decode(bytes)));
    } on PlatformException {
      return null;
    } on FormatException {
      return null;
    } on FileSystemException {
      return null;
    }
  }

  Future<void> close() => _lock.close();
}

class StorageInUse implements Exception {
  const StorageInUse();
}

class NoNotesForCode implements Exception {
  const NoNotesForCode();
}

class LanInterface {
  const LanInterface(this.address, this.prefix);

  final InternetAddress address;
  final int prefix;

  bool contains(InternetAddress remote) {
    if (remote.type != InternetAddressType.IPv4 || !isPrivateV4(remote)) {
      return false;
    }
    final mask = (0xffffffff << (32 - prefix)) & 0xffffffff;
    return (_number(address) & mask) == (_number(remote) & mask);
  }

  static int _number(InternetAddress address) =>
      address.rawAddress.fold(0, (value, octet) => (value << 8) | octet);

  static bool isPrivateV4(InternetAddress address) {
    if (address.type != InternetAddressType.IPv4) return false;
    final bytes = address.rawAddress;
    return bytes[0] == 10 ||
        (bytes[0] == 192 && bytes[1] == 168) ||
        (bytes[0] == 172 && bytes[1] >= 16 && bytes[1] <= 31) ||
        (bytes[0] == 169 && bytes[1] == 254);
  }
}

Future<List<LanInterface>> localInterfaces() async {
  final raw = await _platform.invokeListMethod<String>('localInterfaces') ?? [];
  return [for (final item in raw) ?_parseInterface(item)];
}

LanInterface? _parseInterface(String item) {
  final parts = item.split('/');
  if (parts.length != 2) return null;
  final address = InternetAddress.tryParse(parts[0]);
  final prefix = int.tryParse(parts[1]);
  if (address == null ||
      prefix == null ||
      prefix < 1 ||
      prefix > 32 ||
      !LanInterface.isPrivateV4(address)) {
    return null;
  }
  return LanInterface(address, prefix);
}
