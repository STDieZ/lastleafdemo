import 'dart:async';

import 'package:material_ui/material_ui.dart';

import 'src/appearance_settings.dart';
import 'src/lan_sync.dart';
import 'src/notebook_store.dart';
import 'src/notes.dart';
import 'src/peers.dart';
import 'src/platform_services.dart';
import 'src/setup.dart';
import 'src/theme.dart';
import 'src/workspace.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LastLeafApp());
}

class LastLeafApp extends StatefulWidget {
  const LastLeafApp({super.key});

  @override
  State<LastLeafApp> createState() => _LastLeafAppState();
}

class _LastLeafAppState extends State<LastLeafApp> {
  final _navigator = GlobalKey<NavigatorState>();
  DeviceStorage? _device;
  LocalAccount? _account;
  NotebookStore? _store;
  LanSync? _sync;
  AppearanceSettings _appearance = AppearanceSettings();
  String? _startupError;
  bool _keychainAccessRequired = false;
  var _loading = true;

  @override
  void initState() {
    super.initState();
    unawaited(_open());
  }

  Future<void> _open({bool allowKeychainInteraction = false}) async {
    setState(() {
      _loading = true;
      _startupError = null;
      _keychainAccessRequired = false;
    });
    try {
      _device ??= await DeviceStorage.open();
      _appearance = await AppearanceSettings.open(_device!.directory);
      final stored = await _device!.readAccount(
        allowKeychainInteraction: allowKeychainInteraction,
      );
      if (stored != null) await _activate(stored);
    } on KeychainAccessRequired {
      _keychainAccessRequired = true;
    } on StorageInUse {
      _startupError =
          'Приложение уже открыто. Закройте другое окно и попробуйте снова.';
    } catch (_) {
      _startupError = 'Не удалось открыть данные на этом устройстве.';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _saveAccount(LocalAccount account) async {
    final device = _device!;
    try {
      await device.writeAccount(account);
    } on KeychainAccessRequired {
      final context = _navigator.currentContext;
      if (!mounted || context == null || !context.mounted) rethrow;
      final authorized = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Сохранить ключ Last Leaf'),
          content: const Text(
            'Для сохранения ключа локального аккаунта macOS может показать '
            'запрос доступа к Связке ключей.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Отмена'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Запросить доступ'),
            ),
          ],
        ),
      );
      if (!mounted || authorized != true) rethrow;
      await device.writeAccount(account, allowKeychainInteraction: true);
    }
  }

  Future<void> _activate(
    LocalAccount account, {
    List<LanEndpoint> hints = const [],
  }) async {
    final store = await NotebookStore.open(
      await _device!.directoryFor(account),
      account.key,
    );
    _startSync(account, store, hints: hints);
  }

  void _startSync(
    LocalAccount account,
    NotebookStore store, {
    List<LanEndpoint> hints = const [],
  }) {
    final sync = LanSync(account, store);
    _store = store;
    _account = account;
    _sync = sync;
    unawaited(sync.start(hints: hints));
  }

  Future<void> _onboard(ConnectionCode code) async {
    final saved = await _device!.readAccount();
    if (saved != null && saved.key.code != code.key.code) {
      throw const FormatException('A local account already exists');
    }
    final account = saved ?? LocalAccount(code.key, newId());
    if (saved == null) await _saveAccount(account);
    await _activate(account, hints: code.endpoints);
    if (mounted) setState(() {});
  }

  Future<void> _joinByCode(ConnectionCode code) async {
    final current = _account!;
    final sync = _sync!;
    if (code.key.code == current.key.code) {
      await sync.addCode(code);
      return;
    }

    final account = LocalAccount(
      code.key,
      current.device,
      storageTag: await code.key.discoveryTag(),
    );
    final oldStore = _store!;
    final newStore = await NotebookStore.open(
      await _device!.directoryFor(account),
      account.key,
    );
    try {
      await sync.close();
      await newStore.merge(oldStore.notebook);
      await _saveAccount(account);
    } catch (_) {
      sync.dispose();
      if (mounted) setState(() => _startSync(current, oldStore));
      rethrow;
    }
    sync.dispose();
    if (mounted) {
      setState(() => _startSync(account, newStore, hints: code.endpoints));
    }
  }

  @override
  void dispose() {
    _sync?.dispose();
    final device = _device;
    if (device != null) unawaited(device.close());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final needsKeychain = _keychainAccessRequired;
    final notice = needsKeychain
        ? 'Ключ для сохранённых заметок находится в Связке ключей macOS. '
              'После нажатия кнопки macOS может запросить доступ к ключу Last Leaf.'
        : _startupError;
    return ListenableBuilder(
      listenable: _appearance,
      builder: (context, _) => MaterialApp(
        navigatorKey: _navigator,
        title: appName,
        debugShowCheckedModeBanner: false,
        theme: buildLeafTheme(_appearance.palette, Brightness.light),
        darkTheme: buildLeafTheme(_appearance.palette, Brightness.dark),
        themeMode: _appearance.mode,
        locale: const Locale('ru'),
        supportedLocales: const [Locale('ru')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        home: _loading
            ? const Scaffold(body: Center(child: CircularProgressIndicator()))
            : notice != null
            ? Scaffold(
                body: Center(
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 440),
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(notice, textAlign: TextAlign.center),
                        const SizedBox(height: 16),
                        FilledButton(
                          onPressed: () =>
                              _open(allowKeychainInteraction: needsKeychain),
                          child: Text(
                            needsKeychain
                                ? 'Запросить доступ к ключу'
                                : 'Попробовать снова',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            : _account == null
            ? SetupPage(onConnect: _onboard)
            : NotesWorkspace(
                key: ValueKey(_store!),
                account: _account!,
                store: _store!,
                sync: _sync!,
                appearance: _appearance,
                onJoinCode: _joinByCode,
              ),
      ),
    );
  }
}
