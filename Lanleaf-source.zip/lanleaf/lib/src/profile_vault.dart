import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';

import 'package:characters/characters.dart';
import 'package:cryptography/cryptography.dart';
import 'package:path/path.dart' as path;

import 'appearance_settings.dart';
import 'device_settings.dart';
import 'keys.dart';
import 'notebook_store.dart';
import 'notes.dart';
import 'platform_services.dart';

const minPasswordLength = 8;
const maxPasswordBytes = 1024;
const _saltLength = 16;
const _profileLimit = 16384;

class ProfileVault {
  ProfileVault(Directory directory)
    : _file = File(path.join(directory.path, 'profile.v1'));

  final File _file;

  Future<bool> exists() => _file.exists();

  Future<VaultSession> create({
    required LocalAccount account,
    required Appearance appearance,
    required String password,
  }) async {
    if (await exists()) throw StateError('A local vault already exists');
    return _setPassword((
      account: account,
      appearance: appearance,
      device: defaultDevicePreferences,
    ), password);
  }

  Future<VaultSession> unlock(String password) async {
    final encrypted = await _read();
    final key = await _passwordKey(password, encrypted.salt);
    final data = await _openProfile(encrypted.password, key);
    return VaultSession._(this, data, key, encrypted.salt);
  }

  Future<VaultSession> resetPassword(AccountKey code, String password) async {
    final encrypted = await _read();
    final data = await _openProfile(
      encrypted.recovery,
      await code.profileRecoveryKey(),
    );
    if (data.account.key.code != code.code) {
      throw const VaultAuthenticationFailed();
    }
    return _setPassword(data, password);
  }

  Future<VaultSession> _setPassword(_Profile data, String password) async {
    if (password.characters.length < minPasswordLength ||
        utf8.encode(password).length > maxPasswordBytes) {
      throw const FormatException('Invalid password length');
    }
    final salt = randomBytes(_saltLength);
    final key = await _passwordKey(password, salt);
    await _write(data, key, salt);
    return VaultSession._(this, data, key, salt);
  }

  Future<_EncryptedProfile> _read() async {
    if (await _file.length() > _profileLimit) {
      throw const FormatException('Invalid local vault length');
    }
    final value = jsonDecode(await _file.readAsString());
    if (value is! Map<String, dynamic> ||
        value['format'] != 1 ||
        value['salt'] is! String ||
        value['password'] is! String ||
        value['recovery'] is! String) {
      throw const FormatException('Invalid local vault');
    }
    final salt = base64Decode(value['salt'] as String);
    final password = base64Decode(value['password'] as String);
    final recovery = base64Decode(value['recovery'] as String);
    if (salt.length != _saltLength ||
        password.length < 40 ||
        recovery.length < 40) {
      throw const FormatException('Invalid local vault fields');
    }
    return (salt: salt, password: password, recovery: recovery);
  }

  Future<void> _write(
    _Profile profile,
    SecretKey passwordKey,
    Uint8List salt,
  ) async {
    final content = utf8.encode(
      jsonEncode({
        'account': profile.account.toJson(),
        'appearance': encodeAppearance(profile.appearance),
        'device': encodeDevicePreferences(profile.device),
      }),
    );
    final envelopes = await Future.wait([
      seal(content, passwordKey),
      profile.account.key.profileRecoveryKey().then(
        (key) => seal(content, key),
      ),
    ]);
    await replaceFile(
      _file,
      utf8.encode(
        jsonEncode({
          'format': 1,
          'salt': base64Encode(salt),
          'password': base64Encode(envelopes[0]),
          'recovery': base64Encode(envelopes[1]),
        }),
      ),
    );
  }
}

class VaultSession {
  VaultSession._(this._vault, this._data, this._key, this._salt);

  final ProfileVault _vault;
  final SecretKey _key;
  final Uint8List _salt;
  _Profile _data;
  Future<void> _pending = Future.value();

  LocalAccount get account => _data.account;
  Appearance get appearance => _data.appearance;
  DevicePreferences get device => _data.device;
  Future<void> get idle => _pending;

  Future<void> setAccount(LocalAccount account) => _update(
    (current) => (
      account: account,
      appearance: current.appearance,
      device: current.device,
    ),
  );

  Future<void> setAppearance(Appearance appearance) => _update(
    (current) => (
      account: current.account,
      appearance: appearance,
      device: current.device,
    ),
  );

  Future<void> setDevice(DevicePreferences device) => _update(
    (current) => (
      account: current.account,
      appearance: current.appearance,
      device: device,
    ),
  );

  Future<void> _update(_Profile Function(_Profile current) apply) {
    final result = _pending.then((_) async {
      final updated = apply(_data);
      await _vault._write(updated, _key, _salt);
      _data = updated;
    });
    _pending = result.then<void>((_) {}, onError: (Object _, StackTrace _) {});
    return result;
  }
}

typedef _Profile = ({
  LocalAccount account,
  Appearance appearance,
  DevicePreferences device,
});
typedef _EncryptedProfile = ({
  Uint8List salt,
  Uint8List password,
  Uint8List recovery,
});

class VaultAuthenticationFailed implements Exception {
  const VaultAuthenticationFailed();
}

Future<_Profile> _openProfile(List<int> encrypted, SecretKey key) async {
  final List<int> clear;
  try {
    clear = await unseal(encrypted, key);
  } on SecretBoxAuthenticationError {
    throw const VaultAuthenticationFailed();
  }
  final data = jsonDecode(utf8.decode(clear));
  if (data is! Map<String, dynamic>) {
    throw const FormatException('Invalid local profile');
  }
  return (
    account: await LocalAccount.fromJson(data['account']),
    appearance: parseAppearance(data['appearance']),
    device: parseDevicePreferences(data['device']),
  );
}

Future<SecretKey> _passwordKey(String password, List<int> salt) async {
  if (utf8.encode(password).length > maxPasswordBytes) {
    throw const VaultAuthenticationFailed();
  }
  final bytes = await Isolate.run(() async {
    // Profile format 1 fixes these Argon2id parameters for future unlocks.
    final key = await Argon2id(
      parallelism: 1,
      memory: 19456,
      iterations: 2,
      hashLength: 32,
    ).deriveKeyFromPassword(password: password, nonce: salt);
    return key.extractBytes();
  });
  return SecretKey(bytes);
}
