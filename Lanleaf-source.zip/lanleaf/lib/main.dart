import 'dart:async';

import 'package:material_ui/material_ui.dart';

import 'src/appearance_settings.dart';
import 'src/lan_sync.dart';
import 'src/notebook_store.dart';
import 'src/peers.dart';
import 'src/platform_services.dart';
import 'src/profile_vault.dart';
import 'src/setup.dart';
import 'src/theme.dart';
import 'src/vault_access.dart';
import 'src/workspace.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LastLeafApp());
}

class LastLeafApp extends StatefulWidget {
  const LastLeafApp({super.key});

  @override
  State<LastLeafApp> createState() => _LastLeafAppState();
}

class _LastLeafAppState extends State<LastLeafApp> {
  final _navigator = GlobalKey<NavigatorState>();
  DeviceStorage? _device;
  late ProfileVault _vault;
  VaultSession? _session;
  LocalAccount? _previousWindows;
  NotebookStore? _store;
  LanSync? _sync;
  AppearanceSettings _appearance = AppearanceSettings();
  String? _startupError;
  bool _hasProfile = false;
  bool _hasPreviousNotes = false;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    unawaited(_open());
  }

  Future<void> _open() async {
    setState(() {
      _loading = true;
      _startupError = null;
    });
    try {
      _device ??= await DeviceStorage.open();
      _vault = ProfileVault(_device!.directory);
      _hasProfile = await _vault.exists();
      if (!_hasProfile) {
        _hasPreviousNotes = await _device!.hasPreviousNotes();
        _previousWindows = await _device!.readLegacyWindowsAccount();
      }
    } on StorageInUse {
      _startupError =
          'Приложение уже открыто. Закройте другое окно и попробуйте снова.';
    } catch (_) {
      _startupError = 'Не удалось открыть данные на этом устройстве.';
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _unlock(String password) async {
    await _activate(await _vault.unlock(password));
  }

  Future<void> _recover(ConnectionCode code, String password) async {
    await _activate(
      await _vault.resetPassword(code.key, password),
      hints: code.endpoints,
    );
  }

  Future<void> _activate(
    VaultSession session, {
    List<LanEndpoint> hints = const [],
  }) async {
    final account = session.account;
    final store = await NotebookStore.open(
      await _device!.directoryFor(account),
      account.key,
    );
    if (!mounted) return;
    setState(() => _startSession(session, store, hints: hints));
  }

  void _startSession(
    VaultSession session,
    NotebookStore store, {
    List<LanEndpoint> hints = const [],
  }) {
    _hasProfile = true;
    _previousWindows = null;
    _session = session;
    _appearance = AppearanceSettings(
      value: session.appearance,
      save: session.setAppearance,
    );
    _startSync(session.account, store, hints: hints);
  }

  void _startSync(
    LocalAccount account,
    NotebookStore store, {
    List<LanEndpoint> hints = const [],
  }) {
    final sync = LanSync(account, store);
    _store = store;
    _sync = sync;
    unawaited(sync.start(hints: hints));
  }

  Future<void> _onboard(ConnectionCode code, {required bool restore}) async {
    final opened = await _device!.openForCode(
      code.key,
      requireExisting: restore,
    );
    await _setUpVault(opened.account, opened.store, hints: code.endpoints);
  }

  Future<void> _importWindowsAccount() async {
    final account = _previousWindows!;
    final store = await NotebookStore.open(
      await _device!.directoryFor(account),
      account.key,
    );
    await _setUpVault(account, store);
  }

  Future<void> _setUpVault(
    LocalAccount account,
    NotebookStore store, {
    List<LanEndpoint> hints = const [],
  }) async {
    final context = _navigator.currentContext;
    if (!mounted || context == null) return;
    final password = await showDialog<String>(
      context: context,
      builder: (context) => const SetVaultPasswordDialog(),
    );
    if (!mounted || password == null) return;
    final appearance = await readPreviousAppearance(_device!.directory);
    final session = await _vault.create(
      account: account,
      appearance: appearance,
      password: password,
    );
    if (mounted) setState(() => _startSession(session, store, hints: hints));
  }

  Future<void> _joinByCode(ConnectionCode code) async {
    final session = _session!;
    final current = session.account;
    final sync = _sync!;
    if (code.key.code == current.key.code) {
      await sync.addCode(code);
      return;
    }

    final oldStore = _store!;
    final opened = await _device!.openForCode(code.key, device: current.device);
    try {
      await sync.close();
      await opened.store.merge(oldStore.notebook);
      await session.setAccount(opened.account);
    } catch (_) {
      sync.dispose();
      if (mounted) setState(() => _startSync(current, oldStore));
      rethrow;
    }
    sync.dispose();
    if (mounted) {
      setState(
        () => _startSync(opened.account, opened.store, hints: code.endpoints),
      );
    }
  }

  @override
  void dispose() {
    final sync = _sync;
    final session = _session;
    final device = _device;
    sync?.dispose();
    if (device != null) {
      unawaited(() async {
        await sync?.close();
        await session?.idle;
        await device.close();
      }());
    }
    super.dispose();
  }

  Widget _screen() {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_startupError case final notice?) {
      return Scaffold(
        body: Center(
          child: Container(
            constraints: const BoxConstraints(maxWidth: 440),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(notice, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: _open,
                  child: const Text('Попробовать снова'),
                ),
              ],
            ),
          ),
        ),
      );
    }
    if (_session case final session?) {
      return NotesWorkspace(
        key: ValueKey(_store!),
        account: session.account,
        store: _store!,
        sync: _sync!,
        appearance: _appearance,
        onJoinCode: _joinByCode,
      );
    }
    if (_hasProfile) {
      return VaultUnlockPage(onUnlock: _unlock, onRecover: _recover);
    }
    return SetupPage(
      onConnect: _onboard,
      hasPreviousNotes: _hasPreviousNotes,
      onImportPrevious: _previousWindows == null ? null : _importWindowsAccount,
    );
  }

  @override
  Widget build(BuildContext context) => ListenableBuilder(
    listenable: _appearance,
    builder: (context, _) => MaterialApp(
      navigatorKey: _navigator,
      title: appName,
      debugShowCheckedModeBanner: false,
      theme: buildLeafTheme(_appearance.palette, Brightness.light),
      darkTheme: buildLeafTheme(_appearance.palette, Brightness.dark),
      themeMode: _appearance.mode,
      locale: const Locale('ru'),
      supportedLocales: const [Locale('ru')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      home: _screen(),
    ),
  );
}
