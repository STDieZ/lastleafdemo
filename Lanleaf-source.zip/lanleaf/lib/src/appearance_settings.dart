import 'dart:convert';
import 'dart:io';

import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as path;

import 'theme.dart';

typedef Appearance = ({LeafPalette palette, ThemeMode mode});
const defaultAppearance = (palette: LeafPalette.green, mode: ThemeMode.system);

Appearance parseAppearance(Object? value) {
  if (value is! Map<String, dynamic>) return defaultAppearance;
  return (
    palette:
        LeafPalette.values
            .where((palette) => palette.name == value['palette'])
            .firstOrNull ??
        defaultAppearance.palette,
    mode:
        ThemeMode.values
            .where((mode) => mode.name == value['mode'])
            .firstOrNull ??
        defaultAppearance.mode,
  );
}

Map<String, String> encodeAppearance(Appearance appearance) => {
  'palette': appearance.palette.name,
  'mode': appearance.mode.name,
};

Future<Appearance> readPreviousAppearance(Directory directory) async {
  final file = File(path.join(directory.path, 'appearance.v1'));
  try {
    if (await file.exists() && await file.length() <= 4096) {
      return parseAppearance(jsonDecode(await file.readAsString()));
    }
  } on FormatException {
    return defaultAppearance;
  } on FileSystemException {
    return defaultAppearance;
  }
  return defaultAppearance;
}

class AppearanceSettings extends ChangeNotifier {
  AppearanceSettings({this._value = defaultAppearance, this._save});

  final Future<void> Function(Appearance value)? _save;
  Appearance _value;
  Future<void> _pending = Future.value();

  LeafPalette get palette => _value.palette;
  ThemeMode get mode => _value.mode;

  Future<void> update({LeafPalette? palette, ThemeMode? mode}) {
    final result = _pending.then((_) async {
      final next = (
        palette: palette ?? _value.palette,
        mode: mode ?? _value.mode,
      );
      if (next == _value) return;
      await _save?.call(next);
      _value = next;
      notifyListeners();
    });
    _pending = result.then<void>((_) {}, onError: (Object _, StackTrace _) {});
    return result;
  }
}
