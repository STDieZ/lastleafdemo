import 'dart:convert';
import 'dart:io';

import 'package:material_ui/material_ui.dart';
import 'package:path/path.dart' as path;

import 'notebook_store.dart';
import 'theme.dart';

class AppearanceSettings extends ChangeNotifier {
  AppearanceSettings() : _file = null;

  AppearanceSettings._(this._file);

  final File? _file;
  LeafPalette _palette = LeafPalette.green;
  ThemeMode _mode = ThemeMode.system;
  Future<void> _pending = Future.value();

  LeafPalette get palette => _palette;
  ThemeMode get mode => _mode;

  static Future<AppearanceSettings> open(Directory directory) async {
    final file = File(path.join(directory.path, 'appearance.v1'));
    final settings = AppearanceSettings._(file);
    try {
      if (!await file.exists()) return settings;
      final value = jsonDecode(await file.readAsString());
      if (value is Map<String, dynamic>) {
        settings._palette =
            LeafPalette.values
                .where((palette) => palette.name == value['palette'])
                .firstOrNull ??
            settings._palette;
        settings._mode =
            ThemeMode.values
                .where((mode) => mode.name == value['mode'])
                .firstOrNull ??
            settings._mode;
      }
    } on FormatException {
      // Local notes can open even when an appearance setting is corrupt.
    } on FileSystemException {
      // Keep the default appearance if preferences cannot be read.
    }
    return settings;
  }

  Future<void> update({LeafPalette? palette, ThemeMode? mode}) {
    final result = _pending.then((_) async {
      final nextPalette = palette ?? _palette;
      final nextMode = mode ?? _mode;
      if (nextPalette == _palette && nextMode == _mode) return;
      final file = _file;
      if (file != null) {
        await replaceFile(
          file,
          utf8.encode(
            jsonEncode({'palette': nextPalette.name, 'mode': nextMode.name}),
          ),
        );
      }
      _palette = nextPalette;
      _mode = nextMode;
      notifyListeners();
    });
    _pending = result.then<void>((_) {}, onError: (Object _, StackTrace _) {});
    return result;
  }
}
